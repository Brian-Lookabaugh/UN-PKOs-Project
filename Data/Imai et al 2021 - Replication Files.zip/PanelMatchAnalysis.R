rm(list=ls())

## please set the working directory
setwd("~/gitrepos/tscs/code/AJPS_tscs_replication/")

# First, get matched sets that will be used for the paper 
source("Getting_matched_sets.R")

# Then, getting objects that will later be used for making figures of covariate balance
source("Preparing_covariate_balance.R")

save.image(file= file.path(getwd(),'PanelMatch_temp1.RData'))

# getting estimates 
source("Getting_PanelEstimates.R")

save.image(file= file.path(getwd(),'PanelMatch_temp2.RData'))
