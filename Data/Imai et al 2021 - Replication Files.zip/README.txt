
Instructions for replication of analysis presented in Imai, Kosuke,
In Song Kim, and Erik H. Wang. "Matching Methods for Causal Inference with
Time-Series Cross-Section Data" (2021). American Journal of Political
Science, Forthcoming.


######################################################################
*** I. Install Dependencies *** 
######################################################################

(1) Please begin by installing the following R packages, available from
CRAN, used in the analysis.

- PanelMatch_2.0.0 
- foreign_0.8-81
- multiwayvcov_1.2.3
- lmtest_0.9-38
- stargazer_5.2.2
- pcse_1.9.1.1
- xtable_1.8-4
- devtools_2.4.2    
- gridExtra_2.3
- plm_2.4-1
- logr_1.2.5

(2) The list of Stata packages needed for replication: XTABOND2 and OUTREG2

Note: The following software versions are used to produce the results
          in the manuscript: R version 4.1.0 (2021-05-18) and STATA 12


######################################################################
*** II. R and STATA Codes to reproduce the results in the main text***
######################################################################

Running the R and STATA scripts **in the order below** will produce
figures and tables in the manuscript. Please set the working directory
to where this instruction file is located by changing **line 4 of each
R script** below.

**Note: All the outputs will be put under the /output/ folder.**

(1) PanelMatchAnalysis.R will run the three scripts below--(a), (b),
    and (c)--internally and generate all the objects that are required
    to produce the figures/tables in the main text:

    ** Check whether PanelMatch_temp1.RData and PanelMatch_temp2.RData
    are created under the working directory after running
    PanelMatchAnalysis.R.**

     (a) Getting_matched_sets.R
     (b) Preparing_covariate_balance.R
     (c) Getting_PanelEstimates.R

(2)   Figure1.R creates Figure 1
(3)   Figure3.R creates Figure 3
(4)   Figure4.R creates Figure 4 
(5)   Figure5.R creates Figure 5 
(6)   Figure6.R creates Figure 6
(7)   Figure7.R creates Figure 7 

(8)   Table1_Columns1_3.R, which produces numerical results in columns 1 and 3 of Table 1
(9)   Table1_Columns5-8.R, which produces numerical results in columns 5 through 8 of Table 1
(10) Table1_Columns_2_4.do (STATA do-file), which should be run after
       setting the directory in the STATA software to where this do
       file is, produces the numerical results for columns 2 and 4 in
       Table 1 (Note that the results are to the fourth decimal digit
       while the results in the main text is rounded to the third
       decimal digit).


######################################################################
*** III. R and STATA codes to reproduce the results in the Supplemental
           Information***
######################################################################

Running the R and STATA scripts **in the order below** will produce
figures and tables in the Supplemental Appendix. Please set the
working directory to where this instruction file is located by
changing **line 4 of each R script** below.

**Note: All the outputs will be put under the /output/ folder.**

(1) Appendix_PanelMatch.R produces the figures in Appendix sections S4 & S5

(2) Appendix_OLS.R, produces a .tex file (“Section_S6_Table_S6_1_Columns_1_3.tex")
    for columns 1 and 3 of Appendix Section S6 Table S6.1.

(3) reversal.do (STATA do-file), which should be run after setting the
     directory in the STATA software to where this do file is, produces
     numerical results for columns 2 and 4 of Appendix Section S6 Table
     S6.1.

(4) Simulation results in Supplemental Information Section S3

    (Step 1) Unzip "All_results.zip", which will create a folder
    titled "All_results" in the same directory where this instruction
    file is located. This step can be skipped if the replication
    package already includes All_results folder.

    Note: "fully_automated_simulations_and_figures" contains all
    the necessary materials to reproduce the files in the All_results
    folder. This is a computationally intensive task: The machine used
    is Amazon EC2 instance type “m5d.24xlarge” (with a total of 96
    cores). The volume size set for the machine is 1,500 GiB.

    (Step 2) Simulation_figures_tables.R reproduces Figures S1 - S6 and Tables
    S3.1 and S3.2 in Section S3 of the Appendix.


######################################################################
*** IV. Datasets ***
######################################################################

The following two files are data files used for the analysis 

(1) Acemoglu.RData

     The citation for theis dataset is: Acemoglu, Daron, et
     al. "Democracy does cause growth." Journal of political economy
     127.1 (2019): 47-100.

     Note: Acemoglu2.dta is a STATA file that is identical to
     Acemoglu.RData
     
(2) SS.RData

     The citation for this dataset is: Scheve, K., & Stasavage,
     D. (2012). Democracy, war, and wealth: lessons from two centuries
     of inheritance taxation. American Political Science Review,
     106(1), 81-102.

See Codebook.pdf in the replication package for detailed descriptions
of the variables in the two data sets. 


######################################################################
*** V. Other files in the replication package *** 
######################################################################

(1) There are 12 RData files under "All_results" folder

1. n_1000_n75_ALL_50.RData, which contains intermediate simulation results for Truth = -7.5 and N = 50

2. n_1000_n75_ALL.RData, which contains intermediate simulation results for Truth = -7.5 and N = 162

3. n_1000_n1_ALL_50.RData, which contains intermediate simulation results for Truth = -1 and N = 50

4. n_1000_n1_ALL.RData, which contains intermediate simulation results for Truth = -1 and N = 162

5. n_1000_n0_ALL_50.RData, which contains intermediate simulation results for Truth = 0 and N = 50

6. n_1000_n0_ALL.RData, which contains intermediate simulation results for Truth = 0 and N = 162

7. n_1000_n05_ALL_50.RData, which contains intermediate simulation results for Truth = -.5 and N = 50

8. n_1000_n05_ALL.RData, which contains intermediate simulation results for Truth = -.5 and N = 162

9. n_1000_1_ALL_50.RData, which contains intermediate simulation results for Truth = 1 and N = 50

10. n_1000_1_ALL.RData, which contains intermediate simulation results for Truth = 1 and N = 162

11. n_1000_05_ALL_50.RData, which contains intermediate simulation results for Truth = 0.5 and N = 50

12. n_1000_05_ALL.RData, which contains intermediate simulation results for Truth = 0.5 and N = 162

(2) There are 12 files under "fully_automated_simulations_and_figures" folder

1. summary_calc_functions.R, which contains helper functions that are used by calculations_and_figure.R and calculations_and_figure_50.R

2. ace_data_countries_with_sparse_covs_dropped.rda, which data_function_simulations.R loads to create base data for simulations

3. mother_code_50.R, which produces all intermediate simulation results for N = 50

4. perform_simulations_50.R, which, sourced by mother_code_50.R, performs simulations for N = 50

5. estimation_functions_simulations.R, which contains helper functions that estimate models using OLS and PanelMatch methods and that are used by 

6. other_N.R, which uses ace_data_countries_with_sparse_covs_dropped.rda to produce base data for simulations in scenarios where N = 50

7. calculations_and_figure_50.R, which, sourced by mother_code_50.R, converts raw simulation results into intermediate simulation results

8. perform_simulations.R, which, sourced by mother_code_50.R, performs simulations for N = 162

9. data_function_simulations.R, which uses ace_data_countries_with_sparse_covs_dropped.rda to produce base data for simulations in scenarios where N = 162

10. calculations_and_figure.R, which, sourced by mother_code.R, converts raw simulation results into intermediate simulation results

11. mother_code.R, which produces all intermediate simulation results for N = 162

12. Readme.txt, which provides step-by-step guide to conduct simulations on the Amazon cluster




