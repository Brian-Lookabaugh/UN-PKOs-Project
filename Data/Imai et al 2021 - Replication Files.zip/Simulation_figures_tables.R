rm(list=ls())

## please set the working directory
setwd("~/gitrepos/tscs/code/AJPS_tscs_replication/")

## check/create the folder to put outputs
if (file.exists(file.path(getwd(), "output"))){
    OUT_DIR <- file.path(getwd(), "output")
} else {
    dir.create(file.path(file.path(getwd(), "output")))
    OUT_DIR <- file.path(getwd(), "output")
}

options(digits=4)

library(logr) # R library to produce logs

# open log
tmp <- file.path(getwd(), "simulations_in_R.log") 
lf <- log_open(tmp)

setwd("./All_results")

###### N = 50 ########
files.of.interest <- list.files()[grepl("_ALL", list.files()) & 
                                    grepl("_50", list.files()) & 
                                    grepl("pdf", list.files()) == F & 
                                    grepl("", list.files())]
#load("n_1000_n1_ALL.RData")
big_list <- list()

for(i in 1:length(files.of.interest))
{
  load(files.of.interest[i])
  
  big_list[[i]] <- all_results$estimates
  names(big_list)[i] <- files.of.interest[i]
  
}
names(big_list) <- gsub("n_1000", "n_50", names(big_list))

truths <- c(.5, 1, 0, -.5, -1, -7.5)

for (i in 1:length(big_list)) {
  TREATMENT_EFFECT_TRUTH <- truths[i]
  filename <- gsub("ALL_50.RData", "boxplots.pdf", names(big_list)[i])
  if (grepl("_50", filename) & grepl("n75", filename) == F) {
    ylims = c(-8.5, 8.5)  
  } else if (grepl("_50", filename) == F & grepl("n75", filename) == F){
    ylims = c(-5, 5)
  } else if (grepl("_50", filename) == F & grepl("n75", filename) == T) {
    ylims = c(-12, -4)
  } else if (grepl("_50", filename) == T & grepl("n75", filename) == T) {
    ylims = c(-15, 0)
  }
  pdf(file = paste0(OUT_DIR, "/", filename), width = 23, height = 7.5)
  #par(mfrow=c(1,5), oma = c(0, 10, 0, 0)) including L = 5
  par(mfrow=c(1,4), oma = c(0, 10, 0, 0))
  axis.cex = 1.7
  # labels_ = c("\nOrdinary \nLeast \nSquares",
  #             "\nOrdinary \nLeast \nSquares \nwith dummies",
  #             "\nMahalanobis\n Dist.\nMatching",
  #             "\nPropensity \nScore\nMatching",
  #             "\nPropensity \nScore\nWeighting")
  
  labels_ = c("\nOLS",
              "\nOLS \nwith \ndumm-\nies",
              "\nMD \nMatching",
              "\nPS \nMatching",
              "\nPS \nWeigh-\nting")
  
  mains <- c("(a) L = 1\nSevere Misspecification", 
             "(b) L = 2\nModerate Misspecification",
             "(c) L = 3\nCorrect Specification",
             "(d) L = 4\nOverspecification",
             "(e) L = 5\nSevere Overspecification")
  
  #xlims = c(1:5) this is for including L = 5
  xlims = c(1:4)
  #for (k in 1:(length(big_list[[i]]))) {
  
  for (k in 1:(length(big_list[[i]])-1) ) {
    par(mar = c(10.1, 2, 8.1, 2.1))
    boxplot(estimate ~ method, data = big_list[[i]][[k]],
            main = mains[k], cex.main = 2, cex.axis = 1.2,
            cex.lab=3.3, las =1,
            xaxt = "n" ,
            ylim = ylims, xlab = "", ylab = "")
    axis(1, at = 1:5, labels = labels_, padj = .7, cex.axis = axis.cex)
    
    abline(h = TREATMENT_EFFECT_TRUTH, col = "red")
    if(k == 1){
      mtext("Estimated Effect", side = 2, line = 3, cex = 1.6, outer = T)
    }
    
  }
  
  
  dev.off()
  
}


system("mv ../output/n_50_n75_boxplots.pdf ../output/Section_S3_Figure_S4.pdf")
## box plots for balances
files.of.interest <- list.files()[grepl("_ALL", list.files()) & 
                                    grepl("_50", list.files()) & 
                                    grepl("pdf", list.files()) == F & 
                                    grepl("", list.files())]
#load("n_1000_n1_ALL.RData")
big_list <- list()

for(i in 1:length(files.of.interest))
{
  load(files.of.interest[i])
  
  big_list[[i]] <- all_results$balance
  names(big_list)[i] <- files.of.interest[i]
  
}
names(big_list) <- gsub("n_1000", "n_50", names(big_list))


for (i in 1:length(big_list)) {
  filename <- gsub("ALL_50.RData", "balances.pdf", names(big_list)[i])
  balances <- big_list[[i]]
  names(balances) <- 1:15
  balances <- balances[!names(balances) %in% c("5", "10", "15")] # removing L = 5
  mains <- c("(a) L = 1\nSevere \nMisspecification", 
             "(b) L = 2\nModerate \nMisspecification",
             "(c) L = 3\nCorrect \nSpecification",
             "(d) L = 4\nOverspecification")
  #"(e) L = 5\nSevere \nOverspecification")
  if (grepl("_50", filename)) {
    ylims = c(0, .5)  
  } else {
    ylims = c(0, 0.25)
  }
  pdf(file = paste0(OUT_DIR, "/", filename), width = 8, height = 10)
  par(#mfrow = c(3,5), 
    mfrow = c(3,4),
    oma = c(7, 5, 0, 5))
  for (#k in 1:length(balances)
    k in 1:length(balances)) {
    if (k < 5){
      par(mar = c(1, 2, 5.1, 2.1))
    } else {
      par(mar = c(1, 2, 2, 2.1))
    }
    
    axis.cex = .5
    labels_ = c("L0",
                "L1",
                "L2",
                "L3",
                "L4") # 
    #"L5")
    
    #xlims = c(1:4)  
    data <- balances[[k]]
    data <- data[data$L != "L5",] # to exclude L = 5
    data$L <- as.character(data$L)
    data$L <- as.factor(data$L)
    boxplot(balance ~ L, data = data,
            main = mains[k], cex.main = 1, cex.axis = 1, 
            cex.lab= 1, las =1,
            xaxt = "n" ,
            #  xlim = c(1,4),
            ylim = ylims, xlab = "")
    #ylab = names_of_methods[i])
    axis(1,# at = 1:6, 
         at = 1:5,
         labels = labels_, padj = .7, las = 2,
         cex.axis = axis.cex)
  }
  mtext("Mahalanobis Dist. Matching", side = 2, line = 1.6, outer = T, at = .803)
  mtext("Propensity Score Matching", side = 2, line = 1.6, outer = T, at = .49)
  mtext("Propensity Score Weighting", side = 2, line = 1.6, outer = T, at = .158)
  mtext("Balance Metrics \n Averaged across Covariates for Each Lag",
        side = 1, line = 2.5, outer = T, at = .5)
  dev.off()
}

system("mv ../output/n_50_n75_balances.pdf ../output/Section_S3_Figure_S5.pdf")

## Power graphs N = 50 ##
files.of.interest <- list.files()[grepl("_ALL", list.files()) & 
                                    grepl("_50", list.files()) & 
                                    grepl("pdf", list.files()) == F & 
                                    grepl("", list.files())]
big_list <- list()

for(i in 1:length(files.of.interest))
{
  load(files.of.interest[i])
  
  big_list[[i]] <- all_results$coverage
  names(big_list)[i] <- files.of.interest[i]
  
}
names(big_list) <- gsub("n_1000", "n_50", names(big_list))



### Type II error: 1 X 3 figure
# power = 1- coverage rate for zero
# first figure 
# L5 <- list("truth=-1" = big_list[[5]]$L5$coverage_0, 
#            "truth=-0.5" = big_list[[4]]$L5$coverage_0,
#            "truth=0" = big_list[[3]]$L5$coverage_0,
#            "truth=0.5" = big_list[[1]]$L5$coverage_0,
#            "truth=1" = big_list[[2]]$L5$coverage_0)

L4 <- list("truth=-1" = big_list[[5]]$L4$coverage_0, 
           "truth=-0.5" = big_list[[4]]$L4$coverage_0,
           "truth=0" = big_list[[3]]$L4$coverage_0,
           "truth=0.5" = big_list[[1]]$L4$coverage_0,
           "truth=1" = big_list[[2]]$L4$coverage_0) 

L3 <- list("truth=-1" = big_list[[5]]$L3$coverage_0, 
           "truth=-0.5" = big_list[[4]]$L3$coverage_0,
           "truth=0" = big_list[[3]]$L3$coverage_0,
           "truth=0.5" = big_list[[1]]$L3$coverage_0,
           "truth=1" = big_list[[2]]$L3$coverage_0) 

L2 <- list("truth=-1" = big_list[[5]]$L2$coverage_0, 
           "truth=-0.5" = big_list[[4]]$L2$coverage_0,
           "truth=0" = big_list[[3]]$L2$coverage_0,
           "truth=0.5" = big_list[[1]]$L2$coverage_0,
           "truth=1" = big_list[[2]]$L2$coverage_0) 

L1 <- list("truth=-1" = big_list[[5]]$L1$coverage_0, 
           "truth=-0.5" = big_list[[4]]$L1$coverage_0,
           "truth=0" = big_list[[3]]$L1$coverage_0,
           "truth=0.5" = big_list[[1]]$L1$coverage_0,
           "truth=1" = big_list[[2]]$L1$coverage_0) 


#
# ols_L5 <- 1- c(L5$`truth=-1`[1], L5$`truth=-0.5`[1], L5$`truth=0`[1], L5$`truth=0.5`[1], L5$`truth=1`[1])
# ols2_L5 <- 1- c(L5$`truth=-1`[2], L5$`truth=-0.5`[2], L5$`truth=0`[2], L5$`truth=0.5`[2], L5$`truth=1`[2])
# maha_L5 <- 1- c(L5$`truth=-1`[3], L5$`truth=-0.5`[3], L5$`truth=0`[3], L5$`truth=0.5`[3], L5$`truth=1`[3])
# cbpsm_L5 <- 1- c(L5$`truth=-1`[4], L5$`truth=-0.5`[4], L5$`truth=0`[4], L5$`truth=0.5`[4], L5$`truth=1`[4])
# cbpsw_L5 <- 1- c(L5$`truth=-1`[5], L5$`truth=-0.5`[5], L5$`truth=0`[5], L5$`truth=0.5`[5], L5$`truth=1`[5])


ols_L4 <- 1- c(L4$`truth=-1`[1], L4$`truth=-0.5`[1], L4$`truth=0`[1], L4$`truth=0.5`[1], L4$`truth=1`[1])
ols2_L4 <- 1- c(L4$`truth=-1`[2], L4$`truth=-0.5`[2], L4$`truth=0`[2], L4$`truth=0.5`[2], L4$`truth=1`[2])
maha_L4 <- 1- c(L4$`truth=-1`[3], L4$`truth=-0.5`[3], L4$`truth=0`[3], L4$`truth=0.5`[3], L4$`truth=1`[3])
cbpsm_L4 <- 1- c(L4$`truth=-1`[4], L4$`truth=-0.5`[4], L4$`truth=0`[4], L4$`truth=0.5`[4], L4$`truth=1`[4])
cbpsw_L4 <- 1- c(L4$`truth=-1`[5], L4$`truth=-0.5`[5], L4$`truth=0`[5], L4$`truth=0.5`[5], L4$`truth=1`[5])


ols_L3 <- 1- c(L3$`truth=-1`[1], L3$`truth=-0.5`[1], L3$`truth=0`[1], L3$`truth=0.5`[1], L3$`truth=1`[1])
ols2_L3 <- 1- c(L3$`truth=-1`[2], L3$`truth=-0.5`[2], L3$`truth=0`[2], L3$`truth=0.5`[2], L3$`truth=1`[2])
maha_L3 <- 1- c(L3$`truth=-1`[3], L3$`truth=-0.5`[3], L3$`truth=0`[3], L3$`truth=0.5`[3], L3$`truth=1`[3])
cbpsm_L3 <- 1- c(L3$`truth=-1`[4], L3$`truth=-0.5`[4], L3$`truth=0`[4], L3$`truth=0.5`[4], L3$`truth=1`[4])
cbpsw_L3 <- 1- c(L3$`truth=-1`[5], L3$`truth=-0.5`[5], L3$`truth=0`[5], L3$`truth=0.5`[5], L3$`truth=1`[5])

ols_L2 <- 1- c(L2$`truth=-1`[1], L2$`truth=-0.5`[1], L2$`truth=0`[1], L2$`truth=0.5`[1], L2$`truth=1`[1])
ols2_L2 <- 1- c(L2$`truth=-1`[2], L2$`truth=-0.5`[2], L2$`truth=0`[2], L2$`truth=0.5`[2], L2$`truth=1`[2])
maha_L2 <- 1- c(L2$`truth=-1`[3], L2$`truth=-0.5`[3], L2$`truth=0`[3], L2$`truth=0.5`[3], L2$`truth=1`[3])
cbpsm_L2 <- 1- c(L2$`truth=-1`[4], L2$`truth=-0.5`[4], L2$`truth=0`[4], L2$`truth=0.5`[4], L2$`truth=1`[4])
cbpsw_L2 <- 1- c(L2$`truth=-1`[5], L2$`truth=-0.5`[5], L2$`truth=0`[5], L2$`truth=0.5`[5], L2$`truth=1`[5])

ols_L1 <- 1- c(L1$`truth=-1`[1], L1$`truth=-0.5`[1], L1$`truth=0`[1], L1$`truth=0.5`[1], L1$`truth=1`[1])
ols2_L1 <- 1- c(L1$`truth=-1`[2], L1$`truth=-0.5`[2], L1$`truth=0`[2], L1$`truth=0.5`[2], L1$`truth=1`[2])
maha_L1 <- 1- c(L1$`truth=-1`[3], L1$`truth=-0.5`[3], L1$`truth=0`[3], L1$`truth=0.5`[3], L1$`truth=1`[3])
cbpsm_L1 <- 1- c(L1$`truth=-1`[4], L1$`truth=-0.5`[4], L1$`truth=0`[4], L1$`truth=0.5`[4], L1$`truth=1`[4])
cbpsw_L1 <- 1- c(L1$`truth=-1`[5], L1$`truth=-0.5`[5], L1$`truth=0`[5], L1$`truth=0.5`[5], L1$`truth=1`[5])

#L5_power <- list(ols_L5, ols2_L5,  maha_L5, cbpsm_L5, cbpsw_L5)
L4_power <- list(ols_L4, ols2_L4,  maha_L4, cbpsm_L4, cbpsw_L4)
L3_power <- list(ols_L3, ols2_L3,  maha_L3, cbpsm_L3, cbpsw_L3)
L2_power <- list(ols_L2, ols2_L2,  maha_L2, cbpsm_L2, cbpsw_L2)
L1_power <- list(ols_L1, ols2_L1,  maha_L1, cbpsm_L1, cbpsw_L1)



#powers <- list(L1_power, L2_power, L3_power, L4_power, L5_power)
powers <- list(L1_power, L2_power, L3_power, L4_power)
cols <- c("red", "blue", "green", "purple", "black")
ltys <- c(1,4,5,6, 7)
mains <- c("L = 1 (Misspecified)", "L = 2 (Misspecified)", "L = 3 (Correct)", 
           "L = 4 (Overspecified)")
#"L = 5 (Overspecified)")
pdf(file = paste0(OUT_DIR,"/powers_50.pdf"), width = 10, height = 6)
# pdf(file = "~/Dropbox/new_tscs/Sim_files/powers.pdf", width = 10, height = 6)
#par(mfrow = c(1,5))
par(mfrow = c(1,4))
for (i in 1:length(powers)){
  plot(1, xlab = "Truth", ylab = "Power", 
       xaxt = "n", 
       #yaxt = "n",
       xlim = c(1, 5),
       pch = '',
       ylim = c(0, 1), cex = 1.4,
       main = mains[i]) 
  abline(h = .1, lty = 3)
  abline(v = 3, lty = 2)
  axis(side = 1, at = 1:5, labels = c(-1, -0.5, 0, 0.5, 1))
  #axis(side = 2, at = , labels = c(-1, -0.5, 0, 0.5, 1))
  for (j in 1:length(powers[[i]])) {
    lines(powers[[i]][[j]], col = cols[j], lty = ltys[j])
  }
  
  legend("topright", 
         # legend=c("OLS", 
         #          "OLS with Dummies",
         #          "Mahalanobis Dist. \n Matching", 
         #          "Propensity Score \n Matching", 
         #          "Propensity Score \n Weighting"),
         legend=c("OLS",
                  "OLS with Dummies",
                  "MD Matching",
                  "PS Matching",
                  "PS Weighting"),
         #y.intersp = 3,
         col=cols, lty=ltys, cex=0.6, bty = "n")
  
}
dev.off()
system("mv ../output/powers_50.pdf ../output/Section_S3_Figure_S6.pdf")
###### N = 162 ########

files.of.interest <- list.files()[grepl("_ALL", list.files()) & 
                                    grepl("_50", list.files()) == F & 
                                    grepl("pdf", list.files()) == F & 
                                    grepl("", list.files())]
big_list <- list()

for(i in 1:length(files.of.interest))
{
  load(files.of.interest[i])
  
  big_list[[i]] <- all_results$estimates
  names(big_list)[i] <- files.of.interest[i]
  
}
names(big_list) <- gsub("n_50", "n_1000", names(big_list))

truths <- c(.5, 1, 0, -.5, -1, -7.5)

for (i in 1:length(big_list)) {
  TREATMENT_EFFECT_TRUTH <- truths[i]
  filename <- gsub("ALL.RData", "boxplots.pdf", names(big_list)[i])
  if (grepl("_50", filename) & grepl("n75", filename) == F) {
    ylims = c(-8.5, 8.5)  
  } else if (grepl("_50", filename) == F & grepl("n75", filename) == F){
    ylims = c(-5, 5)
  } else if (grepl("_50", filename) == F & grepl("n75", filename) == T) {
    ylims = c(-12, -4)
  } else if (grepl("_50", filename) == T & grepl("n75", filename) == T) {
    ylims = c(-15, 0)
  }
  pdf(file = paste0(OUT_DIR, "/", filename), width = 23, height = 7.5)
  par(mfrow=c(1,4), oma = c(0, 10, 0, 0))
  #par(mfrow=c(1,4), oma = c(0, 10, 0, 0))
  axis.cex = 1.7
  # labels_ = c("\nOrdinary \nLeast \nSquares",
  #             "\nOrdinary \nLeast \nSquares \nwith Dummies",
  #             "\nMahalanobis\n Dist.\nMatching",
  #             "\nPropensity \nScore\nMatching",
  #             "\nPropensity \nScore\nWeighting")
  
  labels_ = c("\nOLS",
              "\nOLS \nwith \ndumm-\nies",
              "\nMD \nMatching",
              "\nPS \nMatching",
              "\nPS \nWeigh-\nting")
  
  mains <- c("(a) L = 1\nSevere Misspecification", 
             "(b) L = 2\nModerate Misspecification",
             "(c) L = 3\nCorrect Specification",
             "(d) L = 4\nOverspecification")
  #"(e) L = 5\nSevere Overspecification")
  
  xlims = c(1:5)
  for (k in 1:(length(big_list[[i]])-1) ) {
    par(mar = c(10.1, 2, 8.1, 2.1))
    boxplot(estimate ~ method, data = big_list[[i]][[k]],
            main = mains[k], cex.main = 2, cex.axis = 1.2,
            cex.lab=3.3, las =1,
            xaxt = "n" ,
            ylim = ylims, xlab = "", ylab = "")
    axis(1, at = 1:5, labels = labels_, padj = .7, cex.axis = axis.cex)
    
    abline(h = TREATMENT_EFFECT_TRUTH, col = "red")
    if(k == 1){
      mtext("Estimated Effect", side = 2, line = 3, cex = 1.6, outer = T)
    }
  }
  
  
  dev.off()
  
}
system("mv ../output/n_1000_n75_boxplots.pdf ../output/Section_S3_Figure_S1.pdf")

## box plots for balances
files.of.interest <- list.files()[grepl("_ALL", list.files()) & 
                                    grepl("_50", list.files()) == F & 
                                    grepl("pdf", list.files()) == F & 
                                    grepl("", list.files())]

big_list <- list()

for(i in 1:length(files.of.interest))
{
  load(files.of.interest[i])
  
  big_list[[i]] <- all_results$balance
  names(big_list)[i] <- files.of.interest[i]
  
}
names(big_list) <- gsub("n_50", "n_1000", names(big_list))

for (i in 1:length(big_list)) {
  filename <- gsub("ALL.RData", "balances.pdf", names(big_list)[i])
  balances <- big_list[[i]]
  names(balances) <- 1:15
  balances <- balances[!names(balances) %in% c("5", "10", "15")] # removing L = 5
  mains <- c("(a) L = 1\nSevere \nMisspecification", 
             "(b) L = 2\nModerate \nMisspecification",
             "(c) L = 3\nCorrect \nSpecification",
             "(d) L = 4\nOverspecification")
  # "(e) L = 5\nSevere \nOverspecification")
  if (grepl("_50", filename)) {
    ylims = c(0, .5)  
  } else {
    ylims = c(0, 0.25)
  }
  pdf(file = paste0(OUT_DIR, "/", filename), width = 8, height = 10)
  par(mfrow = c(3,4), oma = c(7, 5, 0, 5))
  for (k in 1:length(balances)) {
    if (k < 5){
      par(mar = c(1, 2, 5.1, 2.1))
    } else {
      par(mar = c(1, 2, 2, 2.1))
    }
    
    axis.cex = .5
    labels_ = c("L0",
                "L1",
                "L2",
                "L3",
                "L4")
    #"L5")
    
    #xlims = c(1:4)  
    data <- balances[[k]]
    data <- data[data$L != "L5",] # to exclude L = 5
    data$L <- as.character(data$L)
    data$L <- as.factor(data$L)
    boxplot(balance ~ L, data = data,
            main = mains[k], cex.main = 1, cex.axis = 1, 
            cex.lab= 1, las =1,
            xaxt = "n" ,
            # xlim = c(0.5,5.5),
            ylim = ylims, xlab = "")
    #ylab = names_of_methods[i])
    axis(1, at = 1:5, labels = labels_, padj = .7, las = 2,
         cex.axis = axis.cex)
  }
  mtext("Mahalanobis Dist. Matching", side = 2, line = 1.6, outer = T, at = .803)
  mtext("Propensity Score Matching", side = 2, line = 1.6, outer = T, at = .49)
  mtext("Propensity Score Weighting", side = 2, line = 1.6, outer = T, at = .158)
  mtext("Balance Metrics \n Averaged across Covariates for Each Lag",
        side = 1, line = 2.5, outer = T, at = .5)
  dev.off()
}

system("mv ../output/n_1000_n75_balances.pdf ../output/Section_S3_Figure_S2.pdf")


## Power graphs N = 162 ##
files.of.interest <- list.files()[grepl("_ALL", list.files()) & 
                                    grepl("_50", list.files()) == FALSE & 
                                    grepl("pdf", list.files()) == F & 
                                    grepl("", list.files())]
big_list <- list()

for(i in 1:length(files.of.interest))
{
  load(files.of.interest[i])
  
  big_list[[i]] <- all_results$coverage
  names(big_list)[i] <- files.of.interest[i]
  
}
#names(big_list) <- gsub("n_1000", "n_50", names(big_list))

### Type II error: 1 X 3 figure
# power = 1- coverage rate for zero
# first figure 
# L5 <- list("truth=-1" = big_list[[5]]$L5$coverage_0, 
#            "truth=-0.5" = big_list[[4]]$L5$coverage_0,
#            "truth=0" = big_list[[3]]$L5$coverage_0,
#            "truth=0.5" = big_list[[1]]$L5$coverage_0,
#            "truth=1" = big_list[[2]]$L5$coverage_0)

L4 <- list("truth=-1" = big_list[[5]]$L4$coverage_0, 
           "truth=-0.5" = big_list[[4]]$L4$coverage_0,
           "truth=0" = big_list[[3]]$L4$coverage_0,
           "truth=0.5" = big_list[[1]]$L4$coverage_0,
           "truth=1" = big_list[[2]]$L4$coverage_0) 

L3 <- list("truth=-1" = big_list[[5]]$L3$coverage_0, 
           "truth=-0.5" = big_list[[4]]$L3$coverage_0,
           "truth=0" = big_list[[3]]$L3$coverage_0,
           "truth=0.5" = big_list[[1]]$L3$coverage_0,
           "truth=1" = big_list[[2]]$L3$coverage_0) 

L2 <- list("truth=-1" = big_list[[5]]$L2$coverage_0, 
           "truth=-0.5" = big_list[[4]]$L2$coverage_0,
           "truth=0" = big_list[[3]]$L2$coverage_0,
           "truth=0.5" = big_list[[1]]$L2$coverage_0,
           "truth=1" = big_list[[2]]$L2$coverage_0) 

L1 <- list("truth=-1" = big_list[[5]]$L1$coverage_0, 
           "truth=-0.5" = big_list[[4]]$L1$coverage_0,
           "truth=0" = big_list[[3]]$L1$coverage_0,
           "truth=0.5" = big_list[[1]]$L1$coverage_0,
           "truth=1" = big_list[[2]]$L1$coverage_0) 


#
# ols_L5 <- 1- c(L5$`truth=-1`[1], L5$`truth=-0.5`[1], L5$`truth=0`[1], L5$`truth=0.5`[1], L5$`truth=1`[1])
# ols2_L5 <- 1- c(L5$`truth=-1`[2], L5$`truth=-0.5`[2], L5$`truth=0`[2], L5$`truth=0.5`[2], L5$`truth=1`[2])
# maha_L5 <- 1- c(L5$`truth=-1`[3], L5$`truth=-0.5`[3], L5$`truth=0`[3], L5$`truth=0.5`[3], L5$`truth=1`[3])
# cbpsm_L5 <- 1- c(L5$`truth=-1`[4], L5$`truth=-0.5`[4], L5$`truth=0`[4], L5$`truth=0.5`[4], L5$`truth=1`[4])
# cbpsw_L5 <- 1- c(L5$`truth=-1`[5], L5$`truth=-0.5`[5], L5$`truth=0`[5], L5$`truth=0.5`[5], L5$`truth=1`[5])


ols_L4 <- 1- c(L4$`truth=-1`[1], L4$`truth=-0.5`[1], L4$`truth=0`[1], L4$`truth=0.5`[1], L4$`truth=1`[1])
ols2_L4 <- 1- c(L4$`truth=-1`[2], L4$`truth=-0.5`[2], L4$`truth=0`[2], L4$`truth=0.5`[2], L4$`truth=1`[2])
maha_L4 <- 1- c(L4$`truth=-1`[3], L4$`truth=-0.5`[3], L4$`truth=0`[3], L4$`truth=0.5`[3], L4$`truth=1`[3])
cbpsm_L4 <- 1- c(L4$`truth=-1`[4], L4$`truth=-0.5`[4], L4$`truth=0`[4], L4$`truth=0.5`[4], L4$`truth=1`[4])
cbpsw_L4 <- 1- c(L4$`truth=-1`[5], L4$`truth=-0.5`[5], L4$`truth=0`[5], L4$`truth=0.5`[5], L4$`truth=1`[5])


ols_L3 <- 1- c(L3$`truth=-1`[1], L3$`truth=-0.5`[1], L3$`truth=0`[1], L3$`truth=0.5`[1], L3$`truth=1`[1])
ols2_L3 <- 1- c(L3$`truth=-1`[2], L3$`truth=-0.5`[2], L3$`truth=0`[2], L3$`truth=0.5`[2], L3$`truth=1`[2])
maha_L3 <- 1- c(L3$`truth=-1`[3], L3$`truth=-0.5`[3], L3$`truth=0`[3], L3$`truth=0.5`[3], L3$`truth=1`[3])
cbpsm_L3 <- 1- c(L3$`truth=-1`[4], L3$`truth=-0.5`[4], L3$`truth=0`[4], L3$`truth=0.5`[4], L3$`truth=1`[4])
cbpsw_L3 <- 1- c(L3$`truth=-1`[5], L3$`truth=-0.5`[5], L3$`truth=0`[5], L3$`truth=0.5`[5], L3$`truth=1`[5])

ols_L2 <- 1- c(L2$`truth=-1`[1], L2$`truth=-0.5`[1], L2$`truth=0`[1], L2$`truth=0.5`[1], L2$`truth=1`[1])
ols2_L2 <- 1- c(L2$`truth=-1`[2], L2$`truth=-0.5`[2], L2$`truth=0`[2], L2$`truth=0.5`[2], L2$`truth=1`[2])
maha_L2 <- 1- c(L2$`truth=-1`[3], L2$`truth=-0.5`[3], L2$`truth=0`[3], L2$`truth=0.5`[3], L2$`truth=1`[3])
cbpsm_L2 <- 1- c(L2$`truth=-1`[4], L2$`truth=-0.5`[4], L2$`truth=0`[4], L2$`truth=0.5`[4], L2$`truth=1`[4])
cbpsw_L2 <- 1- c(L2$`truth=-1`[5], L2$`truth=-0.5`[5], L2$`truth=0`[5], L2$`truth=0.5`[5], L2$`truth=1`[5])

ols_L1 <- 1- c(L1$`truth=-1`[1], L1$`truth=-0.5`[1], L1$`truth=0`[1], L1$`truth=0.5`[1], L1$`truth=1`[1])
ols2_L1 <- 1- c(L1$`truth=-1`[2], L1$`truth=-0.5`[2], L1$`truth=0`[2], L1$`truth=0.5`[2], L1$`truth=1`[2])
maha_L1 <- 1- c(L1$`truth=-1`[3], L1$`truth=-0.5`[3], L1$`truth=0`[3], L1$`truth=0.5`[3], L1$`truth=1`[3])
cbpsm_L1 <- 1- c(L1$`truth=-1`[4], L1$`truth=-0.5`[4], L1$`truth=0`[4], L1$`truth=0.5`[4], L1$`truth=1`[4])
cbpsw_L1 <- 1- c(L1$`truth=-1`[5], L1$`truth=-0.5`[5], L1$`truth=0`[5], L1$`truth=0.5`[5], L1$`truth=1`[5])

#L5_power <- list(ols_L5, ols2_L5,  maha_L5, cbpsm_L5, cbpsw_L5)
L4_power <- list(ols_L4, ols2_L4,  maha_L4, cbpsm_L4, cbpsw_L4)
L3_power <- list(ols_L3, ols2_L3,  maha_L3, cbpsm_L3, cbpsw_L3)
L2_power <- list(ols_L2, ols2_L2,  maha_L2, cbpsm_L2, cbpsw_L2)
L1_power <- list(ols_L1, ols2_L1,  maha_L1, cbpsm_L1, cbpsw_L1)



#powers <- list(L1_power, L2_power, L3_power, L4_power, L5_power)
powers <- list(L1_power, L2_power, L3_power, L4_power)
cols <- c("red", "blue", "green", "purple", "black")
ltys <- c(1,4,5,6, 7)
mains <- c("L = 1 (Misspecified)", "L = 2 (Misspecified)", "L = 3 (Correct)", 
           "L = 4 (Overspecified)")
#"L = 5 (Overspecified)")
pdf(file = paste0(OUT_DIR,"/powers_162.pdf"), width = 10, height = 6)
# pdf(file = "~/Dropbox/new_tscs/Sim_files/powers.pdf", width = 10, height = 6)
#par(mfrow = c(1,5))
par(mfrow = c(1,4))
for (i in 1:length(powers)){
  plot(1, xlab = "Truth", ylab = "Power", 
       xaxt = "n", 
       #yaxt = "n",
       xlim = c(1, 5),
       pch = '',
       ylim = c(0, 1), cex = 1.4,
       main = mains[i]) 
  abline(h = .1, lty = 3)
  abline(v = 3, lty = 2)
  axis(side = 1, at = 1:5, labels = c(-1, -0.5, 0, 0.5, 1))
  #axis(side = 2, at = , labels = c(-1, -0.5, 0, 0.5, 1))
  for (j in 1:length(powers[[i]])) {
    lines(powers[[i]][[j]], col = cols[j], lty = ltys[j])
  }
  
  legend("topright", 
         # legend=c("OLS",
         #          "OLS with Dummies",
         #          "Mahalanobis Dist. \n Matching",
         #          "Propensity Score \n Matching",
         #          "Propensity Score \n Weighting"),
         legend=c("OLS",
                  "OLS with Dummies",
                  "MD Matching",
                  "PS Matching",
                  "PS Weighting"),
         
         #y.intersp = 3,
         col=cols, lty=ltys, cex=0.6, bty = "n")
  
}
dev.off()
system("mv ../output/powers_162.pdf ../output/Section_S3_Figure_S3.pdf")
system("rm ../output/n_*")

########## RMSE for N162 ##########
load("n_1000_n75_ALL.RData")
all_estimates <- all_results$estimates
all_ses <- all_results$ses
all_coverage <- all_results$coverage

TRUTH <- -7.5
# bias
L1_bias <- tapply(all_estimates[[1]]$estimate, 
                  all_estimates[[1]]$method,
                  mean, na.rm = T) - TRUTH

L2_bias <- tapply(all_estimates[[2]]$estimate, 
                  all_estimates[[2]]$method,
                  mean, na.rm = T) - TRUTH

L3_bias <- tapply(all_estimates[[3]]$estimate, 
                  all_estimates[[3]]$method,
                  mean, na.rm = T) - TRUTH

L4_bias <- tapply(all_estimates[[4]]$estimate, 
                  all_estimates[[4]]$method,
                  mean, na.rm = T) - TRUTH

# L5_bias <- tapply(all_estimates[[5]]$estimate, 
#                   all_estimates[[5]]$method,
#                   mean, na.rm = T) - TRUTH

L1_sd <- tapply(all_estimates[[1]]$estimate, 
                all_estimates[[1]]$method, 
                sd, na.rm = T)

L2_sd <- tapply(all_estimates[[2]]$estimate, 
                all_estimates[[2]]$method, 
                sd, na.rm = T)

L3_sd <- tapply(all_estimates[[3]]$estimate, 
                all_estimates[[3]]$method, 
                sd, na.rm = T)

L4_sd <- tapply(all_estimates[[4]]$estimate, 
                all_estimates[[4]]$method, 
                sd, na.rm = T)

# SE
L4_se <- tapply(all_ses[[4]]$estimate, 
                all_ses[[4]]$method, 
                mean, na.rm = T)
L4_se <- L4_se[order(factor(names(L4_se), levels = c('OLS', 'OLS2', 'Mahalanobis', 
                                                     'CBPS Matching', 'CBPS Weighting')))]

L1_se <- tapply(all_ses[[1]]$estimate, 
                all_ses[[1]]$method, 
                mean, na.rm = T)
L1_se <- L1_se[order(factor(names(L1_se), levels = c('OLS', 'OLS2', 'Mahalanobis', 
                                                     'CBPS Matching', 'CBPS Weighting')))]

L2_se <- tapply(all_ses[[2]]$estimate, 
                all_ses[[2]]$method, 
                mean, na.rm = T)
L2_se <- L2_se[order(factor(names(L2_se), levels = c('OLS', 'OLS2', 'Mahalanobis', 
                                                     'CBPS Matching', 'CBPS Weighting')))]

L3_se <- tapply(all_ses[[3]]$estimate, 
                all_ses[[3]]$method, 
                mean, na.rm = T)
L3_se <- L3_se[order(factor(names(L3_se), levels = c('OLS', 'OLS2', 'Mahalanobis', 
                                                     'CBPS Matching', 'CBPS Weighting')))]

# L5_sd <- tapply(all_estimates[[5]]$estimate, 
#                 all_estimates[[5]]$method, 
#                 sd, na.rm = T)

L1_rmse <- tapply(all_estimates[[1]]$estimate, 
                  all_estimates[[1]]$method,
                  function(x) sqrt(mean((x-TRUTH)^2)))

L2_rmse <- tapply(all_estimates[[2]]$estimate, 
                  all_estimates[[2]]$method,
                  function(x) sqrt(mean((x-TRUTH)^2)))

L3_rmse <- tapply(all_estimates[[3]]$estimate, 
                  all_estimates[[3]]$method,
                  function(x) sqrt(mean((x-TRUTH)^2)))

L4_rmse <- tapply(all_estimates[[4]]$estimate, 
                  all_estimates[[4]]$method,
                  function(x) sqrt(mean((x-TRUTH)^2)))

# L5_rmse <- tapply(all_estimates[[5]]$estimate, 
#                   all_estimates[[5]]$method,
#                   function(x) sqrt(mean((x-TRUTH)^2)))
L1_rmse <- round(L1_rmse,2)
L2_rmse <- round(L2_rmse,2)
L3_rmse <- round(L3_rmse,2)
L4_rmse <- round(L4_rmse,2)
#L5_rmse <- round(L5_rmse,2)

L1_bias <- round(L1_bias,2)
L2_bias <- round(L2_bias,2)
L3_bias <- round(L3_bias,2)
L4_bias <- round(L4_bias,2)

L1_sd <- round(L1_sd,2)
L2_sd <- round(L2_sd,2)
L3_sd <- round(L3_sd,2)
L4_sd <- round(L4_sd,2)
#L5_sd <- round(L5_sd,2)

L1_se <- round(L1_se,2)
L2_se <- round(L2_se,2)
L3_se <- round(L3_se,2)
L4_se <- round(L4_se,2)


#L5_bias <- round(L5_bias,2)
# coverage
#load("n_1000_n75_coverage.RData")
L1_cov <- round(all_coverage$L1$coverage,2)
L2_cov <- round(all_coverage$L2$coverage,2)
L3_cov <- round(all_coverage$L3$coverage,2)
L4_cov <- round(all_coverage$L4$coverage,2)
#L5_cov <- round(all_coverage$L5$coverage,2)

df <- 
  data.frame(Method = c("OLS",
                        "OLS with dummies",
                        "MD. Matching",
                        "PS. Matching", 
                        "PS. Weighting"),
             L1_Bias = L1_bias,
             #   L1_sd = L1_sd,
             L1_rmse = L1_rmse,
             L1_cov = L1_cov,
             
             L2_Bias = L2_bias,
             #  L2_sd = L2_sd,
             L2_rmse = L2_rmse,
             L2_cov = L2_cov,
             
             L3_Bias = L3_bias,
             # L3_sd = L3_sd,
             L3_rmse = L3_rmse,
             L3_cov = L3_cov,
             
             L4_Bias = L4_bias,
             # L4_sd = L4_sd,
             L4_rmse = L4_rmse,
             L4_cov = L4_cov)

# L5_Bias = L5_bias,
# #L5_sd = L5_sd,
# L5_rmse = L5_rmse,
# L5_cov = L5_cov
#)
row.names(df) <- NULL
colnames(df) <- NULL
library(xtable)

#df <- t(df)
# row.names(df) <- 
#   c("Metrics",
#     "Bias (L = 1)", "RMSE (L = 1)", "Coverage (L = 1)",
#     "Bias (L = 2)", "RMSE (L = 2)", "Coverage (L = 2)",
#     "Bias (L = 3)", "RMSE (L = 3)", "Coverage (L = 3)",
#     "Bias (L = 4)", "RMSE (L = 4)", "Coverage (L = 4)")
#"Bias (L = 5)", "RMSE (L = 5)", "Coverage (L = 5)"
#)


print.xtable(xtable(df), type = "latex",
             floating = F,include.colnames = F,
             file = paste0(OUT_DIR,"/Section_3_Table_S3_1.tex"))
##
load("n_1000_n75_ALL_50.RData")
all_estimates <- all_results$estimates
all_ses <- all_results$ses
all_coverage <- all_results$coverage

TRUTH <- -7.5
# bias
L1_bias <- tapply(all_estimates[[1]]$estimate, 
                  all_estimates[[1]]$method,
                  mean, na.rm = T) - TRUTH

L2_bias <- tapply(all_estimates[[2]]$estimate, 
                  all_estimates[[2]]$method,
                  mean, na.rm = T) - TRUTH

L3_bias <- tapply(all_estimates[[3]]$estimate, 
                  all_estimates[[3]]$method,
                  mean, na.rm = T) - TRUTH

L4_bias <- tapply(all_estimates[[4]]$estimate, 
                  all_estimates[[4]]$method,
                  mean, na.rm = T) - TRUTH

# L5_bias <- tapply(all_estimates[[5]]$estimate, 
#                   all_estimates[[5]]$method,
#                   mean, na.rm = T) - TRUTH

L1_sd <- tapply(all_estimates[[1]]$estimate, 
                all_estimates[[1]]$method, 
                sd, na.rm = T)

L2_sd <- tapply(all_estimates[[2]]$estimate, 
                all_estimates[[2]]$method, 
                sd, na.rm = T)

L3_sd <- tapply(all_estimates[[3]]$estimate, 
                all_estimates[[3]]$method, 
                sd, na.rm = T)

L4_sd <- tapply(all_estimates[[4]]$estimate, 
                all_estimates[[4]]$method, 
                sd, na.rm = T)

# SE
L4_se <- tapply(all_ses[[4]]$estimate, 
                all_ses[[4]]$method, 
                mean, na.rm = T)
L4_se <- L4_se[order(factor(names(L4_se), levels = c('OLS', 'OLS2', 'Mahalanobis', 
                                                     'CBPS Matching', 'CBPS Weighting')))]

L1_se <- tapply(all_ses[[1]]$estimate, 
                all_ses[[1]]$method, 
                mean, na.rm = T)
L1_se <- L1_se[order(factor(names(L1_se), levels = c('OLS', 'OLS2', 'Mahalanobis', 
                                                     'CBPS Matching', 'CBPS Weighting')))]

L2_se <- tapply(all_ses[[2]]$estimate, 
                all_ses[[2]]$method, 
                mean, na.rm = T)
L2_se <- L2_se[order(factor(names(L2_se), levels = c('OLS', 'OLS2', 'Mahalanobis', 
                                                     'CBPS Matching', 'CBPS Weighting')))]

L3_se <- tapply(all_ses[[3]]$estimate, 
                all_ses[[3]]$method, 
                mean, na.rm = T)
L3_se <- L3_se[order(factor(names(L3_se), levels = c('OLS', 'OLS2', 'Mahalanobis', 
                                                     'CBPS Matching', 'CBPS Weighting')))]

# L5_sd <- tapply(all_estimates[[5]]$estimate, 
#                 all_estimates[[5]]$method, 
#                 sd, na.rm = T)

L1_rmse <- tapply(all_estimates[[1]]$estimate, 
                  all_estimates[[1]]$method,
                  function(x) sqrt(mean((x-TRUTH)^2)))

L2_rmse <- tapply(all_estimates[[2]]$estimate, 
                  all_estimates[[2]]$method,
                  function(x) sqrt(mean((x-TRUTH)^2)))

L3_rmse <- tapply(all_estimates[[3]]$estimate, 
                  all_estimates[[3]]$method,
                  function(x) sqrt(mean((x-TRUTH)^2)))

L4_rmse <- tapply(all_estimates[[4]]$estimate, 
                  all_estimates[[4]]$method,
                  function(x) sqrt(mean((x-TRUTH)^2)))

# L5_rmse <- tapply(all_estimates[[5]]$estimate, 
#                   all_estimates[[5]]$method,
#                   function(x) sqrt(mean((x-TRUTH)^2)))
L1_rmse <- round(L1_rmse,2)
L2_rmse <- round(L2_rmse,2)
L3_rmse <- round(L3_rmse,2)
L4_rmse <- round(L4_rmse,2)
#L5_rmse <- round(L5_rmse,2)

L1_bias <- round(L1_bias,2)
L2_bias <- round(L2_bias,2)
L3_bias <- round(L3_bias,2)
L4_bias <- round(L4_bias,2)

L1_sd <- round(L1_sd,2)
L2_sd <- round(L2_sd,2)
L3_sd <- round(L3_sd,2)
L4_sd <- round(L4_sd,2)
#L5_sd <- round(L5_sd,2)

L1_se <- round(L1_se,2)
L2_se <- round(L2_se,2)
L3_se <- round(L3_se,2)
L4_se <- round(L4_se,2)


#L5_bias <- round(L5_bias,2)
# coverage
#load("n_1000_n75_coverage.RData")
L1_cov <- round(all_coverage$L1$coverage,2)
L2_cov <- round(all_coverage$L2$coverage,2)
L3_cov <- round(all_coverage$L3$coverage,2)
L4_cov <- round(all_coverage$L4$coverage,2)
#L5_cov <- round(all_coverage$L5$coverage,2)

df <- 
  data.frame(Method = c("OLS",
                        "OLS with dummies",
                        "MD. Matching",
                        "PS. Matching", 
                        "PS. Weighting"),
             L1_Bias = L1_bias,
             #   L1_sd = L1_sd,
             L1_rmse = L1_rmse,
             L1_cov = L1_cov,
             
             L2_Bias = L2_bias,
             #  L2_sd = L2_sd,
             L2_rmse = L2_rmse,
             L2_cov = L2_cov,
             
             L3_Bias = L3_bias,
             # L3_sd = L3_sd,
             L3_rmse = L3_rmse,
             L3_cov = L3_cov,
             
             L4_Bias = L4_bias,
             # L4_sd = L4_sd,
             L4_rmse = L4_rmse,
             L4_cov = L4_cov)

# L5_Bias = L5_bias,
# #L5_sd = L5_sd,
# L5_rmse = L5_rmse,
# L5_cov = L5_cov
#)
row.names(df) <- NULL
colnames(df) <- NULL
library(xtable)

print.xtable(xtable(df), type = "latex",
             floating = F,include.colnames = F,
             file = paste0(OUT_DIR,"/Section_3_Table_S3_2.tex"))

log_close() # close log
writeLines(readLines(lf))
