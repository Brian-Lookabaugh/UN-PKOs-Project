rm(list=ls())

## please set the working directory
setwd("~/gitrepos/tscs/code/AJPS_tscs_replication/")

## check/create the folder to put outputs
if (file.exists(file.path(getwd(), "output"))){
    OUT_DIR <- file.path(getwd(), "output")
} else {
    dir.create(file.path(file.path(getwd(), "output")))
    OUT_DIR <- file.path(getwd(), "output")
}


## loading packages
library(foreign)
library(DataCombine)
library(multiwayvcov)
library(lmtest)
library(stargazer)
library(plm)
library(pcse)

## This script takes the environment saved in Getting_PanelEstimates.R
load("./PanelMatch_temp2.RData")

## list of variables for creating lagged values
varnames <- c("y", "dem", "logpop", "tradewb", "Populationages014oftotal",
              "Populationages1564oftota", "nfagdp", "unrest")

## creating lagged values (1-4 time periods) for each vars
for(l in 1:4){
  lag <- l
  for(varname in varnames){
    newname <- paste(varname, "_l", lag, sep="")
    cmd <- paste("d2 <- slide(d2, Var = \"", varname, "\", NewVar = \"", newname, "\", slideBy = -",
                 as.character(lag), ", GroupVar = \"wbcode2\"", ", TimeVar = \"year\"", 
                 ")", sep="")
    
    eval(parse(text=cmd))
  }
}

# Column 1 of Table 1
two_way_fe_Ace_con <- lm(y ~ y_l1 + y_l2 + y_l3 + y_l4 + dem + 
                           as.factor(wbcode2) + as.factor(year),
                         data = d2)
m_vcov <- cluster.vcov(two_way_fe_Ace_con, d2$wbcode2) # extracting the clustered variance covoaraince matrix
n1 <- nrow(two_way_fe_Ace_con$model)
# Get the numbers to manually enter 
results_C1 <- coeftest(two_way_fe_Ace_con, m_vcov) # coeftest
results_C1 <- results_C1[c("dem", "y_l1", "y_l2", "y_l3", "y_l4"),
             c("Estimate", "Std. Error")]

# Column 3 of Table 1 

two_way_fe_Ace_con <- lm(y ~ y_l1 + y_l2 + y_l3 + y_l4 + dem + 
                           Populationages014oftotal_l1 + Populationages014oftotal_l2 +
                           Populationages014oftotal_l3 + Populationages014oftotal_l4 +
                           Populationages1564oftota_l1 + Populationages1564oftota_l2 +
                           Populationages1564oftota_l3 + Populationages1564oftota_l4 +
                           unrest_l1 + unrest_l2 + 
                           unrest_l3 + unrest_l4 +
                           tradewb_l1 + tradewb_l2 +
                           tradewb_l3 + tradewb_l4 + 
                           nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 +
                           as.factor(wbcode2) + as.factor(year),
                         data = d2)
m_vcov <- cluster.vcov(two_way_fe_Ace_con, d2$wbcode2) # extracting the clustered variance covoaraince matrix
n3 <- nrow(two_way_fe_Ace_con$model)
# Get the numbers to manually enter 
results_C2 <- coeftest(two_way_fe_Ace_con, m_vcov) # coeftest
results_C2 <- results_C2[c("dem", "y_l1", "y_l2", "y_l3", "y_l4"),
                         c("Estimate", "Std. Error")]

results_table <- data.frame(column_1 = c(t(results_C1)[, "dem"],
                                         t(results_C1)[, "y_l1"],
                                         t(results_C1)[, "y_l2"],
                                         t(results_C1)[, "y_l3"],
                                         t(results_C1)[, "y_l4"],
                                         n1),
                            column_3 = c(t(results_C2)[, "dem"],
                                         t(results_C2)[, "y_l1"],
                                         t(results_C2)[, "y_l2"],
                                         t(results_C2)[, "y_l3"],
                                         t(results_C2)[, "y_l4"],
                                         n3))
row.names(results_table) <- c("ATE_estimate", "ATE_standard_error", 
                              "rho1_estimate", "rho1_standard_error",
                              "rho2_estimate", "rho2_standard_error",
                              "rho3_estimate", "rho3_standard_error",
                              "rho4_estimate", "rho4_standard_error",
                              "N")
library(xtable)
print.xtable(xtable(results_table, 
                    digits = 3), type = "latex",
             
             floating = F,include.colnames = T,
             file = file.path(OUT_DIR,"Columns_1_3_Table1.tex"))
                            


                            
                            

