rm(list=ls())

## please set the working directory
setwd("~/gitrepos/tscs/code/AJPS_tscs_replication/")

## check/create the folder to put outputs
if (file.exists(file.path(getwd(), "output"))){
    OUT_DIR <- file.path(getwd(), "output")
} else {
    dir.create(file.path(file.path(getwd(), "output")))
    OUT_DIR <- file.path(getwd(), "output")
}


## Columns 5 - 8 of Table 1

## loading packages
library(foreign)
library(DataCombine)
library(multiwayvcov)
library(lmtest)
library(stargazer)
library(plm)
library(pcse)

## This script takes the environment saved in Getting_PanelEstimates.R
load("./PanelMatch_temp2.RData")

d3 <- d3[order(d3$ccode, d3$year), ] # reorder d3
d3$ccode <- as.integer(d3$ccode)
d3$year <- as.integer(d3$year)

## First, transform it into pdata.frame
panel.1yr <- pdata.frame(d3, c('ccode','year'))


## Then, we produce results in Columns 7 & 8, which have controls.

# Column 7 two-way FE without lagged DV, cluster standard errors
out.2.1.1 <- plm(topitaxrate2 ~ himobpopyear2pl1 + unisuffragel1 + 
                   leftexec2l1 + rgdppcl1 + australiatrend + 
                   austriatrend + belgiumtrend + canadatrend + 
                   denmarktrend + finlandtrend + francetrend + 
                   germanytrend + irelandtrend + italytrend + 
                   japantrend + koreatrend + netherlandstrend + 
                   newzealandtrend + norwaytrend + swedentrend + 
                   switzerlandtrend + uktrend , model="within", effect="twoways", data=panel.1yr)
n7 <- nrow(out.2.1.1$model)
coeftest(out.2.1.1, vcov.=vcovHC(out.2.1.1, cluster='group', type='HC3'))
results_C7 <- coeftest(out.2.1.1, vcov.=vcovHC(out.2.1.1, cluster='group', type='HC3'))
results_C7 <- results_C7["himobpopyear2pl1" ,c("Estimate", "Std. Error")]

# Column 8, Lagged DV with time FE, Panel-corrected standard errors
temp <- subset(panel.1yr, !is.na(topitaxrate2) & !is.na(topitaxrate2l1) & 
                 !is.na(himobpopyear2pl1) & !is.na(unisuffragel1) & !is.na(leftexec2l1) & !is.na(rgdppcl1))

#
out.2.1.2 <- lm(topitaxrate2 ~ topitaxrate2l1 + himobpopyear2pl1 + 
                  unisuffragel1 + leftexec2l1 + rgdppcl1 + 
                  australiatrend + austriatrend + belgiumtrend + 
                  canadatrend + denmarktrend + finlandtrend + 
                  francetrend + germanytrend + irelandtrend + 
                  italytrend + japantrend + koreatrend + netherlandstrend + 
                  newzealandtrend + norwaytrend + swedentrend + 
                  switzerlandtrend + uktrend + as.factor(year), data=temp)
n8 <- nrow(out.2.1.2$model)
#summary(pcse(out.2.1.2, temp$ccode, as.numeric(as.character(temp$year))))
results_C8 <- pcse(out.2.1.2, temp$ccode, as.numeric(as.character(temp$year)))
results_C8 <- rbind(out.2.1.2$coefficients[c("himobpopyear2pl1", "topitaxrate2l1")],
                    results_C8$pcse[c("himobpopyear2pl1", "topitaxrate2l1")])
## Finally, we produce results in Columns 5 & 6, which don't have controls
# Column 5 two-way FE without lagged DV, cluster standard errors
out.2.1.1 <- plm(topitaxrate2 ~ himobpopyear2pl1 + australiatrend + 
                   austriatrend + belgiumtrend + canadatrend + 
                   denmarktrend + finlandtrend + francetrend + 
                   germanytrend + irelandtrend + italytrend + 
                   japantrend + koreatrend + netherlandstrend + 
                   newzealandtrend + norwaytrend + swedentrend + 
                   switzerlandtrend + uktrend , model="within", effect="twoways", data=panel.1yr)
n5 <- nrow(out.2.1.1$model)
results_C5 <- coeftest(out.2.1.1, vcov.=vcovHC(out.2.1.1, cluster='group', type='HC3'))
results_C5 <- results_C5["himobpopyear2pl1" ,c("Estimate", "Std. Error")]


# Column 6, Lagged DV with time FE, Panel-corrected standard errors
temp <- subset(panel.1yr, !is.na(topitaxrate2) & !is.na(topitaxrate2l1) & 
                 !is.na(himobpopyear2pl1))

#Note the results of the lagged DV model are slightly, but not substantively, different from those obtained in STATA and reported in the paper.
out.2.1.2 <- lm(topitaxrate2 ~ topitaxrate2l1 + himobpopyear2pl1 + 
                  australiatrend + austriatrend + belgiumtrend + 
                  canadatrend + denmarktrend + finlandtrend + 
                  francetrend + germanytrend + irelandtrend + 
                  italytrend + japantrend + koreatrend + netherlandstrend + 
                  newzealandtrend + norwaytrend + swedentrend + 
                  switzerlandtrend + uktrend + as.factor(year), data=temp)
n6 <- nrow(out.2.1.2$model)
results_C6 <- pcse(out.2.1.2, temp$ccode, as.numeric(as.character(temp$year)))
results_C6 <- rbind(out.2.1.2$coefficients[c("himobpopyear2pl1", "topitaxrate2l1")],
      results_C6$pcse[c("himobpopyear2pl1", "topitaxrate2l1")])

results_table <- data.frame(column_5 = c(results_C5, c(NA, NA), n5),
           column_6 = c(results_C6[,1],results_C6[,2], n6),
           column_7 = c(results_C7, c(NA, NA), n7),
           column_8 = c(results_C8[,1],results_C8[,2],n8)
           )
row.names(results_table) <- c("ATE_estimate", "ATE_standard_error", 
                              "rho1_estimate", "rho1_standard_error", "N")

library(xtable)
print.xtable(xtable(results_table,
                    digits = 3), type = "latex",
             floating = F,include.colnames = T,
             file = file.path(OUT_DIR,"Columns_5_8_Table1.tex"))

