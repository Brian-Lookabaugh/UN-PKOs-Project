Steps to perform simulations:
1. Make sure to upload this simulation packet (the .zip file that you have unzipped) to an AWS EC2 instance type “m5d.24xlarge” with volume size set to 1,500 GiB. 
2. Make sure that the instance type has RStudio pre-installed. The version used for the simulations is 1.1.456. 
3. Make sure to have R pre-installed. The R version used for the simulations is 3.4.1 (2017-06-30) -- "Single Candle". 
4. Make sure to have PanelMatch installed. The version used for this paper can be installed by running the following code: “devtools::install_github("insongkim/PanelMatch@80515c5ec486dea7956dab3490171e540d324e92”)”
“devtools::install_github("insongkim/PanelMatch@80515c5ec486dea7956dab3490171e540d324e92”)”
5. Make sure to have R packages "parallel" (the version used for the simulations is 3.4.1) and "dplyr" (the version used for the simulations is 1.0.0) installed. 
6. Open mother_code_50.R and run ALL the codes once.
7. Download n_1000_1_ALL_50.RData, n_1000_05_ALL_50.RData, n_1000_n0_ALL_50.RData, n_1000_n1_ALL_50.RData, n_1000_n05_ALL_50.RData, and n_1000_n75_All_50.RData. Save them into Simulation/All_results of the replication packet. 
8. Restart RStudio session. 
9. Open mother_code.R and run ALL the codes once. 
10. Download n_1000_1_ALL.RData, n_1000_05_ALL.RData, n_1000_n0_ALL.RData, n_1000_n1_ALL.RData, n_1000_n05_ALL.RData, and n_1000_n75_All.RData. Save them into Simulation/All_results of the replication packet. 

