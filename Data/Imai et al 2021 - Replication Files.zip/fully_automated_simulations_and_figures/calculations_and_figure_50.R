# clean slate
library(PanelMatch)
rm(list=ls())
setwd("~/fully_automated_simulations_and_figures/")
source("summary_calc_functions.R")
current.dir <- getwd()
setwd(paste0(current.dir, "/", "simulation_data"))

# TREATMENT_EFFECT_TRUTH = 1
TREATMENT_EFFECT_TRUTH = 1


files.of.interest <- list.files()[grepl("one", list.files())]
list_of_files <- list()
for(file in files.of.interest)
{
  a <- load(file)
  list_of_files[[file]] <- get(a)
}


# a <- load("one_lag_____1cbps.match.estimates.rda")
# a
############## make boxplots
cbps.match.estimates_1 <- unlist(list_of_files[grepl("cbps.match", names(list_of_files))], recursive = F)
cbps.weight.estimates_1 <- unlist(list_of_files[grepl("cbps.weight", names(list_of_files))], recursive = F)
mahalanobis.estimates_1 <- unlist(list_of_files[grepl("maha", names(list_of_files))], recursive = F)

cbps.match.coeffs_1 <- as.numeric(unlist(lapply(cbps.match.estimates_1, function(x) x[[2]]$estimates)))
cbps.weight.coeffs_1 <- as.numeric(unlist(lapply(cbps.weight.estimates_1, function(x) x[[2]]$estimates)))
mahalanobis.coeffs_1 <- as.numeric(unlist(lapply(mahalanobis.estimates_1, function(x) x[[2]]$estimates)))

cbps.match.ses_1 <- as.numeric(unlist(lapply(cbps.match.estimates_1, function(x) x[[2]]$standard.error)))
cbps.weight.ses_1 <- as.numeric(unlist(lapply(cbps.weight.estimates_1, function(x) x[[2]]$standard.error)))
mahalanobis.ses_1 <- as.numeric(unlist(lapply(mahalanobis.estimates_1, function(x) x[[2]]$standard.error)))

cbps.match.balances_1 <- unlist(lapply(cbps.match.estimates_1, function(x) x[[3]]))
cbps.weight.balances_1 <- unlist(lapply(cbps.weight.estimates_1, function(x) x[[3]]))
mahalanobis.balances_1 <- unlist(lapply(mahalanobis.estimates_1, function(x) x[[3]]))

ols.estimates_1 <- as.numeric(unlist(list_of_files[grepl("ols.estimates", names(list_of_files)) & 
                                                     grepl("ols.estimates2", names(list_of_files)) == F], recursive = F))
ols.models_1 <- unlist(list_of_files[grepl("ols.models", names(list_of_files)) & 
                                       grepl("ols.models2", names(list_of_files)) == F], recursive = F)

ols.estimates2_1 <- as.numeric(unlist(list_of_files[grepl("ols.estimates2", names(list_of_files))], recursive = F))
ols.models2_1 <- unlist(list_of_files[grepl("ols.models2", names(list_of_files))], recursive = F)

ols.ses_1 <- as.numeric(sapply(ols.models_1, function (x) summary(x)$coefficients["dem", "Std. Error"]))
ols2.ses_1 <- as.numeric(sapply(ols.models2_1, function (x) summary(x)$coefficients["dem", "Std. Error"]))

############## get another 300 simulations
setwd(paste0(current.dir, "/", "simulation_data_2"))
files.of.interest <- list.files()[grepl("one", list.files())]
list_of_files <- list()
for(file in files.of.interest)
{
  a <- load(file)
  list_of_files[[file]] <- get(a)
}


#mahalanobis.estimates_2[[2]][[2]]
cbps.match.estimates_2 <- unlist(list_of_files[grepl("cbps.match", names(list_of_files))], recursive = F)
cbps.weight.estimates_2 <- unlist(list_of_files[grepl("cbps.weight", names(list_of_files))], recursive = F)
mahalanobis.estimates_2 <- unlist(list_of_files[grepl("maha", names(list_of_files))], recursive = F)

cbps.match.coeffs_2 <- as.numeric(unlist(lapply(cbps.match.estimates_2, function(x) x[[2]]$estimates)))
cbps.weight.coeffs_2 <- as.numeric(unlist(lapply(cbps.weight.estimates_2, function(x) x[[2]]$estimates)))
mahalanobis.coeffs_2 <- as.numeric(unlist(lapply(mahalanobis.estimates_2, function(x) x[[2]]$estimates)))

cbps.match.ses_2 <- as.numeric(unlist(lapply(cbps.match.estimates_2, function(x) x[[2]]$standard.error)))
cbps.weight.ses_2 <- as.numeric(unlist(lapply(cbps.weight.estimates_2, function(x) x[[2]]$standard.error)))
mahalanobis.ses_2 <- as.numeric(unlist(lapply(mahalanobis.estimates_2, function(x) x[[2]]$standard.error)))

cbps.match.balances_2 <- unlist(lapply(cbps.match.estimates_2, function(x) x[[3]]))
cbps.weight.balances_2 <- unlist(lapply(cbps.weight.estimates_2, function(x) x[[3]]))
mahalanobis.balances_2 <- unlist(lapply(mahalanobis.estimates_2, function(x) x[[3]]))

ols.estimates_2 <- as.numeric(unlist(list_of_files[grepl("ols.estimates", names(list_of_files)) & 
                                                     grepl("ols.estimates2", names(list_of_files)) == F], recursive = F))
ols.models_2 <- unlist(list_of_files[grepl("ols.models", names(list_of_files)) & 
                                       grepl("ols.models2", names(list_of_files)) == F], recursive = F)

ols.estimates2_2 <- as.numeric(unlist(list_of_files[grepl("ols.estimates2", names(list_of_files))], recursive = F))
ols.models2_2 <- unlist(list_of_files[grepl("ols.models2", names(list_of_files))], recursive = F)

ols.ses_2 <- as.numeric(sapply(ols.models_2, function (x) summary(x)$coefficients["dem", "Std. Error"]))
ols2.ses_2 <- as.numeric(sapply(ols.models2_2, function (x) summary(x)$coefficients["dem", "Std. Error"]))

############## get another 400 simulations
setwd(paste0(current.dir, "/", "simulation_data_3"))
files.of.interest <- list.files()[grepl("one", list.files())]
list_of_files <- list()
for(file in files.of.interest)
{
  a <- load(file)
  list_of_files[[file]] <- get(a)
}

cbps.match.estimates_3 <- unlist(list_of_files[grepl("cbps.match", names(list_of_files))], recursive = F)
cbps.weight.estimates_3 <- unlist(list_of_files[grepl("cbps.weight", names(list_of_files))], recursive = F)
mahalanobis.estimates_3 <- unlist(list_of_files[grepl("maha", names(list_of_files))], recursive = F)

cbps.match.coeffs_3 <- as.numeric(unlist(lapply(cbps.match.estimates_3, function(x) x[[2]]$estimates)))
cbps.weight.coeffs_3 <- as.numeric(unlist(lapply(cbps.weight.estimates_3, function(x) x[[2]]$estimates)))
mahalanobis.coeffs_3 <- as.numeric(unlist(lapply(mahalanobis.estimates_3, function(x) x[[2]]$estimates)))

cbps.match.ses_3 <- as.numeric(unlist(lapply(cbps.match.estimates_3, function(x) x[[2]]$standard.error)))
cbps.weight.ses_3 <- as.numeric(unlist(lapply(cbps.weight.estimates_3, function(x) x[[2]]$standard.error)))
mahalanobis.ses_3 <- as.numeric(unlist(lapply(mahalanobis.estimates_3, function(x) x[[2]]$standard.error)))

cbps.match.balances_3 <- unlist(lapply(cbps.match.estimates_3, function(x) x[[3]]))
cbps.weight.balances_3 <- unlist(lapply(cbps.weight.estimates_3, function(x) x[[3]]))
mahalanobis.balances_3 <- unlist(lapply(mahalanobis.estimates_3, function(x) x[[3]]))

ols.estimates_3 <- as.numeric(unlist(list_of_files[grepl("ols.estimates", names(list_of_files)) & 
                                                     grepl("ols.estimates2", names(list_of_files)) == F], recursive = F))
ols.models_3 <- unlist(list_of_files[grepl("ols.models", names(list_of_files)) & 
                                       grepl("ols.models2", names(list_of_files)) == F], recursive = F)

ols.estimates2_3 <- as.numeric(unlist(list_of_files[grepl("ols.estimates2", names(list_of_files))], recursive = F))
ols.models2_3 <- unlist(list_of_files[grepl("ols.models2", names(list_of_files))], recursive = F)

ols.ses_3 <- as.numeric(sapply(ols.models_3, function (x) summary(x)$coefficients["dem", "Std. Error"]))
ols2.ses_3 <- as.numeric(sapply(ols.models2_3, function (x) summary(x)$coefficients["dem", "Std. Error"]))

## putting stuff together
ols.estimates <- c(ols.estimates_1, ols.estimates_2, ols.estimates_3)
ols.estimates2 <- c(ols.estimates2_1, ols.estimates2_2, ols.estimates2_3)
ols.ses <- c(ols.ses_1, ols.ses_2, ols.ses_3)
ols.ses2 <- c(ols2.ses_1, ols2.ses_2, ols2.ses_3)
mahalanobis.coeffs <- c(mahalanobis.coeffs_1, mahalanobis.coeffs_2, mahalanobis.coeffs_3)
cbps.match.coeffs <- c(cbps.match.coeffs_1, cbps.match.coeffs_2, cbps.match.coeffs_3)
cbps.weight.coeffs <- c(cbps.weight.coeffs_1, cbps.weight.coeffs_2, cbps.weight.coeffs_3)
mahalanobis.ses <- c(mahalanobis.ses_1, mahalanobis.ses_2, mahalanobis.ses_3)
cbps.match.ses <- c(cbps.match.ses_1, cbps.match.ses_2, cbps.match.ses_3)
cbps.weight.ses <- c(cbps.weight.ses_1, cbps.weight.ses_2, cbps.weight.ses_3)

mahalanobis.balances <- c(mahalanobis.balances_1, mahalanobis.balances_2, mahalanobis.balances_3)
cbps.weight.balances <- c(cbps.weight.balances_1, cbps.weight.balances_2, cbps.weight.balances_3)
cbps.match.balances <- c(cbps.match.balances_1, cbps.match.balances_2, cbps.match.balances_3)

boxplot.ses_l1 <- data.frame(method = c(rep("OLS", length(ols.ses)),
                                        rep("OLS2", length(ols.ses)),
                                        rep("Mahalanobis", length(mahalanobis.ses)),
                                        rep("CBPS Matching", length(cbps.match.ses)),
                                        rep("CBPS Weighting", length(cbps.weight.ses))),
                             estimate = c(ols.ses, ols.ses2, mahalanobis.ses,
                                          cbps.match.ses, cbps.weight.ses))


boxplot.data_l1 <- data.frame(method = c(rep("OLS", length(ols.estimates)),
                                         rep("OLS2", length(ols.estimates)),
                                         rep("Mahalanobis", length(mahalanobis.coeffs)),
                                         rep("CBPS Matching", length(cbps.match.coeffs)),
                                         rep("CBPS Weighting", length(cbps.weight.coeffs))),
                              estimate = c(ols.estimates, ols.estimates2, mahalanobis.coeffs,
                                           cbps.match.coeffs, cbps.weight.coeffs))


#as.numeric(mahalanobis.balances[grepl("L0",names(mahalanobis.balances))])

boxplot.maha.balance_l1 <- data.frame("L" = c(rep("L0", length(mahalanobis.balances)/6),
                                              rep("L1", length(mahalanobis.balances)/6),
                                              rep("L2", length(mahalanobis.balances)/6),
                                              rep("L3", length(mahalanobis.balances)/6),
                                              rep("L4", length(mahalanobis.balances)/6),
                                              rep("L5", length(mahalanobis.balances)/6)),
                                      "balance" = c(as.numeric(mahalanobis.balances[grepl("L0",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L1",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L2",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L3",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L4",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L5",names(mahalanobis.balances))])))

boxplot.cbps.match.balance_l1 <- data.frame("L" = c(rep("L0", length(cbps.match.balances)/6),
                                                    rep("L1", length(cbps.match.balances)/6),
                                                    rep("L2", length(cbps.match.balances)/6),
                                                    rep("L3", length(cbps.match.balances)/6),
                                                    rep("L4", length(cbps.match.balances)/6),
                                                    rep("L5", length(cbps.match.balances)/6)),
                                            "balance" = c(as.numeric(cbps.match.balances[grepl("L0",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L1",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L2",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L3",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L4",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L5",names(cbps.match.balances))])))

boxplot.cbps.weight.balance_l1 <- data.frame("L" = c(rep("L0", length(cbps.weight.balances)/6),
                                                     rep("L1", length(cbps.weight.balances)/6),
                                                     rep("L2", length(cbps.weight.balances)/6),
                                                     rep("L3", length(cbps.weight.balances)/6),
                                                     rep("L4", length(cbps.weight.balances)/6),
                                                     rep("L5", length(cbps.weight.balances)/6)),
                                             "balance" = c(as.numeric(cbps.weight.balances[grepl("L0",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L1",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L2",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L3",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L4",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L5",names(cbps.weight.balances))])))



##calculations


ll1 <- prep_data_for_coverage_calc(list(mahalanobis.estimates_1, mahalanobis.estimates_2, mahalanobis.estimates_3),
                                   list(cbps.match.estimates_1, cbps.match.estimates_2, cbps.match.estimates_3),
                                   list(cbps.weight.estimates_1, cbps.weight.estimates_2, cbps.weight.estimates_3),
                                   list(ols.models_1, ols.models_2, ols.models_3),
                                   list(ols.models2_1, ols.models2_2, ols.models2_3)
)
#maha.list <- list(mahalanobis.estimates_1, mahalanobis.estimates_2, mahalanobis.estimates_3)


coverage_l1 <- find_coverage_calc(true.effect = TREATMENT_EFFECT_TRUTH,
                                  ols.list = ll1[[1]],
                                  ols.list2 = ll1[[2]],
                                  maha.list = ll1[[3]],
                                  cbps.match.list = ll1[[4]],
                                  cbps.weight.list = ll1[[5]])

# bias.calc(TREATMENT_EFFECT_TRUTH, ols.estimates, ols.estimates2, mahalanobis.coeffs, cbps.weight.coeffs, cbps.match.coeffs)
# sd.calc(ols.estimates, ols.estimates2, mahalanobis.coeffs, cbps.weight.coeffs, cbps.match.coeffs)
# rmse.calc(ols.estimates, ols.estimates2, mahalanobis.coeffs, cbps.weight.coeffs, cbps.match.coeffs, TREATMENT_EFFECT_TRUTH)


#L = 2 setup
setwd(paste0(current.dir, "/", "simulation_data"))
files.of.interest <- list.files()[grepl("two", list.files())]
list_of_files <- list()
for(file in files.of.interest)
{
  a <- load(file)
  list_of_files[[file]] <- get(a)
}


############## make boxplots
cbps.match.estimates_1 <- unlist(list_of_files[grepl("cbps.match", names(list_of_files))], recursive = F)
cbps.weight.estimates_1 <- unlist(list_of_files[grepl("cbps.weight", names(list_of_files))], recursive = F)
mahalanobis.estimates_1 <- unlist(list_of_files[grepl("maha", names(list_of_files))], recursive = F)

cbps.match.coeffs_1 <- as.numeric(unlist(lapply(cbps.match.estimates_1, function(x) x[[2]]$estimates)))
cbps.weight.coeffs_1 <- as.numeric(unlist(lapply(cbps.weight.estimates_1, function(x) x[[2]]$estimates)))
mahalanobis.coeffs_1 <- as.numeric(unlist(lapply(mahalanobis.estimates_1, function(x) x[[2]]$estimates)))

cbps.match.ses_1 <- as.numeric(unlist(lapply(cbps.match.estimates_1, function(x) x[[2]]$standard.error)))
cbps.weight.ses_1 <- as.numeric(unlist(lapply(cbps.weight.estimates_1, function(x) x[[2]]$standard.error)))
mahalanobis.ses_1 <- as.numeric(unlist(lapply(mahalanobis.estimates_1, function(x) x[[2]]$standard.error)))

cbps.match.balances_1 <- unlist(lapply(cbps.match.estimates_1, function(x) x[[3]]))
cbps.weight.balances_1 <- unlist(lapply(cbps.weight.estimates_1, function(x) x[[3]]))
mahalanobis.balances_1 <- unlist(lapply(mahalanobis.estimates_1, function(x) x[[3]]))

ols.estimates_1 <- as.numeric(unlist(list_of_files[grepl("ols.estimates", names(list_of_files)) & 
                                                     grepl("ols.estimates2", names(list_of_files)) == F], recursive = F))
ols.models_1 <- unlist(list_of_files[grepl("ols.models", names(list_of_files)) & 
                                       grepl("ols.models2", names(list_of_files)) == F], recursive = F)

ols.estimates2_1 <- as.numeric(unlist(list_of_files[grepl("ols.estimates2", names(list_of_files))], recursive = F))
ols.models2_1 <- unlist(list_of_files[grepl("ols.models2", names(list_of_files))], recursive = F)

ols.ses_1 <- as.numeric(sapply(ols.models_1, function (x) summary(x)$coefficients["dem", "Std. Error"]))
ols2.ses_1 <- as.numeric(sapply(ols.models2_1, function (x) summary(x)$coefficients["dem", "Std. Error"]))


############## get another 300 simulations
setwd(paste0(current.dir, "/", "simulation_data_2"))
files.of.interest <- list.files()[grepl("two", list.files())]
list_of_files <- list()
for(file in files.of.interest)
{
  a <- load(file)
  list_of_files[[file]] <- get(a)
}


#mahalanobis.estimates_2[[2]][[2]]
cbps.match.estimates_2 <- unlist(list_of_files[grepl("cbps.match", names(list_of_files))], recursive = F)
cbps.weight.estimates_2 <- unlist(list_of_files[grepl("cbps.weight", names(list_of_files))], recursive = F)
mahalanobis.estimates_2 <- unlist(list_of_files[grepl("maha", names(list_of_files))], recursive = F)

cbps.match.coeffs_2 <- as.numeric(unlist(lapply(cbps.match.estimates_2, function(x) x[[2]]$estimates)))
cbps.weight.coeffs_2 <- as.numeric(unlist(lapply(cbps.weight.estimates_2, function(x) x[[2]]$estimates)))
mahalanobis.coeffs_2 <- as.numeric(unlist(lapply(mahalanobis.estimates_2, function(x) x[[2]]$estimates)))

cbps.match.ses_2 <- as.numeric(unlist(lapply(cbps.match.estimates_2, function(x) x[[2]]$standard.error)))
cbps.weight.ses_2 <- as.numeric(unlist(lapply(cbps.weight.estimates_2, function(x) x[[2]]$standard.error)))
mahalanobis.ses_2 <- as.numeric(unlist(lapply(mahalanobis.estimates_2, function(x) x[[2]]$standard.error)))

cbps.match.balances_2 <- unlist(lapply(cbps.match.estimates_2, function(x) x[[3]]))
cbps.weight.balances_2 <- unlist(lapply(cbps.weight.estimates_2, function(x) x[[3]]))
mahalanobis.balances_2 <- unlist(lapply(mahalanobis.estimates_2, function(x) x[[3]]))

ols.estimates_2 <- as.numeric(unlist(list_of_files[grepl("ols.estimates", names(list_of_files)) & 
                                                     grepl("ols.estimates2", names(list_of_files)) == F], recursive = F))
ols.models_2 <- unlist(list_of_files[grepl("ols.models", names(list_of_files)) & 
                                       grepl("ols.models2", names(list_of_files)) == F], recursive = F)

ols.estimates2_2 <- as.numeric(unlist(list_of_files[grepl("ols.estimates2", names(list_of_files))], recursive = F))
ols.models2_2 <- unlist(list_of_files[grepl("ols.models2", names(list_of_files))], recursive = F)

ols.ses_2 <- as.numeric(sapply(ols.models_2, function (x) summary(x)$coefficients["dem", "Std. Error"]))
ols2.ses_2 <- as.numeric(sapply(ols.models2_2, function (x) summary(x)$coefficients["dem", "Std. Error"]))


############## get another 400 simulations
setwd(paste0(current.dir, "/", "simulation_data_3"))
files.of.interest <- list.files()[grepl("two", list.files())]
list_of_files <- list()
for(file in files.of.interest)
{
  a <- load(file)
  list_of_files[[file]] <- get(a)
}

cbps.match.estimates_3 <- unlist(list_of_files[grepl("cbps.match", names(list_of_files))], recursive = F)
cbps.weight.estimates_3 <- unlist(list_of_files[grepl("cbps.weight", names(list_of_files))], recursive = F)
mahalanobis.estimates_3 <- unlist(list_of_files[grepl("maha", names(list_of_files))], recursive = F)

cbps.match.coeffs_3 <- as.numeric(unlist(lapply(cbps.match.estimates_3, function(x) x[[2]]$estimates)))
cbps.weight.coeffs_3 <- as.numeric(unlist(lapply(cbps.weight.estimates_3, function(x) x[[2]]$estimates)))
mahalanobis.coeffs_3 <- as.numeric(unlist(lapply(mahalanobis.estimates_3, function(x) x[[2]]$estimates)))

cbps.match.ses_3 <- as.numeric(unlist(lapply(cbps.match.estimates_3, function(x) x[[2]]$standard.error)))
cbps.weight.ses_3 <- as.numeric(unlist(lapply(cbps.weight.estimates_3, function(x) x[[2]]$standard.error)))
mahalanobis.ses_3 <- as.numeric(unlist(lapply(mahalanobis.estimates_3, function(x) x[[2]]$standard.error)))

cbps.match.balances_3 <- unlist(lapply(cbps.match.estimates_3, function(x) x[[3]]))
cbps.weight.balances_3 <- unlist(lapply(cbps.weight.estimates_3, function(x) x[[3]]))
mahalanobis.balances_3 <- unlist(lapply(mahalanobis.estimates_3, function(x) x[[3]]))

ols.estimates_3 <- as.numeric(unlist(list_of_files[grepl("ols.estimates", names(list_of_files)) & 
                                                     grepl("ols.estimates2", names(list_of_files)) == F], recursive = F))
ols.models_3 <- unlist(list_of_files[grepl("ols.models", names(list_of_files)) & 
                                       grepl("ols.models2", names(list_of_files)) == F], recursive = F)

ols.estimates2_3 <- as.numeric(unlist(list_of_files[grepl("ols.estimates2", names(list_of_files))], recursive = F))
ols.models2_3 <- unlist(list_of_files[grepl("ols.models2", names(list_of_files))], recursive = F)

ols.ses_3 <- as.numeric(sapply(ols.models_3, function (x) summary(x)$coefficients["dem", "Std. Error"]))
ols2.ses_3 <- as.numeric(sapply(ols.models2_3, function (x) summary(x)$coefficients["dem", "Std. Error"]))


## putting stuff together
ols.estimates <- c(ols.estimates_1, ols.estimates_2, ols.estimates_3)
ols.estimates2 <- c(ols.estimates2_1, ols.estimates2_2, ols.estimates2_3)
ols.ses <- c(ols.ses_1, ols.ses_2, ols.ses_3)
ols.ses2 <- c(ols2.ses_1, ols2.ses_2, ols2.ses_3)
mahalanobis.coeffs <- c(mahalanobis.coeffs_1, mahalanobis.coeffs_2, mahalanobis.coeffs_3)
cbps.match.coeffs <- c(cbps.match.coeffs_1, cbps.match.coeffs_2, cbps.match.coeffs_3)
cbps.weight.coeffs <- c(cbps.weight.coeffs_1, cbps.weight.coeffs_2, cbps.weight.coeffs_3)
mahalanobis.ses <- c(mahalanobis.ses_1, mahalanobis.ses_2, mahalanobis.ses_3)
cbps.match.ses <- c(cbps.match.ses_1, cbps.match.ses_2, cbps.match.ses_3)
cbps.weight.ses <- c(cbps.weight.ses_1, cbps.weight.ses_2, cbps.weight.ses_3)

mahalanobis.balances <- c(mahalanobis.balances_1, mahalanobis.balances_2, mahalanobis.balances_3)
cbps.weight.balances <- c(cbps.weight.balances_1, cbps.weight.balances_2, cbps.weight.balances_3)
cbps.match.balances <- c(cbps.match.balances_1, cbps.match.balances_2, cbps.match.balances_3)

boxplot.ses_l2 <- data.frame(method = c(rep("OLS", length(ols.ses)),
                                        rep("OLS2", length(ols.ses)),
                                        rep("Mahalanobis", length(mahalanobis.ses)),
                                        rep("CBPS Matching", length(cbps.match.ses)),
                                        rep("CBPS Weighting", length(cbps.weight.ses))),
                             estimate = c(ols.ses, ols.ses2, mahalanobis.ses,
                                          cbps.match.ses, cbps.weight.ses))

boxplot.data_l2 <- data.frame(method = c(rep("OLS", length(ols.estimates)),
                                         rep("OLS2", length(ols.estimates)),
                                         rep("Mahalanobis", length(mahalanobis.coeffs)),
                                         rep("CBPS Matching", length(cbps.match.coeffs)),
                                         rep("CBPS Weighting", length(cbps.weight.coeffs))),
                              estimate = c(ols.estimates, ols.estimates2, mahalanobis.coeffs,
                                           cbps.match.coeffs, cbps.weight.coeffs))


boxplot.maha.balance_l2 <- data.frame("L" = c(rep("L0", length(mahalanobis.balances)/6),
                                              rep("L1", length(mahalanobis.balances)/6),
                                              rep("L2", length(mahalanobis.balances)/6),
                                              rep("L3", length(mahalanobis.balances)/6),
                                              rep("L4", length(mahalanobis.balances)/6),
                                              rep("L5", length(mahalanobis.balances)/6)),
                                      "balance" = c(as.numeric(mahalanobis.balances[grepl("L0",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L1",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L2",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L3",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L4",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L5",names(mahalanobis.balances))])))

boxplot.cbps.match.balance_l2 <- data.frame("L" = c(rep("L0", length(cbps.match.balances)/6),
                                                    rep("L1", length(cbps.match.balances)/6),
                                                    rep("L2", length(cbps.match.balances)/6),
                                                    rep("L3", length(cbps.match.balances)/6),
                                                    rep("L4", length(cbps.match.balances)/6),
                                                    rep("L5", length(cbps.match.balances)/6)),
                                            "balance" = c(as.numeric(cbps.match.balances[grepl("L0",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L1",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L2",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L3",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L4",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L5",names(cbps.match.balances))])))

boxplot.cbps.weight.balance_l2 <- data.frame("L" = c(rep("L0", length(cbps.weight.balances)/6),
                                                     rep("L1", length(cbps.weight.balances)/6),
                                                     rep("L2", length(cbps.weight.balances)/6),
                                                     rep("L3", length(cbps.weight.balances)/6),
                                                     rep("L4", length(cbps.weight.balances)/6),
                                                     rep("L5", length(cbps.weight.balances)/6)),
                                             "balance" = c(as.numeric(cbps.weight.balances[grepl("L0",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L1",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L2",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L3",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L4",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L5",names(cbps.weight.balances))])))



##calculations


ll <- prep_data_for_coverage_calc(list(mahalanobis.estimates_1, mahalanobis.estimates_2, mahalanobis.estimates_3),
                                  list(cbps.match.estimates_1, cbps.match.estimates_2, cbps.match.estimates_3),
                                  list(cbps.weight.estimates_1, cbps.weight.estimates_2, cbps.weight.estimates_3),
                                  list(ols.models_1, ols.models_2, ols.models_3),
                                  list(ols.models2_1, ols.models2_2, ols.models2_3)
)
#maha.list <- list(mahalanobis.estimates_1, mahalanobis.estimates_2, mahalanobis.estimates_3)


coverage_l2 <- find_coverage_calc(true.effect = TREATMENT_EFFECT_TRUTH,
                                  ols.list = ll[[1]],
                                  ols.list2 = ll[[2]],
                                  maha.list = ll[[3]],
                                  cbps.match.list = ll[[4]],
                                  cbps.weight.list = ll[[5]])

# bias.calc(TREATMENT_EFFECT_TRUTH, ols.estimates, ols.estimates2, mahalanobis.coeffs, cbps.weight.coeffs, cbps.match.coeffs)
# sd.calc(ols.estimates, ols.estimates2, mahalanobis.coeffs, cbps.weight.coeffs, cbps.match.coeffs)
# rmse.calc(ols.estimates, ols.estimates2, mahalanobis.coeffs, cbps.weight.coeffs, cbps.match.coeffs, TREATMENT_EFFECT_TRUTH)



#L = 3 setup
setwd(paste0(current.dir, "/", "simulation_data"))
files.of.interest <- list.files()[grepl("three", list.files())]
list_of_files <- list()
for(file in files.of.interest)
{
  a <- load(file)
  list_of_files[[file]] <- get(a)
}


############## make boxplots
cbps.match.estimates_1 <- unlist(list_of_files[grepl("cbps.match", names(list_of_files))], recursive = F)
cbps.weight.estimates_1 <- unlist(list_of_files[grepl("cbps.weight", names(list_of_files))], recursive = F)
mahalanobis.estimates_1 <- unlist(list_of_files[grepl("maha", names(list_of_files))], recursive = F)

cbps.match.coeffs_1 <- as.numeric(unlist(lapply(cbps.match.estimates_1, function(x) x[[2]]$estimates)))
cbps.weight.coeffs_1 <- as.numeric(unlist(lapply(cbps.weight.estimates_1, function(x) x[[2]]$estimates)))
mahalanobis.coeffs_1 <- as.numeric(unlist(lapply(mahalanobis.estimates_1, function(x) x[[2]]$estimates)))

cbps.match.ses_1 <- as.numeric(unlist(lapply(cbps.match.estimates_1, function(x) x[[2]]$standard.error)))
cbps.weight.ses_1 <- as.numeric(unlist(lapply(cbps.weight.estimates_1, function(x) x[[2]]$standard.error)))
mahalanobis.ses_1 <- as.numeric(unlist(lapply(mahalanobis.estimates_1, function(x) x[[2]]$standard.error)))

cbps.match.balances_1 <- unlist(lapply(cbps.match.estimates_1, function(x) x[[3]]))
cbps.weight.balances_1 <- unlist(lapply(cbps.weight.estimates_1, function(x) x[[3]]))
mahalanobis.balances_1 <- unlist(lapply(mahalanobis.estimates_1, function(x) x[[3]]))

ols.estimates_1 <- as.numeric(unlist(list_of_files[grepl("ols.estimates", names(list_of_files)) & 
                                                     grepl("ols.estimates2", names(list_of_files)) == F], recursive = F))
ols.models_1 <- unlist(list_of_files[grepl("ols.models", names(list_of_files)) & 
                                       grepl("ols.models2", names(list_of_files)) == F], recursive = F)

ols.estimates2_1 <- as.numeric(unlist(list_of_files[grepl("ols.estimates2", names(list_of_files))], recursive = F))
ols.models2_1 <- unlist(list_of_files[grepl("ols.models2", names(list_of_files))], recursive = F)

ols.ses_1 <- as.numeric(sapply(ols.models_1, function (x) summary(x)$coefficients["dem", "Std. Error"]))
ols2.ses_1 <- as.numeric(sapply(ols.models2_1, function (x) summary(x)$coefficients["dem", "Std. Error"]))


############## get another 300 simulations
setwd(paste0(current.dir, "/", "simulation_data_2"))
files.of.interest <- list.files()[grepl("three", list.files())]
list_of_files <- list()
for(file in files.of.interest)
{
  a <- load(file)
  list_of_files[[file]] <- get(a)
}


#mahalanobis.estimates_2[[2]][[2]]
cbps.match.estimates_2 <- unlist(list_of_files[grepl("cbps.match", names(list_of_files))], recursive = F)
cbps.weight.estimates_2 <- unlist(list_of_files[grepl("cbps.weight", names(list_of_files))], recursive = F)
mahalanobis.estimates_2 <- unlist(list_of_files[grepl("maha", names(list_of_files))], recursive = F)

cbps.match.coeffs_2 <- as.numeric(unlist(lapply(cbps.match.estimates_2, function(x) x[[2]]$estimates)))
cbps.weight.coeffs_2 <- as.numeric(unlist(lapply(cbps.weight.estimates_2, function(x) x[[2]]$estimates)))
mahalanobis.coeffs_2 <- as.numeric(unlist(lapply(mahalanobis.estimates_2, function(x) x[[2]]$estimates)))

cbps.match.ses_2 <- as.numeric(unlist(lapply(cbps.match.estimates_2, function(x) x[[2]]$standard.error)))
cbps.weight.ses_2 <- as.numeric(unlist(lapply(cbps.weight.estimates_2, function(x) x[[2]]$standard.error)))
mahalanobis.ses_2 <- as.numeric(unlist(lapply(mahalanobis.estimates_2, function(x) x[[2]]$standard.error)))

cbps.match.balances_2 <- unlist(lapply(cbps.match.estimates_2, function(x) x[[3]]))
cbps.weight.balances_2 <- unlist(lapply(cbps.weight.estimates_2, function(x) x[[3]]))
mahalanobis.balances_2 <- unlist(lapply(mahalanobis.estimates_2, function(x) x[[3]]))

ols.estimates_2 <- as.numeric(unlist(list_of_files[grepl("ols.estimates", names(list_of_files)) & 
                                                     grepl("ols.estimates2", names(list_of_files)) == F], recursive = F))
ols.models_2 <- unlist(list_of_files[grepl("ols.models", names(list_of_files)) & 
                                       grepl("ols.models2", names(list_of_files)) == F], recursive = F)

ols.estimates2_2 <- as.numeric(unlist(list_of_files[grepl("ols.estimates2", names(list_of_files))], recursive = F))
ols.models2_2 <- unlist(list_of_files[grepl("ols.models2", names(list_of_files))], recursive = F)

ols.ses_2 <- as.numeric(sapply(ols.models_2, function (x) summary(x)$coefficients["dem", "Std. Error"]))
ols2.ses_2 <- as.numeric(sapply(ols.models2_2, function (x) summary(x)$coefficients["dem", "Std. Error"]))


############## get another 400 simulations
setwd(paste0(current.dir, "/", "simulation_data_3"))
files.of.interest <- list.files()[grepl("three", list.files())]
list_of_files <- list()
for(file in files.of.interest)
{
  a <- load(file)
  list_of_files[[file]] <- get(a)
}

cbps.match.estimates_3 <- unlist(list_of_files[grepl("cbps.match", names(list_of_files))], recursive = F)
cbps.weight.estimates_3 <- unlist(list_of_files[grepl("cbps.weight", names(list_of_files))], recursive = F)
mahalanobis.estimates_3 <- unlist(list_of_files[grepl("maha", names(list_of_files))], recursive = F)

cbps.match.coeffs_3 <- as.numeric(unlist(lapply(cbps.match.estimates_3, function(x) x[[2]]$estimates)))
cbps.weight.coeffs_3 <- as.numeric(unlist(lapply(cbps.weight.estimates_3, function(x) x[[2]]$estimates)))
mahalanobis.coeffs_3 <- as.numeric(unlist(lapply(mahalanobis.estimates_3, function(x) x[[2]]$estimates)))

cbps.match.ses_3 <- as.numeric(unlist(lapply(cbps.match.estimates_3, function(x) x[[2]]$standard.error)))
cbps.weight.ses_3 <- as.numeric(unlist(lapply(cbps.weight.estimates_3, function(x) x[[2]]$standard.error)))
mahalanobis.ses_3 <- as.numeric(unlist(lapply(mahalanobis.estimates_3, function(x) x[[2]]$standard.error)))

cbps.match.balances_3 <- unlist(lapply(cbps.match.estimates_3, function(x) x[[3]]))
cbps.weight.balances_3 <- unlist(lapply(cbps.weight.estimates_3, function(x) x[[3]]))
mahalanobis.balances_3 <- unlist(lapply(mahalanobis.estimates_3, function(x) x[[3]]))

ols.estimates_3 <- as.numeric(unlist(list_of_files[grepl("ols.estimates", names(list_of_files)) & 
                                                     grepl("ols.estimates2", names(list_of_files)) == F], recursive = F))
ols.models_3 <- unlist(list_of_files[grepl("ols.models", names(list_of_files)) & 
                                       grepl("ols.models2", names(list_of_files)) == F], recursive = F)

ols.estimates2_3 <- as.numeric(unlist(list_of_files[grepl("ols.estimates2", names(list_of_files))], recursive = F))
ols.models2_3 <- unlist(list_of_files[grepl("ols.models2", names(list_of_files))], recursive = F)

ols.ses_3 <- as.numeric(sapply(ols.models_3, function (x) summary(x)$coefficients["dem", "Std. Error"]))
ols2.ses_3 <- as.numeric(sapply(ols.models2_3, function (x) summary(x)$coefficients["dem", "Std. Error"]))


## putting stuff together
ols.estimates <- c(ols.estimates_1, ols.estimates_2, ols.estimates_3)
ols.estimates2 <- c(ols.estimates2_1, ols.estimates2_2, ols.estimates2_3)
ols.ses <- c(ols.ses_1, ols.ses_2, ols.ses_3)
ols.ses2 <- c(ols2.ses_1, ols2.ses_2, ols2.ses_3)
mahalanobis.coeffs <- c(mahalanobis.coeffs_1, mahalanobis.coeffs_2, mahalanobis.coeffs_3)
cbps.match.coeffs <- c(cbps.match.coeffs_1, cbps.match.coeffs_2, cbps.match.coeffs_3)
cbps.weight.coeffs <- c(cbps.weight.coeffs_1, cbps.weight.coeffs_2, cbps.weight.coeffs_3)
mahalanobis.ses <- c(mahalanobis.ses_1, mahalanobis.ses_2, mahalanobis.ses_3)
cbps.match.ses <- c(cbps.match.ses_1, cbps.match.ses_2, cbps.match.ses_3)
cbps.weight.ses <- c(cbps.weight.ses_1, cbps.weight.ses_2, cbps.weight.ses_3)

mahalanobis.balances <- c(mahalanobis.balances_1, mahalanobis.balances_2, mahalanobis.balances_3)
cbps.weight.balances <- c(cbps.weight.balances_1, cbps.weight.balances_2, cbps.weight.balances_3)
cbps.match.balances <- c(cbps.match.balances_1, cbps.match.balances_2, cbps.match.balances_3)

boxplot.ses_l3 <- data.frame(method = c(rep("OLS", length(ols.ses)),
                                        rep("OLS2", length(ols.ses)),
                                        rep("Mahalanobis", length(mahalanobis.ses)),
                                        rep("CBPS Matching", length(cbps.match.ses)),
                                        rep("CBPS Weighting", length(cbps.weight.ses))),
                             estimate = c(ols.ses, ols.ses2, mahalanobis.ses,
                                          cbps.match.ses, cbps.weight.ses))

boxplot.data_l3 <- data.frame(method = c(rep("OLS", length(ols.estimates)),
                                         rep("OLS2", length(ols.estimates)),
                                         rep("Mahalanobis", length(mahalanobis.coeffs)),
                                         rep("CBPS Matching", length(cbps.match.coeffs)),
                                         rep("CBPS Weighting", length(cbps.weight.coeffs))),
                              estimate = c(ols.estimates, ols.estimates2, mahalanobis.coeffs,
                                           cbps.match.coeffs, cbps.weight.coeffs))


boxplot.maha.balance_l3 <- data.frame("L" = c(rep("L0", length(mahalanobis.balances)/6),
                                              rep("L1", length(mahalanobis.balances)/6),
                                              rep("L2", length(mahalanobis.balances)/6),
                                              rep("L3", length(mahalanobis.balances)/6),
                                              rep("L4", length(mahalanobis.balances)/6),
                                              rep("L5", length(mahalanobis.balances)/6)),
                                      "balance" = c(as.numeric(mahalanobis.balances[grepl("L0",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L1",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L2",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L3",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L4",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L5",names(mahalanobis.balances))])))

boxplot.cbps.match.balance_l3 <- data.frame("L" = c(rep("L0", length(cbps.match.balances)/6),
                                                    rep("L1", length(cbps.match.balances)/6),
                                                    rep("L2", length(cbps.match.balances)/6),
                                                    rep("L3", length(cbps.match.balances)/6),
                                                    rep("L4", length(cbps.match.balances)/6),
                                                    rep("L5", length(cbps.match.balances)/6)),
                                            "balance" = c(as.numeric(cbps.match.balances[grepl("L0",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L1",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L2",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L3",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L4",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L5",names(cbps.match.balances))])))

boxplot.cbps.weight.balance_l3 <- data.frame("L" = c(rep("L0", length(cbps.weight.balances)/6),
                                                     rep("L1", length(cbps.weight.balances)/6),
                                                     rep("L2", length(cbps.weight.balances)/6),
                                                     rep("L3", length(cbps.weight.balances)/6),
                                                     rep("L4", length(cbps.weight.balances)/6),
                                                     rep("L5", length(cbps.weight.balances)/6)),
                                             "balance" = c(as.numeric(cbps.weight.balances[grepl("L0",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L1",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L2",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L3",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L4",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L5",names(cbps.weight.balances))])))



##calculations


ll <- prep_data_for_coverage_calc(list(mahalanobis.estimates_1, mahalanobis.estimates_2, mahalanobis.estimates_3),
                                  list(cbps.match.estimates_1, cbps.match.estimates_2, cbps.match.estimates_3),
                                  list(cbps.weight.estimates_1, cbps.weight.estimates_2, cbps.weight.estimates_3),
                                  list(ols.models_1, ols.models_2, ols.models_3),
                                  list(ols.models2_1, ols.models2_2, ols.models2_3)
)


coverage_l3 <- find_coverage_calc(true.effect = TREATMENT_EFFECT_TRUTH,
                                  ols.list = ll[[1]],
                                  ols.list2 = ll[[2]],
                                  maha.list = ll[[3]],
                                  cbps.match.list = ll[[4]],
                                  cbps.weight.list = ll[[5]])

# bias.calc(TREATMENT_EFFECT_TRUTH, ols.estimates,ols.estimates2, mahalanobis.coeffs, cbps.weight.coeffs, cbps.match.coeffs)
# sd.calc(ols.estimates, ols.estimates2, mahalanobis.coeffs, cbps.weight.coeffs, cbps.match.coeffs)
# rmse.calc(ols.estimates, ols.estimates2, mahalanobis.coeffs, cbps.weight.coeffs, cbps.match.coeffs, TREATMENT_EFFECT_TRUTH)


#L = 4 setup
setwd(paste0(current.dir, "/", "simulation_data"))
files.of.interest <- list.files()[grepl("four", list.files())]
list_of_files <- list()
for(file in files.of.interest)
{
  a <- load(file)
  list_of_files[[file]] <- get(a)
}


############## make boxplots
cbps.match.estimates_1 <- unlist(list_of_files[grepl("cbps.match", names(list_of_files))], recursive = F)
cbps.weight.estimates_1 <- unlist(list_of_files[grepl("cbps.weight", names(list_of_files))], recursive = F)
mahalanobis.estimates_1 <- unlist(list_of_files[grepl("maha", names(list_of_files))], recursive = F)

cbps.match.coeffs_1 <- as.numeric(unlist(lapply(cbps.match.estimates_1, function(x) x[[2]]$estimates)))
cbps.weight.coeffs_1 <- as.numeric(unlist(lapply(cbps.weight.estimates_1, function(x) x[[2]]$estimates)))
mahalanobis.coeffs_1 <- as.numeric(unlist(lapply(mahalanobis.estimates_1, function(x) x[[2]]$estimates)))

cbps.match.ses_1 <- as.numeric(unlist(lapply(cbps.match.estimates_1, function(x) x[[2]]$standard.error)))
cbps.weight.ses_1 <- as.numeric(unlist(lapply(cbps.weight.estimates_1, function(x) x[[2]]$standard.error)))
mahalanobis.ses_1 <- as.numeric(unlist(lapply(mahalanobis.estimates_1, function(x) x[[2]]$standard.error)))

cbps.match.balances_1 <- unlist(lapply(cbps.match.estimates_1, function(x) x[[3]]))
cbps.weight.balances_1 <- unlist(lapply(cbps.weight.estimates_1, function(x) x[[3]]))
mahalanobis.balances_1 <- unlist(lapply(mahalanobis.estimates_1, function(x) x[[3]]))

ols.estimates_1 <- as.numeric(unlist(list_of_files[grepl("ols.estimates", names(list_of_files)) & 
                                                     grepl("ols.estimates2", names(list_of_files)) == F], recursive = F))
ols.models_1 <- unlist(list_of_files[grepl("ols.models", names(list_of_files)) & 
                                       grepl("ols.models2", names(list_of_files)) == F], recursive = F)

ols.estimates2_1 <- as.numeric(unlist(list_of_files[grepl("ols.estimates2", names(list_of_files))], recursive = F))
ols.models2_1 <- unlist(list_of_files[grepl("ols.models2", names(list_of_files))], recursive = F)

ols.ses_1 <- as.numeric(sapply(ols.models_1, function (x) summary(x)$coefficients["dem", "Std. Error"]))
ols2.ses_1 <- as.numeric(sapply(ols.models2_1, function (x) summary(x)$coefficients["dem", "Std. Error"]))


############## get another 300 simulations
setwd(paste0(current.dir, "/", "simulation_data_2"))
files.of.interest <- list.files()[grepl("four", list.files())]
list_of_files <- list()
for(file in files.of.interest)
{
  a <- load(file)
  list_of_files[[file]] <- get(a)
}


#mahalanobis.estimates_2[[2]][[2]]
cbps.match.estimates_2 <- unlist(list_of_files[grepl("cbps.match", names(list_of_files))], recursive = F)
cbps.weight.estimates_2 <- unlist(list_of_files[grepl("cbps.weight", names(list_of_files))], recursive = F)
mahalanobis.estimates_2 <- unlist(list_of_files[grepl("maha", names(list_of_files))], recursive = F)

cbps.match.coeffs_2 <- as.numeric(unlist(lapply(cbps.match.estimates_2, function(x) x[[2]]$estimates)))
cbps.weight.coeffs_2 <- as.numeric(unlist(lapply(cbps.weight.estimates_2, function(x) x[[2]]$estimates)))
mahalanobis.coeffs_2 <- as.numeric(unlist(lapply(mahalanobis.estimates_2, function(x) x[[2]]$estimates)))

cbps.match.ses_2 <- as.numeric(unlist(lapply(cbps.match.estimates_2, function(x) x[[2]]$standard.error)))
cbps.weight.ses_2 <- as.numeric(unlist(lapply(cbps.weight.estimates_2, function(x) x[[2]]$standard.error)))
mahalanobis.ses_2 <- as.numeric(unlist(lapply(mahalanobis.estimates_2, function(x) x[[2]]$standard.error)))

cbps.match.balances_2 <- unlist(lapply(cbps.match.estimates_2, function(x) x[[3]]))
cbps.weight.balances_2 <- unlist(lapply(cbps.weight.estimates_2, function(x) x[[3]]))
mahalanobis.balances_2 <- unlist(lapply(mahalanobis.estimates_2, function(x) x[[3]]))

ols.estimates_2 <- as.numeric(unlist(list_of_files[grepl("ols.estimates", names(list_of_files)) & 
                                                     grepl("ols.estimates2", names(list_of_files)) == F], recursive = F))
ols.models_2 <- unlist(list_of_files[grepl("ols.models", names(list_of_files)) & 
                                       grepl("ols.models2", names(list_of_files)) == F], recursive = F)

ols.estimates2_2 <- as.numeric(unlist(list_of_files[grepl("ols.estimates2", names(list_of_files))], recursive = F))
ols.models2_2 <- unlist(list_of_files[grepl("ols.models2", names(list_of_files))], recursive = F)

ols.ses_2 <- as.numeric(sapply(ols.models_2, function (x) summary(x)$coefficients["dem", "Std. Error"]))
ols2.ses_2 <- as.numeric(sapply(ols.models2_2, function (x) summary(x)$coefficients["dem", "Std. Error"]))


############## get another 400 simulations
setwd(paste0(current.dir, "/", "simulation_data_3"))
files.of.interest <- list.files()[grepl("four", list.files())]
list_of_files <- list()
for(file in files.of.interest)
{
  a <- load(file)
  list_of_files[[file]] <- get(a)
}

cbps.match.estimates_3 <- unlist(list_of_files[grepl("cbps.match", names(list_of_files))], recursive = F)
cbps.weight.estimates_3 <- unlist(list_of_files[grepl("cbps.weight", names(list_of_files))], recursive = F)
mahalanobis.estimates_3 <- unlist(list_of_files[grepl("maha", names(list_of_files))], recursive = F)

cbps.match.coeffs_3 <- as.numeric(unlist(lapply(cbps.match.estimates_3, function(x) x[[2]]$estimates)))
cbps.weight.coeffs_3 <- as.numeric(unlist(lapply(cbps.weight.estimates_3, function(x) x[[2]]$estimates)))
mahalanobis.coeffs_3 <- as.numeric(unlist(lapply(mahalanobis.estimates_3, function(x) x[[2]]$estimates)))

cbps.match.ses_3 <- as.numeric(unlist(lapply(cbps.match.estimates_3, function(x) x[[2]]$standard.error)))
cbps.weight.ses_3 <- as.numeric(unlist(lapply(cbps.weight.estimates_3, function(x) x[[2]]$standard.error)))
mahalanobis.ses_3 <- as.numeric(unlist(lapply(mahalanobis.estimates_3, function(x) x[[2]]$standard.error)))

cbps.match.balances_3 <- unlist(lapply(cbps.match.estimates_3, function(x) x[[3]]))
cbps.weight.balances_3 <- unlist(lapply(cbps.weight.estimates_3, function(x) x[[3]]))
mahalanobis.balances_3 <- unlist(lapply(mahalanobis.estimates_3, function(x) x[[3]]))

ols.estimates_3 <- as.numeric(unlist(list_of_files[grepl("ols.estimates", names(list_of_files)) & 
                                                     grepl("ols.estimates2", names(list_of_files)) == F], recursive = F))
ols.models_3 <- unlist(list_of_files[grepl("ols.models", names(list_of_files)) & 
                                       grepl("ols.models2", names(list_of_files)) == F], recursive = F)

ols.estimates2_3 <- as.numeric(unlist(list_of_files[grepl("ols.estimates2", names(list_of_files))], recursive = F))
ols.models2_3 <- unlist(list_of_files[grepl("ols.models2", names(list_of_files))], recursive = F)

ols.ses_3 <- as.numeric(sapply(ols.models_3, function (x) summary(x)$coefficients["dem", "Std. Error"]))
ols2.ses_3 <- as.numeric(sapply(ols.models2_3, function (x) summary(x)$coefficients["dem", "Std. Error"]))


## putting stuff together
ols.estimates <- c(ols.estimates_1, ols.estimates_2, ols.estimates_3)
ols.estimates2 <- c(ols.estimates2_1, ols.estimates2_2, ols.estimates2_3)
ols.ses <- c(ols.ses_1, ols.ses_2, ols.ses_3)
ols.ses2 <- c(ols2.ses_1, ols2.ses_2, ols2.ses_3)
mahalanobis.coeffs <- c(mahalanobis.coeffs_1, mahalanobis.coeffs_2, mahalanobis.coeffs_3)
cbps.match.coeffs <- c(cbps.match.coeffs_1, cbps.match.coeffs_2, cbps.match.coeffs_3)
cbps.weight.coeffs <- c(cbps.weight.coeffs_1, cbps.weight.coeffs_2, cbps.weight.coeffs_3)
mahalanobis.ses <- c(mahalanobis.ses_1, mahalanobis.ses_2, mahalanobis.ses_3)
cbps.match.ses <- c(cbps.match.ses_1, cbps.match.ses_2, cbps.match.ses_3)
cbps.weight.ses <- c(cbps.weight.ses_1, cbps.weight.ses_2, cbps.weight.ses_3)

mahalanobis.balances <- c(mahalanobis.balances_1, mahalanobis.balances_2, mahalanobis.balances_3)
cbps.weight.balances <- c(cbps.weight.balances_1, cbps.weight.balances_2, cbps.weight.balances_3)
cbps.match.balances <- c(cbps.match.balances_1, cbps.match.balances_2, cbps.match.balances_3)

boxplot.ses_l4 <- data.frame(method = c(rep("OLS", length(ols.ses)),
                                        rep("OLS2", length(ols.ses)),
                                        rep("Mahalanobis", length(mahalanobis.ses)),
                                        rep("CBPS Matching", length(cbps.match.ses)),
                                        rep("CBPS Weighting", length(cbps.weight.ses))),
                             estimate = c(ols.ses, ols.ses2, mahalanobis.ses,
                                          cbps.match.ses, cbps.weight.ses))

boxplot.data_l4 <- data.frame(method = c(rep("OLS", length(ols.estimates)),
                                         rep("OLS2", length(ols.estimates)),
                                         rep("Mahalanobis", length(mahalanobis.coeffs)),
                                         rep("CBPS Matching", length(cbps.match.coeffs)),
                                         rep("CBPS Weighting", length(cbps.weight.coeffs))),
                              estimate = c(ols.estimates, ols.estimates2, mahalanobis.coeffs,
                                           cbps.match.coeffs, cbps.weight.coeffs))


boxplot.maha.balance_l4 <- data.frame("L" = c(rep("L0", length(mahalanobis.balances)/6),
                                              rep("L1", length(mahalanobis.balances)/6),
                                              rep("L2", length(mahalanobis.balances)/6),
                                              rep("L3", length(mahalanobis.balances)/6),
                                              rep("L4", length(mahalanobis.balances)/6),
                                              rep("L5", length(mahalanobis.balances)/6)),
                                      "balance" = c(as.numeric(mahalanobis.balances[grepl("L0",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L1",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L2",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L3",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L4",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L5",names(mahalanobis.balances))])))

boxplot.cbps.match.balance_l4 <- data.frame("L" = c(rep("L0", length(cbps.match.balances)/6),
                                                    rep("L1", length(cbps.match.balances)/6),
                                                    rep("L2", length(cbps.match.balances)/6),
                                                    rep("L3", length(cbps.match.balances)/6),
                                                    rep("L4", length(cbps.match.balances)/6),
                                                    rep("L5", length(cbps.match.balances)/6)),
                                            "balance" = c(as.numeric(cbps.match.balances[grepl("L0",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L1",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L2",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L3",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L4",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L5",names(cbps.match.balances))])))

boxplot.cbps.weight.balance_l4 <- data.frame("L" = c(rep("L0", length(cbps.weight.balances)/6),
                                                     rep("L1", length(cbps.weight.balances)/6),
                                                     rep("L2", length(cbps.weight.balances)/6),
                                                     rep("L3", length(cbps.weight.balances)/6),
                                                     rep("L4", length(cbps.weight.balances)/6),
                                                     rep("L5", length(cbps.weight.balances)/6)),
                                             "balance" = c(as.numeric(cbps.weight.balances[grepl("L0",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L1",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L2",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L3",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L4",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L5",names(cbps.weight.balances))])))



##calculations


ll <- prep_data_for_coverage_calc(list(mahalanobis.estimates_1, mahalanobis.estimates_2, mahalanobis.estimates_3),
                                  list(cbps.match.estimates_1, cbps.match.estimates_2, cbps.match.estimates_3),
                                  list(cbps.weight.estimates_1, cbps.weight.estimates_2, cbps.weight.estimates_3),
                                  list(ols.models_1, ols.models_2, ols.models_3),
                                  list(ols.models2_1, ols.models2_2, ols.models2_3)
)


coverage_l4 <- find_coverage_calc(true.effect = TREATMENT_EFFECT_TRUTH,
                                  ols.list = ll[[1]],
                                  ols.list2 = ll[[2]],
                                  maha.list = ll[[3]],
                                  cbps.match.list = ll[[4]],
                                  cbps.weight.list = ll[[5]])


##L = 5 setup
setwd(paste0(current.dir, "/", "simulation_data"))
files.of.interest <- list.files()[grepl("five", list.files())]
list_of_files <- list()
for(file in files.of.interest)
{
  a <- load(file)
  list_of_files[[file]] <- get(a)
}


############## make boxplots
cbps.match.estimates_1 <- unlist(list_of_files[grepl("cbps.match", names(list_of_files))], recursive = F)
cbps.weight.estimates_1 <- unlist(list_of_files[grepl("cbps.weight", names(list_of_files))], recursive = F)
mahalanobis.estimates_1 <- unlist(list_of_files[grepl("maha", names(list_of_files))], recursive = F)

cbps.match.coeffs_1 <- as.numeric(unlist(lapply(cbps.match.estimates_1, function(x) x[[2]]$estimates)))
cbps.weight.coeffs_1 <- as.numeric(unlist(lapply(cbps.weight.estimates_1, function(x) x[[2]]$estimates)))
mahalanobis.coeffs_1 <- as.numeric(unlist(lapply(mahalanobis.estimates_1, function(x) x[[2]]$estimates)))

cbps.match.ses_1 <- as.numeric(unlist(lapply(cbps.match.estimates_1, function(x) x[[2]]$standard.error)))
cbps.weight.ses_1 <- as.numeric(unlist(lapply(cbps.weight.estimates_1, function(x) x[[2]]$standard.error)))
mahalanobis.ses_1 <- as.numeric(unlist(lapply(mahalanobis.estimates_1, function(x) x[[2]]$standard.error)))

cbps.match.balances_1 <- unlist(lapply(cbps.match.estimates_1, function(x) x[[3]]))
cbps.weight.balances_1 <- unlist(lapply(cbps.weight.estimates_1, function(x) x[[3]]))
mahalanobis.balances_1 <- unlist(lapply(mahalanobis.estimates_1, function(x) x[[3]]))

ols.estimates_1 <- as.numeric(unlist(list_of_files[grepl("ols.estimates", names(list_of_files)) & 
                                                     grepl("ols.estimates2", names(list_of_files)) == F], recursive = F))
ols.models_1 <- unlist(list_of_files[grepl("ols.models", names(list_of_files)) & 
                                       grepl("ols.models2", names(list_of_files)) == F], recursive = F)

ols.estimates2_1 <- as.numeric(unlist(list_of_files[grepl("ols.estimates2", names(list_of_files))], recursive = F))
ols.models2_1 <- unlist(list_of_files[grepl("ols.models2", names(list_of_files))], recursive = F)

ols.ses_1 <- as.numeric(sapply(ols.models_1, function (x) summary(x)$coefficients["dem", "Std. Error"]))
ols2.ses_1 <- as.numeric(sapply(ols.models2_1, function (x) summary(x)$coefficients["dem", "Std. Error"]))


############## get another 300 simulations
setwd(paste0(current.dir, "/", "simulation_data_2"))
files.of.interest <- list.files()[grepl("five", list.files())]
list_of_files <- list()
for(file in files.of.interest)
{
  a <- load(file)
  list_of_files[[file]] <- get(a)
}


#mahalanobis.estimates_2[[2]][[2]]
cbps.match.estimates_2 <- unlist(list_of_files[grepl("cbps.match", names(list_of_files))], recursive = F)
cbps.weight.estimates_2 <- unlist(list_of_files[grepl("cbps.weight", names(list_of_files))], recursive = F)
mahalanobis.estimates_2 <- unlist(list_of_files[grepl("maha", names(list_of_files))], recursive = F)

cbps.match.coeffs_2 <- as.numeric(unlist(lapply(cbps.match.estimates_2, function(x) x[[2]]$estimates)))
cbps.weight.coeffs_2 <- as.numeric(unlist(lapply(cbps.weight.estimates_2, function(x) x[[2]]$estimates)))
mahalanobis.coeffs_2 <- as.numeric(unlist(lapply(mahalanobis.estimates_2, function(x) x[[2]]$estimates)))

cbps.match.ses_2 <- as.numeric(unlist(lapply(cbps.match.estimates_2, function(x) x[[2]]$standard.error)))
cbps.weight.ses_2 <- as.numeric(unlist(lapply(cbps.weight.estimates_2, function(x) x[[2]]$standard.error)))
mahalanobis.ses_2 <- as.numeric(unlist(lapply(mahalanobis.estimates_2, function(x) x[[2]]$standard.error)))

cbps.match.balances_2 <- unlist(lapply(cbps.match.estimates_2, function(x) x[[3]]))
cbps.weight.balances_2 <- unlist(lapply(cbps.weight.estimates_2, function(x) x[[3]]))
mahalanobis.balances_2 <- unlist(lapply(mahalanobis.estimates_2, function(x) x[[3]]))

ols.estimates_2 <- as.numeric(unlist(list_of_files[grepl("ols.estimates", names(list_of_files)) & 
                                                     grepl("ols.estimates2", names(list_of_files)) == F], recursive = F))
ols.models_2 <- unlist(list_of_files[grepl("ols.models", names(list_of_files)) & 
                                       grepl("ols.models2", names(list_of_files)) == F], recursive = F)

ols.estimates2_2 <- as.numeric(unlist(list_of_files[grepl("ols.estimates2", names(list_of_files))], recursive = F))
ols.models2_2 <- unlist(list_of_files[grepl("ols.models2", names(list_of_files))], recursive = F)

ols.ses_2 <- as.numeric(sapply(ols.models_2, function (x) summary(x)$coefficients["dem", "Std. Error"]))
ols2.ses_2 <- as.numeric(sapply(ols.models2_2, function (x) summary(x)$coefficients["dem", "Std. Error"]))


############## get another 400 simulations
setwd(paste0(current.dir, "/", "simulation_data_3"))
files.of.interest <- list.files()[grepl("five", list.files())]
list_of_files <- list()
for(file in files.of.interest)
{
  a <- load(file)
  list_of_files[[file]] <- get(a)
}

cbps.match.estimates_3 <- unlist(list_of_files[grepl("cbps.match", names(list_of_files))], recursive = F)
cbps.weight.estimates_3 <- unlist(list_of_files[grepl("cbps.weight", names(list_of_files))], recursive = F)
mahalanobis.estimates_3 <- unlist(list_of_files[grepl("maha", names(list_of_files))], recursive = F)

cbps.match.coeffs_3 <- as.numeric(unlist(lapply(cbps.match.estimates_3, function(x) x[[2]]$estimates)))
cbps.weight.coeffs_3 <- as.numeric(unlist(lapply(cbps.weight.estimates_3, function(x) x[[2]]$estimates)))
mahalanobis.coeffs_3 <- as.numeric(unlist(lapply(mahalanobis.estimates_3, function(x) x[[2]]$estimates)))

cbps.match.ses_3 <- as.numeric(unlist(lapply(cbps.match.estimates_3, function(x) x[[2]]$standard.error)))
cbps.weight.ses_3 <- as.numeric(unlist(lapply(cbps.weight.estimates_3, function(x) x[[2]]$standard.error)))
mahalanobis.ses_3 <- as.numeric(unlist(lapply(mahalanobis.estimates_3, function(x) x[[2]]$standard.error)))

cbps.match.balances_3 <- unlist(lapply(cbps.match.estimates_3, function(x) x[[3]]))
cbps.weight.balances_3 <- unlist(lapply(cbps.weight.estimates_3, function(x) x[[3]]))
mahalanobis.balances_3 <- unlist(lapply(mahalanobis.estimates_3, function(x) x[[3]]))

ols.estimates_3 <- as.numeric(unlist(list_of_files[grepl("ols.estimates", names(list_of_files)) & 
                                                     grepl("ols.estimates2", names(list_of_files)) == F], recursive = F))
ols.models_3 <- unlist(list_of_files[grepl("ols.models", names(list_of_files)) & 
                                       grepl("ols.models2", names(list_of_files)) == F], recursive = F)

ols.estimates2_3 <- as.numeric(unlist(list_of_files[grepl("ols.estimates2", names(list_of_files))], recursive = F))
ols.models2_3 <- unlist(list_of_files[grepl("ols.models2", names(list_of_files))], recursive = F)

ols.ses_3 <- as.numeric(sapply(ols.models_3, function (x) summary(x)$coefficients["dem", "Std. Error"]))
ols2.ses_3 <- as.numeric(sapply(ols.models2_3, function (x) summary(x)$coefficients["dem", "Std. Error"]))


## putting stuff together
ols.estimates <- c(ols.estimates_1, ols.estimates_2, ols.estimates_3)
ols.estimates2 <- c(ols.estimates2_1, ols.estimates2_2, ols.estimates2_3)
ols.ses <- c(ols.ses_1, ols.ses_2, ols.ses_3)
ols.ses2 <- c(ols2.ses_1, ols2.ses_2, ols2.ses_3)
mahalanobis.coeffs <- c(mahalanobis.coeffs_1, mahalanobis.coeffs_2, mahalanobis.coeffs_3)
cbps.match.coeffs <- c(cbps.match.coeffs_1, cbps.match.coeffs_2, cbps.match.coeffs_3)
cbps.weight.coeffs <- c(cbps.weight.coeffs_1, cbps.weight.coeffs_2, cbps.weight.coeffs_3)
mahalanobis.ses <- c(mahalanobis.ses_1, mahalanobis.ses_2, mahalanobis.ses_3)
cbps.match.ses <- c(cbps.match.ses_1, cbps.match.ses_2, cbps.match.ses_3)
cbps.weight.ses <- c(cbps.weight.ses_1, cbps.weight.ses_2, cbps.weight.ses_3)

mahalanobis.balances <- c(mahalanobis.balances_1, mahalanobis.balances_2, mahalanobis.balances_3)
cbps.weight.balances <- c(cbps.weight.balances_1, cbps.weight.balances_2, cbps.weight.balances_3)
cbps.match.balances <- c(cbps.match.balances_1, cbps.match.balances_2, cbps.match.balances_3)

boxplot.ses_l5 <- data.frame(method = c(rep("OLS", length(ols.ses)),
                                        rep("OLS2", length(ols.ses)),
                                        rep("Mahalanobis", length(mahalanobis.ses)),
                                        rep("CBPS Matching", length(cbps.match.ses)),
                                        rep("CBPS Weighting", length(cbps.weight.ses))),
                             estimate = c(ols.ses, ols.ses2, mahalanobis.ses,
                                          cbps.match.ses, cbps.weight.ses))

boxplot.data_l5 <- data.frame(method = c(rep("OLS", length(ols.estimates)),
                                         rep("OLS2", length(ols.estimates)),
                                         rep("Mahalanobis", length(mahalanobis.coeffs)),
                                         rep("CBPS Matching", length(cbps.match.coeffs)),
                                         rep("CBPS Weighting", length(cbps.weight.coeffs))),
                              estimate = c(ols.estimates, ols.estimates2, mahalanobis.coeffs,
                                           cbps.match.coeffs, cbps.weight.coeffs))


boxplot.maha.balance_l5 <- data.frame("L" = c(rep("L0", length(mahalanobis.balances)/6),
                                              rep("L1", length(mahalanobis.balances)/6),
                                              rep("L2", length(mahalanobis.balances)/6),
                                              rep("L3", length(mahalanobis.balances)/6),
                                              rep("L4", length(mahalanobis.balances)/6),
                                              rep("L5", length(mahalanobis.balances)/6)),
                                      "balance" = c(as.numeric(mahalanobis.balances[grepl("L0",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L1",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L2",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L3",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L4",names(mahalanobis.balances))]),
                                                    as.numeric(mahalanobis.balances[grepl("L5",names(mahalanobis.balances))])))

boxplot.cbps.match.balance_l5 <- data.frame("L" = c(rep("L0", length(cbps.match.balances)/6),
                                                    rep("L1", length(cbps.match.balances)/6),
                                                    rep("L2", length(cbps.match.balances)/6),
                                                    rep("L3", length(cbps.match.balances)/6),
                                                    rep("L4", length(cbps.match.balances)/6),
                                                    rep("L5", length(cbps.match.balances)/6)),
                                            "balance" = c(as.numeric(cbps.match.balances[grepl("L0",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L1",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L2",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L3",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L4",names(cbps.match.balances))]),
                                                          as.numeric(cbps.match.balances[grepl("L5",names(cbps.match.balances))])))

boxplot.cbps.weight.balance_l5 <- data.frame("L" = c(rep("L0", length(cbps.weight.balances)/6),
                                                     rep("L1", length(cbps.weight.balances)/6),
                                                     rep("L2", length(cbps.weight.balances)/6),
                                                     rep("L3", length(cbps.weight.balances)/6),
                                                     rep("L4", length(cbps.weight.balances)/6),
                                                     rep("L5", length(cbps.weight.balances)/6)),
                                             "balance" = c(as.numeric(cbps.weight.balances[grepl("L0",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L1",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L2",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L3",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L4",names(cbps.weight.balances))]),
                                                           as.numeric(cbps.weight.balances[grepl("L5",names(cbps.weight.balances))])))



##calculations


ll <- prep_data_for_coverage_calc(list(mahalanobis.estimates_1, mahalanobis.estimates_2, mahalanobis.estimates_3),
                                  list(cbps.match.estimates_1, cbps.match.estimates_2, cbps.match.estimates_3),
                                  list(cbps.weight.estimates_1, cbps.weight.estimates_2, cbps.weight.estimates_3),
                                  list(ols.models_1, ols.models_2, ols.models_3),
                                  list(ols.models2_1, ols.models2_2, ols.models2_3)
)


coverage_l5 <- find_coverage_calc(true.effect = TREATMENT_EFFECT_TRUTH,
                                  ols.list = ll[[1]],
                                  ols.list2 = ll[[2]],
                                  maha.list = ll[[3]],
                                  cbps.match.list = ll[[4]],
                                  cbps.weight.list = ll[[5]])

setwd(paste0(current.dir))
#####constructing the boxplot figures
boxplot.data_l1$method <- factor(boxplot.data_l1$method, 
                                 levels = c("OLS", "OLS2", "Mahalanobis", "CBPS Matching", "CBPS Weighting"))
boxplot.data_l2$method <- factor(boxplot.data_l2$method, 
                                 levels = c("OLS", "OLS2", "Mahalanobis", "CBPS Matching", "CBPS Weighting"))
boxplot.data_l3$method <- factor(boxplot.data_l3$method, 
                                 levels = c("OLS", "OLS2", "Mahalanobis", "CBPS Matching", "CBPS Weighting"))
boxplot.data_l4$method <- factor(boxplot.data_l4$method, 
                                 levels = c("OLS", "OLS2", "Mahalanobis", "CBPS Matching", "CBPS Weighting"))
boxplot.data_l5$method <- factor(boxplot.data_l5$method, 
                                 levels = c("OLS", "OLS2", "Mahalanobis", "CBPS Matching", "CBPS Weighting"))

balances <- list(boxplot.maha.balance_l1, boxplot.maha.balance_l2, boxplot.maha.balance_l3, 
                 boxplot.maha.balance_l4,boxplot.maha.balance_l5,
                 boxplot.cbps.match.balance_l1,boxplot.cbps.match.balance_l2, boxplot.cbps.match.balance_l3,
                 boxplot.cbps.match.balance_l4,boxplot.cbps.match.balance_l5,
                 boxplot.cbps.weight.balance_l1,boxplot.cbps.weight.balance_l2, 
                 boxplot.cbps.weight.balance_l3,
                 boxplot.cbps.weight.balance_l4,boxplot.cbps.weight.balance_l5)

mains <- rep(c("(a) L = 1\nSevere \n Misspecification", 
               "(b) L = 2\nModerate \n Misspecification", 
               "(c) L = 3\nCorrect \n Specification",
               "(c) L = 4\nModerate \n Overspecification",
               "(c) L = 5\nSevere \n Overspecification"),3)
mains[6:length(mains)] <- ""
names_of_methods <- c(rep("Mahalanobis Dist. Matching", 5), 
                      rep("Propensity Score Matching", 5),
                      rep("Propensity Score Weighting", 5)) 



## box plots for balances
filename <- "n_1000_1_balances"
pdf(file = paste0(filename, ".pdf"), width = 8, height = 10)
par(mfrow = c(3,5), oma = c(7, 5, 0, 5))
for (i in 1:length(balances)) {
  if (i < 6){
    par(mar = c(1, 2, 5.1, 2.1))
  } else {
    par(mar = c(1, 2, 2, 2.1))
  }
  
  axis.cex = .5
  labels_ = c("L0",
              "L1",
              "L2",
              "L3",
              "L4",
              "L5")
  if (grepl("_50", filename)) {
    ylims = c(0, .5)  
  } else {
    ylims = c(0, 0.25)
  }
  
  xlims = c(1:4)  
  boxplot(balance ~ L, data = balances[[i]],
          main = mains[i], cex.main = 1.3, cex.axis = 1, 
          cex.lab= 1, las =1,
          xaxt = "n" ,
          ylim = ylims, xlab = "")
  #ylab = names_of_methods[i])
  axis(1, at = 1:6, labels = labels_, padj = .7, las = 2,
       cex.axis = axis.cex)
}
mtext("Mahalanobis Dist. Matching", side = 2, line = 1.6, outer = T, at = .792)
mtext("Propensity Score Matching", side = 2, line = 1.6, outer = T, at = .46)
mtext("Propensity Score Weighting", side = 2, line = 1.6, outer = T, at = .127)
mtext("Balance Metrics \n Averaged across Covariates for Each Lag",
      side = 1, line = 2.5, outer = T, at = .5)
dev.off()
## box plots for estimates
# pdf(file = "n_1000_1_boxplots.pdf", width = 23, height = 7.5)
# par(mfrow=c(1,3), oma = c(0, 10, 0, 0))
# par(mar = c(10.1, 2, 8.1, 2.1))
# 
# axis.cex = 2.2
# labels_ = c("\nOrdinary \nLeast \nSquares",
#             "\nMahalanobis\n Dist.\nMatching",
#             "\nPropensity \nScore\nMatching",
#             "\nPropensity \nScore\nWeighting")
# 
# ylims = c(-10.5, -4.6)
# xlims = c(1:4)
# boxplot(estimate ~ method, data = boxplot.data_l1,
#         main = "(a) L = 1\nSevere Misspecification", cex.main = 3, cex.axis = 1.8,cex.lab=3.3, las =1,
#         xaxt = "n" ,
#         ylim = ylims, xlab = "", ylab = "")
# axis(1, at = 1:4, labels = labels_, padj = .7, cex.axis = axis.cex)
# 
# abline(h = -7.5, col = "red")
# 
# par(mar = c(10.1, 2, 8.1, 2))
# 
# boxplot(estimate ~ method, data = boxplot.data_l2,
#         main = "(b) L = 2\nModerate Misspecification", cex.main = 3, cex.axis = 1.8,cex.lab=2.7, las =1,
#         xaxt = "n" ,ylim = ylims, xlab = "", ylab = "")
# axis(1, at = 1:4, labels = labels_, padj = .7, cex.axis = axis.cex)
# #mtext("\nModerate Misspecification", side = 3, cex = 1.4, line = 1)
# abline(h = -7.5, col = "red")
# 
# par(mar = c(10.1, 2, 8.1, 2))
# boxplot(estimate ~ method, data = boxplot.data_l3,
#         main = "(c) L = 3\nCorrect Specification", cex.main = 3, cex.axis = 1.8,cex.lab=2.7, las =1,
#         xaxt = "n" ,ylim = ylims, xlab = "", ylab = "")
# axis(1, at = 1:4, labels = labels_, padj = .7, cex.axis = axis.cex)
# #mtext("\nCorrect Specification", side = 3, cex = 1.4, line = 1)
# abline(h = -7.5, col = "red")
# mtext("Estimated Contemporaneous\nTreatment Effect", side =2, cex = 2.7, line = 1, outer = T)
# 
# 
# dev.off()


# ###
# pdf(file = "n_1000_1_boxplots.pdf", width = 23, height = 7.5)
# par(mfrow=c(1,3), oma = c(0, 10, 0, 0))
# par(mar = c(10.1, 2, 8.1, 2.1))
# 
# axis.cex = 2.2
# labels_ = c("\nOrdinary \nLeast \nSquares",
#             "\nMahalanobis\n Dist.\nMatching",
#             "\nPropensity \nScore\nMatching",
#             "\nPropensity \nScore\nWeighting")
# 
# ylims = c(-5, 5)
# xlims = c(1:4)
# boxplot(estimate ~ method, data = boxplot.data_l1,
#         main = "(a) L = 1\nSevere Misspecification", cex.main = 3, cex.axis = 1.8,cex.lab=3.3, las =1,
#         xaxt = "n" ,
#         ylim = ylims, xlab = "", ylab = "")
# axis(1, at = 1:4, labels = labels_, padj = .7, cex.axis = axis.cex)
# 
# abline(h = TREATMENT_EFFECT_TRUTH, col = "red")
# 
# par(mar = c(10.1, 2, 8.1, 2))
# 
# boxplot(estimate ~ method, data = boxplot.data_l2,
#         main = "(b) L = 2\nModerate Misspecification", cex.main = 3, cex.axis = 1.8,cex.lab=2.7, las =1,
#         xaxt = "n" ,ylim = ylims, xlab = "", ylab = "")
# axis(1, at = 1:4, labels = labels_, padj = .7, cex.axis = axis.cex)
# #mtext("\nModerate Misspecification", side = 3, cex = 1.4, line = 1)
# abline(h = TREATMENT_EFFECT_TRUTH, col = "red")
# 
# par(mar = c(10.1, 2, 8.1, 2))
# boxplot(estimate ~ method, data = boxplot.data_l3,
#         main = "(c) L = 3\nCorrect Specification", cex.main = 3, cex.axis = 1.8,cex.lab=2.7, las =1,
#         xaxt = "n" ,ylim = ylims, xlab = "", ylab = "")
# axis(1, at = 1:4, labels = labels_, padj = .7, cex.axis = axis.cex)
# #mtext("\nCorrect Specification", side = 3, cex = 1.4, line = 1)
# abline(h = TREATMENT_EFFECT_TRUTH, col = "red")
# mtext("Estimated Contemporaneous\nTreatment Effect", side =2, cex = 2.7, line = 1, outer = T)
# 
# 
# dev.off()

###
filename <- "n_1000_1_boxplots"
pdf(file = "n_1000_1_boxplots.pdf", width = 23, height = 7.5)
par(mfrow=c(1,5), oma = c(0, 10, 0, 0))
par(mar = c(10.1, 2, 8.1, 2.1))

axis.cex = 1.3
labels_ = c("\nOrdinary \nLeast \nSquares",
            "\nOrdinary \nLeast \nSquares2",
            "\nMahalanobis\n Dist.\nMatching",
            "\nPropensity \nScore\nMatching",
            "\nPropensity \nScore\nWeighting")
if (grepl("_50", filename) & grepl("n75", filename) == F) {
  ylims = c(-8.5, 8.5)  
} else if (grepl("_50", filename) == F & grepl("n75", filename) == F){
  ylims = c(-5, 5)
} else if (grepl("_50", filename) == F & grepl("n75", filename) == T) {
  ylims = c(-12, -4)
} else if (grepl("_50", filename) == T & grepl("n75", filename) == T) {
  ylims = c(-15, 0)
}


xlims = c(1:5)
boxplot(estimate ~ method, data = boxplot.data_l1,
        main = "(a) L = 1\nSevere Misspecification", cex.main = 3, cex.axis = 1.8,cex.lab=3.3, las =1,
        xaxt = "n" ,
        ylim = ylims, xlab = "", ylab = "")
axis(1, at = 1:5, labels = labels_, padj = .7, cex.axis = axis.cex)

abline(h = TREATMENT_EFFECT_TRUTH, col = "red")

par(mar = c(10.1, 2, 8.1, 2))

boxplot(estimate ~ method, data = boxplot.data_l2,
        main = "(b) L = 2\nModerate Misspecification", cex.main = 3, cex.axis = 1.8,cex.lab=2.7, las =1,
        xaxt = "n" ,ylim = ylims, xlab = "", ylab = "")
axis(1, at = 1:5, labels = labels_, padj = .7, cex.axis = axis.cex)
#mtext("\nModerate Misspecification", side = 3, cex = 1.4, line = 1)
abline(h = TREATMENT_EFFECT_TRUTH, col = "red")

par(mar = c(10.1, 2, 8.1, 2))
boxplot(estimate ~ method, data = boxplot.data_l3,
        main = "(c) L = 3\nCorrect Specification", cex.main = 3, cex.axis = 1.8,cex.lab=2.7, las =1,
        xaxt = "n" ,ylim = ylims, xlab = "", ylab = "")
axis(1, at = 1:5, labels = labels_, padj = .7, cex.axis = axis.cex)
#mtext("\nCorrect Specification", side = 3, cex = 1.4, line = 1)
abline(h = TREATMENT_EFFECT_TRUTH, col = "red")
mtext("Estimated Contemporaneous\nTreatment Effect", side =2, cex = 2.7, line = 1, outer = T)

par(mar = c(10.1, 2, 8.1, 2))
boxplot(estimate ~ method, data = boxplot.data_l4,
        main = "(c) L = 4\nModerate Overspecification", cex.main = 3, cex.axis = 1.8,cex.lab=2.7, las =1,
        xaxt = "n" ,ylim = ylims, xlab = "", ylab = "")
axis(1, at = 1:5, labels = labels_, padj = .7, cex.axis = axis.cex)
#mtext("\nCorrect Specification", side = 3, cex = 1.4, line = 1)
abline(h = TREATMENT_EFFECT_TRUTH, col = "red")
mtext("Estimated Contemporaneous\nTreatment Effect", side =2, cex = 2.7, line = 1, outer = T)

par(mar = c(10.1, 2, 8.1, 2))
boxplot(estimate ~ method, data = boxplot.data_l5,
        main = "(c) L = 5\nSevere Overspecification", cex.main = 3, cex.axis = 1.8,cex.lab=2.7, las =1,
        xaxt = "n" ,ylim = ylims, xlab = "", ylab = "")
axis(1, at = 1:5, labels = labels_, padj = .7, cex.axis = axis.cex)
#mtext("\nCorrect Specification", side = 3, cex = 1.4, line = 1)
abline(h = TREATMENT_EFFECT_TRUTH, col = "red")
mtext("Estimated Contemporaneous\nTreatment Effect", side =2, cex = 2.7, line = 1, outer = T)

dev.off()

## saving coverage results 
all_coverage <- list("L1" = coverage_l1, "L2" = coverage_l2, "L3" = coverage_l3,
                     "L4" = coverage_l4, "L5" = coverage_l5)
save(all_coverage, file = "n_1000_1_coverage.RData")

## and balance results
save(balances, file = "n_1000_1_balances.RData")

## and estimates results
all_estimates <- list("L1" = boxplot.data_l1, "L2" = boxplot.data_l2, 
                      "L3" = boxplot.data_l3, "L4" = boxplot.data_l4,
                      "L5" = boxplot.data_l5)
save(all_estimates, file = "n_1000_1_estimates.RData")

## and ses results
all_ses <- list("L1" = boxplot.ses_l1, "L2" = boxplot.ses_l2, 
                "L3" = boxplot.ses_l3, "L4" = boxplot.ses_l4,
                "L5" = boxplot.ses_l5)
save(all_ses, file = "n_1000_1_ses.RData")

## all results
all_results <- list("coverage" = all_coverage,
                "balance" = balances,
                "estimates" = all_estimates,
                "ses" = all_ses)
save(all_results, file = "n_1000_1_ALL_50.RData")
