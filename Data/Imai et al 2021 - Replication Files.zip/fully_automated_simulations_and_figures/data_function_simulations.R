library(dplyr)
library(PanelMatch)
#load("ace_data_countries_with_sparse_covs_dropped.rda") #loads as d3
load("ace_data_countries_with_sparse_covs_dropped.rda")
d3 <- d3[order(d3[,"wbcode2"], d3[,"year"]), ]
d3$logpop <- d3$logpop / 10 
impute_data <- function(ace_data, country.code, covariate, bin.var = F)
{
  country.data <- dplyr::filter(ace_data, wbcode2 == country.code)
  if(!bin.var)
  {
    if(mean(is.na(country.data[, covariate])) >= .35)
    {
      degree <- 1
    } else
    {
      degree <- 2
    }
    form <- paste0(covariate, "~ poly(year, ", degree, ")")
    lm.model <- lm(as.formula(form), data= country.data)
    
    lplot = predict(lm.model, newdata = data.frame(year = 1960:2010))
    #seq.diffs <- diff(country.data[, covariate], lag = 1) #for variance
    #sim.points <- sapply(lplot, rnorm, n = 1, sd = sd(seq.diffs, na.rm = T) )
    sim.points <- lplot
    idx <- which(is.na(country.data[, covariate]))
    country.data[idx, covariate] <- sim.points[idx]
    return(country.data[, covariate])
  } else
  {
    if(mean(is.na(country.data[, covariate])) >= .35)
    {
      degree <- 1
    } else
    {
      degree <- 2
    }
    
    form <- paste0(covariate, "~ poly(year, ", degree, ")")
    if(length(na.omit(unique(country.data[, covariate]))) == 1)
    {
      #browser()
      val <- as.integer(na.omit(unique(country.data[, covariate])))
      idx <- which(is.na(country.data[, covariate]))
      country.data[idx, covariate] <- val
    }
    else
    {
      # form <- paste0(covariate, "~ year")
      log.model <- glm(as.formula(form), data = country.data, family = binomial, na.action = na.omit)
      lplot <- predict(log.model, newdata = data.frame(year = 1960:2010), type = "response")
      #lplot <- sapply(lplot, rbinom, n = 1, size = 1)
      lplot <- round(lplot)
      idx <- which(is.na(country.data[, covariate]))
      country.data[idx, covariate] <- lplot[idx]
    }
    
    return(country.data[, covariate])
  }
}

fill.data <- function(ace_data)
{
  countries <- unique(ace_data[, "wbcode2"])
  covars.to.sim <- colnames(ace_data)[!colnames(ace_data) %in% c("wbcode2", "year", "dem", "unrest")] #maybe add y back in
  
  for(country in countries)
  {
    for(covar in covars.to.sim)
    {
      ace_data[ace_data[,"wbcode2"] == country, covar] <- impute_data(ace_data, country, covar)
    }
  }
  
  covars.to.sim <- colnames(ace_data)[colnames(ace_data) %in% c("dem", "unrest")]
  #binary variable attempt
  for(country in countries)
  {
    for(covar in covars.to.sim)
    {
      ace_data[ace_data[,"wbcode2"] == country, covar] <- impute_data(ace_data, country, covar, bin.var = T)
    }
  }
  #ace_data <- ace_data %>% group_by(wbcode2) %>% mutate(dem_l1 = lag(dem)) %>% mutate(dem_l2 = lag(dem, 2)) %>% mutate(dem_l3 = lag(dem, 3))
  return(ace_data)
}

og.vars <- c('logpop', 'tradewb', "Populationages014oftotal", "Populationages1564oftota", "nfagdp", "unrest")
new.data <- fill.data(d3)
#new data is the entirely imputed data set that we want to use in combination with the FE model so that we can generate X_its


###fill in first ten years of each countrys data so that we can fit the fixed effects model
imputed.model.data <- d3
countries <- unique(imputed.model.data[, "wbcode2"])
for(country in countries)
{
  idx <- new.data[, "wbcode2"] == country & new.data[, "year"] %in% (1960:1970)
  imputed.model.data[idx, ] <- new.data[idx, ]
}


imputed.model.data2 <- imputed.model.data %>% as.data.frame(.)# %>% filter(., year > 1962)

new.data %>% group_by(wbcode2) %>% mutate_all(., .funs = list(l1 = lag), n = 1) %>% select(., wbcode2, ends_with("_l1"), -"year_l1") -> t1
new.data %>% group_by(wbcode2) %>% mutate_all(., .funs = list(l2 = lag), n = 2) %>% select(., wbcode2, ends_with("_l2"),  -"year_l2") -> t2
new.data %>% group_by(wbcode2) %>% mutate_all(., .funs = list(l3 = lag), n = 3) %>% select(., wbcode2,  ends_with("_l3"), -"year_l3") -> t3
new.data %>% group_by(wbcode2) -> new.data

# new.data <- bind_cols(new.data, t1, t2, t3) %>% select(., -"y_l1", -"y_l2", -"y_l3", -"wbcode21", -"wbcode22", -"wbcode23")
# note that I revised the line above. 
# The previous problem was that "wbcode21" wasn't created. Instead, "wbcode2...1" was created
new.data <- bind_cols(new.data, t1[, colnames(t1)[colnames(t1)!="wbcode2"] ], 
                      t2[,colnames(t2)[colnames(t2)!="wbcode2"]], 
                      t3[,colnames(t3)[colnames(t3)!="wbcode2"]]) %>% select(., -"y_l1", -"y_l2", -"y_l3") # 31 vars

####################################building the formulae as strings#############################################
interaction.var.term <- "logpop"
sub.og.vars <- og.vars[og.vars != interaction.var.term & og.vars != "unrest"]
interaction.term.formula.as.character <- paste0(as.character(sapply(sub.og.vars, function(x) sapply(c("", "_l1", "_l2", "_l3"),
                                                                                                    function(y) paste0(x,y, " * ", interaction.var.term, y)))), collapse = " + ")


form.obj.treatment <- paste("dem ~ factor(wbcode2) + factor(year) + logpop + tradewb + Populationages014oftotal + Populationages1564oftota + nfagdp + unrest + ",
                            paste0(paste0(c("dem", "logpop", "tradewb", "Populationages014oftotal", "Populationages1564oftota", "nfagdp", "unrest"), "_l1 + "),
                                   paste0(c("dem", "logpop", "tradewb", "Populationages014oftotal", "Populationages1564oftota", "nfagdp", "unrest"), "_l2 + "),
                                   paste0(c("dem", "logpop", "tradewb", "Populationages014oftotal", "Populationages1564oftota", "nfagdp", "unrest"), "_l3"), collapse = " + "))


form.obj.treatment <- paste0(form.obj.treatment, " + ", interaction.term.formula.as.character)

form.obj.outcome <- paste("y ~ factor(wbcode2) + factor(year) + logpop + tradewb + Populationages014oftotal + Populationages1564oftota + nfagdp + unrest + dem + ",
                          paste0(paste0(c("dem", "logpop", "tradewb", "Populationages014oftotal", "Populationages1564oftota", "nfagdp", "unrest"), "_l1 + "),
                                 paste0(c("dem", "logpop", "tradewb", "Populationages014oftotal", "Populationages1564oftota", "nfagdp", "unrest"), "_l2 + "),
                                 paste0(c("dem", "logpop", "tradewb", "Populationages014oftotal", "Populationages1564oftota", "nfagdp", "unrest"), "_l3"), collapse = " + "))

form.obj.outcome <- paste0(form.obj.outcome, " + ", interaction.term.formula.as.character)

model.form <- paste("~ logpop + tradewb + Populationages014oftotal + Populationages1564oftota + nfagdp + unrest + dem + ",
                    paste0(paste0(c("dem", "logpop", "tradewb", "Populationages014oftotal", "Populationages1564oftota", "nfagdp", "unrest"), "_l1 + "),
                           paste0(c("dem", "logpop", "tradewb", "Populationages014oftotal", "Populationages1564oftota", "nfagdp", "unrest"), "_l2 + "),
                           paste0(c("dem", "logpop", "tradewb", "Populationages014oftotal", "Populationages1564oftota", "nfagdp", "unrest"), "_l3"), collapse = " + "))

model.form <- paste0(model.form, " + ", interaction.term.formula.as.character)
################################################################################################################################################


imputed.model.data2 %>% group_by(wbcode2) %>% mutate_all(., .funs = list(l1 = lag), n = 1) %>% select(., wbcode2, ends_with("_l1"), -"year_l1", "wbcode2") -> t1
imputed.model.data2 %>% group_by(wbcode2) %>% mutate_all(., .funs = list(l2 = lag), n = 2) %>% select(., wbcode2, ends_with("_l2"),  -"year_l2", "wbcode2") -> t2
imputed.model.data2 %>% group_by(wbcode2) %>% mutate_all(., .funs = list(l3 = lag), n = 3) %>% select(., wbcode2,  ends_with("_l3"), -"year_l3", "wbcode2") -> t3
imputed.model.data2 %>% group_by(wbcode2) -> imputed.model.data2

# line also revised for the same reason as the one for line 113
imputed.model.data2 <- bind_cols(imputed.model.data2, 
                                 t1[, colnames(t1)[colnames(t1)!="wbcode2"] ], 
                                 t2[,colnames(t2)[colnames(t2)!="wbcode2"]], 
                                 t3[,colnames(t3)[colnames(t3)!="wbcode2"]]) %>% as.data.frame(.) %>% select(., -"y_l1", -"y_l2", -"y_l3") %>% filter(., year > 1962)

x.fe.model <- glm(data = imputed.model.data2,
                  as.formula(paste(form.obj.treatment, "- 1")),
                  na.action = na.omit, family = binomial)


y.fe.model <- lm(data = imputed.model.data2,
                 as.formula(paste(form.obj.outcome, "- 1")),
                 na.action = na.omit)

# y.fe.model
Betas <- x.fe.model$coefficients
betas <- c(Betas[1:162], 0, Betas[163:length(Betas)])
names(betas)[163] <- "factor(year)1963"
#betas <- c(betas, c(0,0,0)) #accounting for y_l*, this will need to be adjusted if x.fe.model is adjusted
#names(betas)[names(betas) == ""] <- c('y_l1','y_l2','y_l3')

y.Betas <- y.fe.model$coefficients
y.betas <- c(y.Betas[1:162], 0, y.Betas[163:length(y.Betas)])
names(y.betas)[163] <- "factor(year)1963"

# TREATMENT_EFFECT_TRUTH = -7.5
TREATMENT_EFFECT_TRUTH = -7.5
#y.betas <- c(y.betas, TREATMENT_EFFECT_TRUTH)
idx <- which(names(y.betas) == "dem")
y.betas[idx] <- TREATMENT_EFFECT_TRUTH

#new.data <- as.data.frame(new.data)
newd <- as.data.frame(new.data)# %>% filter(., year > 1962)
newd$year <- as.factor(newd$year)
newd$wbcode2 <- as.factor(newd$wbcode2)

dummy.mat1 <- model.matrix(~  newd$wbcode2 - 1)
dummy.mat2 <- model.matrix(~  newd$year - 1)[, -c(1, 2, 3)]
#fill in six variable formula in the next line
dummy.mat3 <- model.matrix( as.formula(model.form), model.frame(~., data = newd, na.action = na.pass)) %>% as.data.frame(.) %>%
  select(., -"logpop", -"tradewb", -"Populationages014oftotal", -"Populationages1564oftota",
         -"nfagdp", -"unrest", -"dem", -"(Intercept)")
newd <- select(newd, -ends_with("_l1"), -ends_with("_l2"), -ends_with("_l3"))
newd3 <- cbind(dummy.mat1, dummy.mat2, dummy.mat3, newd)



newd3$year <- as.numeric(as.character(newd3$year))
newd3$wbcode2 <- as.numeric(as.character(newd3$wbcode2))

#y.betas[211:length(y.betas)] <- y.betas[colnames(newd3)[211:length(colnames(newd3))]]
nms <- colnames(newd3)[211:length(colnames(newd3))][!colnames(newd3)[211:length(colnames(newd3))] %in% c('year', 'wbcode2', 'y')]
y.betas <- c(y.betas[1:210], y.betas[nms])

nms <- colnames(newd3)[211:length(colnames(newd3))][!colnames(newd3)[211:length(colnames(newd3))] %in% c('year', 'wbcode2', 'y', 'dem')]
betas <- c(betas[1:210], betas[nms])

simulate_function <- function(betas, y.betas, new.data, idx)
{
  new.data <- fill.data(d3)
  imputed.model.data <- d3
  countries <- unique(imputed.model.data[, "wbcode2"])
  for(country in countries)
  {
    idx <- new.data[, "wbcode2"] == country & new.data[, "year"] %in% (1960:1970)
    imputed.model.data[idx, ] <- new.data[idx, ]
  }
  imputed.model.data2 <- imputed.model.data %>% as.data.frame(.)# %>% filter(., year > 1962)
  new.data %>% group_by(wbcode2) %>% mutate_all(., .funs = list(l1 = lag), n = 1) %>% select(., wbcode2, ends_with("_l1"), -"year_l1") -> t1
  new.data %>% group_by(wbcode2) %>% mutate_all(., .funs = list(l2 = lag), n = 2) %>% select(., wbcode2, ends_with("_l2"),  -"year_l2") -> t2
  new.data %>% group_by(wbcode2) %>% mutate_all(., .funs = list(l3 = lag), n = 3) %>% select(., wbcode2,  ends_with("_l3"), -"year_l3") -> t3
  new.data %>% group_by(wbcode2) -> new.data
  
  new.data <- bind_cols(new.data, t1[, colnames(t1)[colnames(t1)!="wbcode2"] ], 
                        t2[,colnames(t2)[colnames(t2)!="wbcode2"]], 
                        t3[,colnames(t3)[colnames(t3)!="wbcode2"]]) %>% select(., -"y_l1", -"y_l2", -"y_l3")
  
  newd <- as.data.frame(new.data)# %>% filter(., year > 1962)
  newd$year <- as.factor(newd$year)
  newd$wbcode2 <- as.factor(newd$wbcode2)
  
  dummy.mat1 <- model.matrix(~  newd$wbcode2 - 1)
  dummy.mat2 <- model.matrix(~  newd$year - 1)[, -c(1, 2, 3)]
  #fill in six variable formula in the next line
  dummy.mat3 <- model.matrix( as.formula(model.form), model.frame(~., data = newd, na.action = na.pass)) %>% as.data.frame(.) %>%
    select(., -"logpop", -"tradewb", -"Populationages014oftotal", -"Populationages1564oftota",
           -"nfagdp", -"unrest", -"dem", -"(Intercept)")
  newd <- select(newd, -ends_with("_l1"), -ends_with("_l2"), -ends_with("_l3"))
  newd3 <- cbind(dummy.mat1, dummy.mat2, dummy.mat3, newd)
  
  
  
  newd3$year <- as.numeric(as.character(newd3$year))
  newd3$wbcode2 <- as.numeric(as.character(newd3$wbcode2))
  # tdata <- dplyr::filter(newd3, year > 1962) %>% dplyr::filter(., wbcode2 == 22) %>% select(., -dem) %>% select(., -year) %>% select(., -wbcode2) %>% select(., -y)
  newd3$sim.X <- NA
  newd3$sim.Y <- NA
  countries <- unique(newd3$wbcode2)
  
  #fill in 1960-1962 "simulated" treatments by just pulling from the imputed data
  for(country in countries)
  {
    demvals <- as.data.frame(dplyr::filter(new.data, year %in% 1960:1962 & wbcode2 == country) %>% as.data.frame(.) %>% select(., "dem"))[,1]
    newd3[newd3$wbcode2 == country & newd3$year %in% 1960:1962, "sim.X"] <- demvals
    
    yvals <- as.data.frame(dplyr::filter(new.data, year %in% 1960:1962 & wbcode2 == country) %>% as.data.frame(.) %>% select(., "y"))[,1]
    newd3[newd3$wbcode2 == country & newd3$year %in% 1960:1962, "sim.Y"] <- yvals
  }
  
  lag.mat <- cbind(dplyr::filter(newd3, year == 1962) %>% select(., "sim.X"),
                   dplyr::filter(newd3, year == 1961) %>% select(., "sim.X"),
                   dplyr::filter(newd3, year == 1960) %>% select(., "sim.X"))
  colnames(lag.mat) <- c("l1", "l2", "l3")
  
  # y.lag.mat <- cbind(dplyr::filter(newd3, year == 1962) %>% select(., "sim.Y"),
  #                    dplyr::filter(newd3, year == 1961) %>% select(., "sim.Y"),
  #                    dplyr::filter(newd3, year == 1960) %>% select(., "sim.Y"))
  # colnames(y.lag.mat) <- c("l1", "l2", "l3")
  
  year.data <- list()
  for (time in 1960:2010) {
    if(time %in% 1960:1962)
    {
      #just insert into the list for convenience
      tdata <- dplyr::filter(newd3, year == time) %>% select("wbcode2", "year", 'logpop', 'tradewb', "Populationages014oftotal", "Populationages1564oftota", "nfagdp", "unrest", "dem", "y") %>%
        rename(sim.X = dem, sim.Y = y)
      
      year.data[[paste0("year.", time)]] <- as.data.frame(tdata)
    } else
    {
      
      yeardata <- dplyr::filter(newd3, year == time) %>% select(., -"dem", -"y", -"wbcode2", -"year", -"sim.X", -"sim.Y")
      yeardata[, c("dem_l1", "dem_l2", "dem_l3")] <- lag.mat
      
      #yeardata[, paste0(as.character(sapply(sub.og.vars, function(x) sapply(c("", "_l1", "_l2", "_l3"), function(y) paste0(interaction.var.term, y, ":", x,y)))))] <-
      #  yeardata[, paste0(as.character(sapply(sub.og.vars, function(x) sapply(c("", "_l1", "_l2", "_l3"), function(y) paste0(x,y)))))] * do.call(cbind, lapply(1:6, function(x) lag.mat))
      preds <- as.matrix(yeardata) %*% as.matrix(betas, ncol = 1)
      sim.x <- sapply(exp(preds) / (1 + exp(preds)), FUN = rbinom, n = 1, size = 1) # random
      yeardata <- dplyr::filter(newd3, year == time) %>%
        select(., -"y", -"wbcode2", -"year", -"sim.X", -"sim.Y")
      yeardata[, c("dem_l1", "dem_l2", "dem_l3")] <- lag.mat
      #yeardata[, paste0(as.character(sapply(sub.og.vars, function(x) sapply(c("", "_l1", "_l2", "_l3"), function(y) paste0(interaction.var.term, y, ":", x,y)))))] <-
      #  yeardata[, paste0(as.character(sapply(sub.og.vars, function(x) sapply(c("", "_l1", "_l2", "_l3"), function(y) paste0(x,y)))))] * do.call(cbind, lapply(1:6, function(x) lag.mat))
      yeardata[, "dem"] <- sim.x
      
      ix <- which(colnames(yeardata) == "dem")
      colnames(yeardata)[ix] <- 'sim.x'
      #yeardata <- cbind(yeardata, sim.x)
      
      sim.y <- as.matrix(yeardata) %*% as.matrix(y.betas, ncol = 1)
      
      sim.y <- sim.y + rnorm(n = nrow(sim.y), mean = 0, sd = 4) #sd = (sigma(y.fe.model))) #, sd = 4.20)
      tdata <- dplyr::filter(newd3, year == time) %>%
        select("wbcode2", "year", 'logpop', 'tradewb', "Populationages014oftotal", "Populationages1564oftota", "nfagdp", "unrest", "sim.X", "sim.Y")
      tdata$sim.X <- sim.x
      tdata$sim.Y <- sim.y
      
      year.data[[paste0("year.", time)]] <- tdata
      
      tmat <- lag.mat[, c("l1", "l2")]
      tmat <- cbind(sim.x, tmat)
      colnames(tmat) <- c("l1", "l2", "l3")
      lag.mat <- tmat
      
      #ymat <- y.lag.mat[, c("l1", "l2")]
      #ymat <- cbind(sim.y, ymat)
      #colnames(ymat) <- c("l1", "l2", "l3")
      #y.lag.mat <- ymat
    }
    
  }
  sim.data <- do.call(rbind, year.data)
  rownames(sim.data) <- NULL
  sim.data <- sim.data %>% 
    select(., wbcode2, year, sim.Y, sim.X, logpop, tradewb, Populationages014oftotal, Populationages1564oftota, nfagdp, unrest) %>%
    group_by(wbcode2) %>% mutate(dem_l1 = lag(sim.X)) %>% mutate(dem_l2 = lag(sim.X, 2)) %>% mutate(dem_l3 = lag(sim.X, 3)) %>%
    mutate(dem_l4 = lag(sim.X, 4)) %>% mutate(dem_l5 = lag(sim.X, 5)) %>% 
    mutate(y_l1 = lag(sim.Y, 1)) %>% mutate(y_l2 = lag(sim.Y, 2)) %>% mutate(y_l3 = lag(sim.Y, 3)) %>%
    mutate(y_l4 = lag(sim.Y, 4)) %>% mutate(y_l5 = lag(sim.Y, 5)) %>% 
    mutate(logpop_l1 = lag(logpop, 1)) %>% mutate(logpop_l2 = lag(logpop, 2)) %>% mutate(logpop_l3 = lag(logpop, 3)) %>%
    mutate(logpop_l4 = lag(logpop, 4)) %>% mutate(logpop_l5 = lag(logpop, 5)) %>% 
    mutate(tradewb_l1 = lag(tradewb, 1)) %>% mutate(tradewb_l2 = lag(tradewb, 2)) %>% mutate(tradewb_l3 = lag(tradewb, 3)) %>%
    mutate(tradewb_l4 = lag(tradewb, 4)) %>% mutate(tradewb_l5 = lag(tradewb, 5)) %>% 
    mutate(Populationages014oftotal_l1 = lag(Populationages014oftotal, 1)) %>% mutate(Populationages014oftotal_l2 = lag(Populationages014oftotal, 2)) %>% mutate(Populationages014oftotal_l3 = lag(Populationages014oftotal, 3)) %>%
    mutate(Populationages014oftotal_l4 = lag(Populationages014oftotal, 4)) %>% mutate(Populationages014oftotal_l5 = lag(Populationages014oftotal, 5)) %>% 
    mutate(Populationages1564oftota_l1 = lag(Populationages1564oftota, 1)) %>% mutate(Populationages1564oftota_l2 = lag(Populationages1564oftota, 2)) %>% mutate(Populationages1564oftota_l3 = lag(Populationages1564oftota, 3)) %>%
    mutate(Populationages1564oftota_l4 = lag(Populationages1564oftota, 4)) %>% mutate(Populationages1564oftota_l5 = lag(Populationages1564oftota, 5)) %>% 
    mutate(nfagdp_l1 = lag(nfagdp, 1)) %>% mutate(nfagdp_l2 = lag(nfagdp, 2)) %>% mutate(nfagdp_l3 = lag(nfagdp, 3)) %>%
    mutate(nfagdp_l4 = lag(nfagdp, 4)) %>% mutate(nfagdp_l5 = lag(nfagdp, 5)) %>% 
    mutate(unrest_l1 = lag(unrest, 1)) %>% mutate(unrest_l2 = lag(unrest, 2)) %>% mutate(unrest_l3 = lag(unrest, 3)) %>% 
    mutate(unrest_l4 = lag(unrest, 4)) %>% mutate(unrest_l5 = lag(unrest, 5))
  
  sim.data <- as.data.frame(sim.data)
  sim.data <- sim.data[order(sim.data[,"wbcode2"], sim.data[,"year"]), ]
  sim.data <- as_tibble(sim.data) %>% filter(., year > 1962)
  
  sim.data$history_L5 <- sim.data$dem_l1*2^(1-1) + sim.data$dem_l2*2^(2-1) + sim.data$dem_l3*2^(3-1) + 
    sim.data$dem_l4*2^(4-1) + sim.data$dem_l5*2^(5-1)
   
  sim.data$history_L4 <- sim.data$dem_l1*2^(1-1) + sim.data$dem_l2*2^(2-1) + sim.data$dem_l3*2^(3-1) + 
    sim.data$dem_l4*2^(4-1)
  sim.data$history_L3 <- sim.data$dem_l1*2^(1-1) + sim.data$dem_l2*2^(2-1) + sim.data$dem_l3*2^(3-1)
  
  # 000, 0 
  # 001, 4
  # 010,2
  # 011,6
  # 100,1
  # 101,5
  # 110,3
  # 111,7

  sim.data$history_L2 <- sim.data$dem_l1*2^(1-1) + sim.data$dem_l2*2^(2-1) #+ sim.data$dem_l3*2^(3-1)
  
  # 00, 0
  # 01, 2
  # 10 1
  # 11 3
  
  sim.data$history_L1 <- sim.data$dem_l1*2^(1-1)
  
  # sim.data$history_L5[sim.data$sim.X == 0] <- 99
  # sim.data$history_L4[sim.data$sim.X == 0] <- 99
  # sim.data$history_L3[sim.data$sim.X == 0] <- 99
  # sim.data$history_L2[sim.data$sim.X == 0] <- 99
  # sim.data$history_L1[sim.data$sim.X == 0] <- 99
  
  #print("finished simulation")
  return(sim.data)
  
}
