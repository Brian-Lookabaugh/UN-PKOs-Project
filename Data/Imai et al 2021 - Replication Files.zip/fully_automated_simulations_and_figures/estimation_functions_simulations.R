get.ols.estimate <- function(simulation, formula.input.ols)
{
  simulation <- simulation %>% rename(dem = sim.X, y = sim.Y)
  ymod <- lm(data = simulation,
             formula.input.ols,
             na.action = na.omit)
  #print('finished estimation')
  return(ymod$coefficients['dem'])
}


get.pe.estimate.maha <- function(simulation, formula.input, lag.in)#, idx)
{
  #print(idx)
  ssd <- select(simulation, wbcode2, year, sim.Y, sim.X, logpop, tradewb,
                Populationages014oftotal, Populationages1564oftota, nfagdp, unrest,
                logpop_l5, logpop_l4,logpop_l3, logpop_l2, logpop_l1,
                tradewb_l5, tradewb_l4, tradewb_l3,tradewb_l2,tradewb_l1,
                Populationages014oftotal_l5, Populationages014oftotal_l4,
                Populationages014oftotal_l3, Populationages014oftotal_l2, Populationages014oftotal_l1,
                Populationages1564oftota_l5,Populationages1564oftota_l4,
                Populationages1564oftota_l3,Populationages1564oftota_l2,Populationages1564oftota_l1,
                nfagdp_l5,nfagdp_l4, nfagdp_l3,nfagdp_l2,nfagdp_l1,
                unrest_l5, unrest_l4, unrest_l3, unrest_l2, unrest_l1,
                dem_l1, dem_l2, dem_l3, dem_l4, dem_l5)
  ssd <- as.data.frame(ssd)
  ssd$year <- ssd$year %>% as.integer()
  pm.sets <- PanelMatch(lag = lag.in, time.id = "year", unit.id = "wbcode2", treatment = "sim.X",
                        covs.formula = formula.input,
                        refinement.method = "mahalanobis", size.match = 10,
                        outcome.var = "sim.Y", lead = 0, qoi = "att", data = ssd, 
                        use.diagonal.variance.matrix = T, forbid.treatment.reversal = T,
                        listwise.delete = T, match.missing = F)
  
  balance_tmp <- abs(get_covariate_balance(matched.sets = pm.sets$att, 
                                           covariates = colnames(ssd)[5:45], 
                                           data = ssd))
  balance_tmp <- balance_tmp["t_0",]
  pm.balance <- c(mean(balance_tmp[grepl("_l1|_l2|_l3|_l4|_l5", names(balance_tmp)) == F], na.rm = T),
                  mean(balance_tmp[grepl("_l1", names(balance_tmp))], na.rm = T),
                  mean(balance_tmp[grepl("_l2", names(balance_tmp))], na.rm = T),
                  mean(balance_tmp[grepl("_l3", names(balance_tmp))], na.rm = T),
                  mean(balance_tmp[grepl("_l4", names(balance_tmp))], na.rm = T),
                  mean(balance_tmp[grepl("_l5", names(balance_tmp))], na.rm = T))
  names(pm.balance) <- c("L0", "L1", "L2", "L3", "L4", "L5")
  
  pe.results <- PanelEstimate(sets = pm.sets,  data = ssd, confidence.level = .9, 
                              se.method = "analytical")
  #print("finished estimation")
  # add balance here
  return(list(pm.sets, pe.results, pm.balance))
}

get.pe.estimate.cbps.weight <- function(simulation, formula.input, lag.in)
{
  ssd <- select(simulation, wbcode2, year, sim.Y, sim.X, logpop, tradewb,
                Populationages014oftotal, Populationages1564oftota, nfagdp, unrest,
                logpop_l5, logpop_l4,logpop_l3, logpop_l2, logpop_l1,
                tradewb_l5, tradewb_l4, tradewb_l3,tradewb_l2,tradewb_l1,
                Populationages014oftotal_l5, Populationages014oftotal_l4,
                Populationages014oftotal_l3, Populationages014oftotal_l2, Populationages014oftotal_l1,
                Populationages1564oftota_l5,Populationages1564oftota_l4,
                Populationages1564oftota_l3,Populationages1564oftota_l2,Populationages1564oftota_l1,
                nfagdp_l5,nfagdp_l4, nfagdp_l3,nfagdp_l2,nfagdp_l1,
                unrest_l5, unrest_l4, unrest_l3, unrest_l2, unrest_l1,
                dem_l1, dem_l2, dem_l3, dem_l4, dem_l5)
  ssd <- as.data.frame(ssd)
  ssd$year <- ssd$year %>% as.integer()
  pm.sets <- PanelMatch(lag = lag.in, time.id = "year", unit.id = "wbcode2", treatment = "sim.X",
                        covs.formula = formula.input,
                        refinement.method = "CBPS.weight",listwise.delete = T,
                        match.missing = F,
                        outcome.var = "sim.Y", lead = 0, qoi = "att", data = ssd, forbid.treatment.reversal = T)
  
  balance_tmp <- abs(get_covariate_balance(matched.sets = pm.sets$att, 
                                           covariates = colnames(ssd)[5:45], 
                                           data = ssd))
  balance_tmp <- balance_tmp["t_0",]
  pm.balance <- c(mean(balance_tmp[grepl("_l1|_l2|_l3|_l4|_l5", names(balance_tmp)) == F], na.rm = T),
                  mean(balance_tmp[grepl("_l1", names(balance_tmp))], na.rm = T),
                  mean(balance_tmp[grepl("_l2", names(balance_tmp))], na.rm = T),
                  mean(balance_tmp[grepl("_l3", names(balance_tmp))], na.rm = T),
                  mean(balance_tmp[grepl("_l4", names(balance_tmp))], na.rm = T),
                  mean(balance_tmp[grepl("_l5", names(balance_tmp))], na.rm = T))
  names(pm.balance) <- c("L0", "L1", "L2", "L3", "L4", "L5")
  
  pe.results <- PanelEstimate(sets = pm.sets,  data = ssd, confidence.level = .9,
                              se.method = "analytical")
  #print("finished estimation")
  return(list(pm.sets, pe.results, pm.balance))
}


get.pe.estimate.cbps.match <- function(simulation, formula.input, lag.in)
{
  ssd <- select(simulation, wbcode2, year, sim.Y, sim.X, logpop, tradewb,
                Populationages014oftotal, Populationages1564oftota, nfagdp, unrest,
                logpop_l5, logpop_l4,logpop_l3, logpop_l2, logpop_l1,
                tradewb_l5, tradewb_l4, tradewb_l3,tradewb_l2,tradewb_l1,
                Populationages014oftotal_l5, Populationages014oftotal_l4,
                Populationages014oftotal_l3, Populationages014oftotal_l2, Populationages014oftotal_l1,
                Populationages1564oftota_l5,Populationages1564oftota_l4,
                Populationages1564oftota_l3,Populationages1564oftota_l2,Populationages1564oftota_l1,
                nfagdp_l5,nfagdp_l4, nfagdp_l3,nfagdp_l2,nfagdp_l1,
                unrest_l5, unrest_l4, unrest_l3, unrest_l2, unrest_l1,
                dem_l1, dem_l2, dem_l3, dem_l4, dem_l5)
  ssd <- as.data.frame(ssd)
  ssd$year <- ssd$year %>% as.integer()
  pm.sets <- PanelMatch(lag = lag.in, time.id = "year", unit.id = "wbcode2", treatment = "sim.X",
                        covs.formula = formula.input,
                        refinement.method = "CBPS.match", size.match = 10,
                        listwise.delete = T,
                        match.missing = F,
                        outcome.var = "sim.Y", lead = 0, qoi = "att", 
                        data = ssd, forbid.treatment.reversal = T)
  balance_tmp <- abs(get_covariate_balance(matched.sets = pm.sets$att, 
                                           covariates = colnames(ssd)[5:45], 
                                           data = ssd))
  balance_tmp <- balance_tmp["t_0",]
  pm.balance <- c(mean(balance_tmp[grepl("_l1|_l2|_l3|_l4|_l5", names(balance_tmp)) == F], na.rm = T),
                  mean(balance_tmp[grepl("_l1", names(balance_tmp))], na.rm = T),
                  mean(balance_tmp[grepl("_l2", names(balance_tmp))], na.rm = T),
                  mean(balance_tmp[grepl("_l3", names(balance_tmp))], na.rm = T),
                  mean(balance_tmp[grepl("_l4", names(balance_tmp))], na.rm = T),
                  mean(balance_tmp[grepl("_l5", names(balance_tmp))], na.rm = T))
  names(pm.balance) <- c("L0", "L1", "L2", "L3", "L4", "L5")
  
  pe.results <- PanelEstimate(sets = pm.sets,  data = ssd, confidence.level = .9,
                              se.method = "analytical")
  #print("finished estimation")
  return(list(pm.sets, pe.results, pm.balance))
}

get.ols.model <- function(simulation, formula.input.ols)
{
  simulation <- simulation %>% rename(dem = sim.X, y = sim.Y)
  ymod <- lm(data = simulation,
             formula.input.ols,
             na.action = na.omit)
  #print('finished estimation')
  return(ymod)
}

do_simulations <- function(misspecified_formula, lag.input, ols.misspec,
                           ols.misspec2,
                           simulation_iterations, write.to.disk = TRUE, nametext = "")
{
  
  ols.estimates <- list()
  ols.estimates2 <- list()
  ols.models <- list()
  ols.models2 <- list()
  mahalanobis.estimates <- list()
  cbps.weight.estimates <- list()
  cbps.match.estimates <- list()
  
  
  for(k in 1:simulation_iterations)
  {
    print(paste("simulation: ", k))
    mult.sims <- parallel::mclapply(1:50, simulate_function, betas = betas, y.betas = y.betas,
                                    new.data = new.data, mc.cores = 50)
    ols.estimates[[k]] <- parallel::mclapply(mult.sims, get.ols.estimate, formula.input.ols = ols.misspec, mc.cores = 50)
    ols.estimates2[[k]] <- parallel::mclapply(mult.sims, get.ols.estimate, formula.input.ols = ols.misspec2, mc.cores = 50)
    ols.models[[k]] <- parallel::mclapply(mult.sims, get.ols.model, formula.input.ols = ols.misspec, mc.cores = 50)
    ols.models2[[k]] <- parallel::mclapply(mult.sims, get.ols.model, formula.input.ols = ols.misspec2, mc.cores = 50)
    mahalanobis.estimates[[k]] <- parallel::mclapply(mult.sims, get.pe.estimate.maha, lag.in = lag.input,
                                                     formula.input = misspecified_formula, mc.cores = 50)
    # lapply(mult.sims, get.pe.estimate.maha)
    #estimates.pe.ps.weight1 <- parallel::mclapply(mult.sims, get.pe.estimate.ps.weight, mc.cores = 50)
    #estimates.pe.ps.match1 <- parallel::mclapply(mult.sims, get.pe.estimate.ps.match, mc.cores = 50)
    cbps.weight.estimates[[k]] <- parallel::mclapply(mult.sims, get.pe.estimate.cbps.weight, lag.in = lag.input,
                                                     formula.input = misspecified_formula, mc.cores = 50)
    cbps.match.estimates[[k]] <- parallel::mclapply(mult.sims, get.pe.estimate.cbps.match, lag.in = lag.input,
                                                    formula.input = misspecified_formula, mc.cores = 50)
  }
  if(write.to.disk)
  {
    save(ols.estimates, file = paste0(nametext, "__", "ols.estimates.rda"))
    save(ols.models, file = paste0(nametext, "__", "ols.models.rda"))
    save(ols.estimates2, file = paste0(nametext, "__", "ols.estimates2.rda"))
    save(ols.models2, file = paste0(nametext, "__", "ols.models2.rda"))
    save(mahalanobis.estimates, file = paste0(nametext, "__","mahalanobis.estimates.rda"))
    save(cbps.weight.estimates, file = paste0(nametext, "__", "cbps.weight.estimates.rda"))
    save(cbps.match.estimates, file = paste0(nametext, "__", "cbps.match.estimates.rda"))
    
  }
  else {
    return(list(ols.estimates, ols.models, 
                ols.estimates2, ols.models2,
                mahalanobis.estimates, 
                cbps.weight.estimates, cbps.match.estimates))
  }
  
}
## do_simulations2 ## trying to prevent memory errors
do_simulations2 <- function(misspecified_formula, lag.input, ols.misspec,
                            ols.misspec2, n.cores = 50, draw.per.iter = 200,
                            simulation_iterations, write.to.disk = TRUE, nametext = "")
{
  
  # ols.estimates <- list()
  # ols.estimates2 <- list()
  # ols.models <- list()
  # ols.models2 <- list()
  # mahalanobis.estimates <- list()
  # cbps.weight.estimates <- list()
  # cbps.match.estimates <- list()
  
  
  for(k in 1:simulation_iterations)
  {
    print(paste("simulation: ", k))
    RNGkind("L'Ecuyer-CMRG")
    mult.sims <- parallel::mclapply(1:draw.per.iter, simulate_function, betas = betas, y.betas = y.betas,
                                    new.data = new.data, mc.cores = n.cores)
    RNGkind("L'Ecuyer-CMRG")
    ols.estimates <- 
      parallel::mclapply(mult.sims, get.ols.estimate, formula.input.ols = ols.misspec, mc.cores = n.cores)
    save(ols.estimates, file = paste0(nametext, "__", k, "ols.estimates.rda"))
    rm(ols.estimates)
    invisible(gc())
    RNGkind("L'Ecuyer-CMRG")
    ols.estimates2 <- 
      parallel::mclapply(mult.sims, get.ols.estimate, formula.input.ols = ols.misspec2, mc.cores = n.cores)
    save(ols.estimates2, file = paste0(nametext, "__",k, "ols.estimates2.rda"))
    rm(ols.estimates2)
    invisible(gc())
    RNGkind("L'Ecuyer-CMRG")
    ols.models <- 
      parallel::mclapply(mult.sims, get.ols.model, formula.input.ols = ols.misspec, mc.cores = n.cores)
    save(ols.models, file = paste0(nametext, "__",k, "ols.models.rda"))
    rm(ols.models)
    invisible(gc())
    RNGkind("L'Ecuyer-CMRG")
    ols.models2 <- 
      parallel::mclapply(mult.sims, get.ols.model, formula.input.ols = ols.misspec2, mc.cores = n.cores)
    save(ols.models2, file = paste0(nametext, "__",k, "ols.models2.rda"))
    rm(ols.models2)
    invisible(gc())
    RNGkind("L'Ecuyer-CMRG")
    mahalanobis.estimates <- 
      parallel::mclapply(mult.sims, get.pe.estimate.maha, lag.in = lag.input,
                         formula.input = misspecified_formula, mc.cores = n.cores)
    save(mahalanobis.estimates, file = paste0(nametext, "__",k,"mahalanobis.estimates.rda"))
    rm(mahalanobis.estimates)
    invisible(gc())
    # lapply(mult.sims, get.pe.estimate.maha)
    #estimates.pe.ps.weight1 <- parallel::mclapply(mult.sims, get.pe.estimate.ps.weight, mc.cores = 50)
    #estimates.pe.ps.match1 <- parallel::mclapply(mult.sims, get.pe.estimate.ps.match, mc.cores = 50)
    RNGkind("L'Ecuyer-CMRG")
    cbps.weight.estimates <- parallel::mclapply(mult.sims, get.pe.estimate.cbps.weight, lag.in = lag.input,
                                                formula.input = misspecified_formula, mc.cores = n.cores)
    save(cbps.weight.estimates, file = paste0(nametext, "__",k, "cbps.weight.estimates.rda"))
    rm(cbps.weight.estimates)
    invisible(gc())
    RNGkind("L'Ecuyer-CMRG")
    cbps.match.estimates <- parallel::mclapply(mult.sims, get.pe.estimate.cbps.match, lag.in = lag.input,
                                               formula.input = misspecified_formula, mc.cores = n.cores)
    save(cbps.match.estimates, file = paste0(nametext, "__",k, "cbps.match.estimates.rda"))
    rm(cbps.match.estimates)
    invisible(gc())
  }
  # if(write.to.disk)
  # {
  #   save(ols.estimates, file = paste0(nametext, "__", "ols.estimates.rda"))
  #   save(ols.models, file = paste0(nametext, "__", "ols.models.rda"))
  #   save(ols.estimates2, file = paste0(nametext, "__", "ols.estimates2.rda"))
  #   save(ols.models2, file = paste0(nametext, "__", "ols.models2.rda"))
  #   save(mahalanobis.estimates, file = paste0(nametext, "__","mahalanobis.estimates.rda"))
  #   save(cbps.weight.estimates, file = paste0(nametext, "__", "cbps.weight.estimates.rda"))
  #   save(cbps.match.estimates, file = paste0(nametext, "__", "cbps.match.estimates.rda"))
  #   
  # }
  # else {
  #   return(list(ols.estimates, ols.models, 
  #               ols.estimates2, ols.models2,
  #               mahalanobis.estimates, 
  #               cbps.weight.estimates, cbps.match.estimates))
  # }
  
}
