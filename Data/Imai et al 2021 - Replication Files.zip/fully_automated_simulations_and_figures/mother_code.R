# 
## R version: 3.4.1 (2017-06-30)
## m5d.24xlarge
## Run mother_code_50.R first
# clean slate
rm(list=ls())
# first, set to this directory
setwd("~/fully_automated_simulations_and_figures/")
# clean to save space
system("rm -rf simulation_data")
system("rm -rf simulation_data_2")
system("rm -rf simulation_data_3")
# then, do -1, -0.5, 0, 0.5, 1, one by one

## -1
set.seed(2020)
# doing the command replace
system("sed -i.bak 's/TREATMENT_EFFECT_TRUTH = -7.5/TREATMENT_EFFECT_TRUTH = -1/g' data_function_simulations.R")
system("sed -i.bak 's/TREATMENT_EFFECT_TRUTH = -7.5/TREATMENT_EFFECT_TRUTH = -1/g' calculations_and_figure.R")
#system("sed -i.bak 's/TREATMENT_EFFECT_TRUTH = -7.5/TREATMENT_EFFECT_TRUTH = -1/g' calculations_and_figures2.R")
#system("sed -i.bak 's/n_1000_1/n_1000_n1/g' calculations_and_figure.R")
system("sed -i.bak 's/n_1000_n75/n_1000_n1/g' calculations_and_figure.R")

source("perform_simulations.R")
setwd("~/fully_automated_simulations_and_figures/")
source("calculations_and_figure.R")
# clean to save space
system("rm -rf simulation_data")
system("rm -rf simulation_data_2")
system("rm -rf simulation_data_3")
rm(list=ls())
# library(rstudioapi)
# restartSession(command = "print('x')")
setwd("~/fully_automated_simulations_and_figures/")

## -0.5
set.seed(2020)
system("sed -i.bak 's/TREATMENT_EFFECT_TRUTH = -1/TREATMENT_EFFECT_TRUTH = -0.5/g' data_function_simulations.R")
system("sed -i.bak 's/TREATMENT_EFFECT_TRUTH = -1/TREATMENT_EFFECT_TRUTH = -0.5/g' calculations_and_figure.R")
system("sed -i.bak 's/n_1000_n1/n_1000_n05/g' calculations_and_figure.R")
#system("sed -i.bak 's/n_1000_n1/n_1000_n05/g' calculations_and_figures2.R")
source("perform_simulations.R")
setwd("~/fully_automated_simulations_and_figures/")
source("calculations_and_figure.R")

# clean to save space
system("rm -rf simulation_data")
system("rm -rf simulation_data_2")
system("rm -rf simulation_data_3")
rm(list=ls())
# library(rstudioapi)
# restartSession(command = "print('x')")
setwd("~/fully_automated_simulations_and_figures/")

## 0
set.seed(2020)
system("sed -i.bak 's/TREATMENT_EFFECT_TRUTH = -0.5/TREATMENT_EFFECT_TRUTH = 0/g' data_function_simulations.R")
system("sed -i.bak 's/TREATMENT_EFFECT_TRUTH = -0.5/TREATMENT_EFFECT_TRUTH = 0/g' calculations_and_figure.R")
system("sed -i.bak 's/n_1000_n05/n_1000_n0/g' calculations_and_figure.R")
source("perform_simulations.R")
setwd("~/fully_automated_simulations_and_figures/")
source("calculations_and_figure.R")

# clean to save space
system("rm -rf simulation_data")
system("rm -rf simulation_data_2")
system("rm -rf simulation_data_3")
rm(list=ls())
# library(rstudioapi)
# restartSession(command = "print('x')")
setwd("~/fully_automated_simulations_and_figures/")

## 0.5
set.seed(2020)
system("sed -i.bak 's/TREATMENT_EFFECT_TRUTH = 0/TREATMENT_EFFECT_TRUTH = 0.5/g' data_function_simulations.R")
system("sed -i.bak 's/TREATMENT_EFFECT_TRUTH = 0/TREATMENT_EFFECT_TRUTH = 0.5/g' calculations_and_figure.R")
system("sed -i.bak 's/n_1000_n0/n_1000_05/g' calculations_and_figure.R")
source("perform_simulations.R")
setwd("~/fully_automated_simulations_and_figures/")
source("calculations_and_figure.R")

# clean to save space
system("rm -rf simulation_data")
system("rm -rf simulation_data_2")
system("rm -rf simulation_data_3")
rm(list=ls())
# library(rstudioapi)
# restartSession(command = "print('x')")
setwd("~/fully_automated_simulations_and_figures/")

## 1
set.seed(2020)
system("sed -i.bak 's/TREATMENT_EFFECT_TRUTH = 0.5/TREATMENT_EFFECT_TRUTH = 1/g' data_function_simulations.R")
system("sed -i.bak 's/TREATMENT_EFFECT_TRUTH = 0.5/TREATMENT_EFFECT_TRUTH = 1/g' calculations_and_figure.R")
system("sed -i.bak 's/n_1000_05/n_1000_1/g' calculations_and_figure.R")
source("perform_simulations.R")
setwd("~/fully_automated_simulations_and_figures/")
source("calculations_and_figure.R")

# clean to save space
system("rm -rf simulation_data")
system("rm -rf simulation_data_2")
system("rm -rf simulation_data_3")
rm(list=ls())
# library(rstudioapi)
# restartSession(command = "print('x')")
setwd("~/fully_automated_simulations_and_figures/")

## -7.5, N = 162
set.seed(2020)
system("sed -i.bak 's/TREATMENT_EFFECT_TRUTH = 1/TREATMENT_EFFECT_TRUTH = -7.5/g' data_function_simulations.R")
system("sed -i.bak 's/TREATMENT_EFFECT_TRUTH = 1/TREATMENT_EFFECT_TRUTH = -7.5/g' calculations_and_figure.R")
system("sed -i.bak 's/n_1000_1/n_1000_n75/g' calculations_and_figure.R")

source("perform_simulations.R")
setwd("~/fully_automated_simulations_and_figures/")
source("calculations_and_figure.R")

# clean to save space
system("rm -rf simulation_data")
system("rm -rf simulation_data_2")
system("rm -rf simulation_data_3")
rm(list=ls())
setwd("~/fully_automated_simulations_and_figures/")



# ## -7.5, N = 50
# 
# system("sed -i.bak 's/TREATMENT_EFFECT_TRUTH = 1/TREATMENT_EFFECT_TRUTH = -7.5/g' other_N.R")
# system("sed -i.bak 's/TREATMENT_EFFECT_TRUTH = 1/TREATMENT_EFFECT_TRUTH = -7.5/g' calculations_and_figure.R")
# system("sed -i.bak 's/n_1000_1/n_1000_n75_50/g' calculations_and_figure.R")
# source("perform_simulations_50.R")
# setwd("~/fully_automated_simulations_and_figures/")
# source("calculations_and_figure.R")



