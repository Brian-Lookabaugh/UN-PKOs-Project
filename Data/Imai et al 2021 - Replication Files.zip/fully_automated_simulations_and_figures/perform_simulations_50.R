# clean slate
rm(list=ls())
library(dplyr)
library(PanelMatch)
setwd("~/fully_automated_simulations_and_figures/")
set.seed(2020)
source("./other_N.R") # still an error as of June 21
source("./estimation_functions_simulations.R")
current.dir <- getwd()
print("doing one lag models")
dir.create("simulation_data")
dir.create("simulation_data_2")
dir.create("simulation_data_3")
setwd(paste0(current.dir, "/", "simulation_data"))

# one_lag <- 
do_simulations2(misspecified_formula = ~ logpop + logpop_l1 +
                  tradewb + tradewb_l1 +
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages1564oftota + Populationages1564oftota_l1 +
                  nfagdp + nfagdp_l1 +
                  unrest + unrest_l1 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1, lag.input = 1, 
                
                ols.misspec = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 +
                  tradewb + tradewb_l1 +
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages1564oftota + Populationages1564oftota_l1 +
                  nfagdp + nfagdp_l1 +
                  unrest + unrest_l1 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  dem + dem_l1 - 1,
                
                ols.misspec2 = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 +
                  tradewb + tradewb_l1 +
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages1564oftota + Populationages1564oftota_l1 +
                  nfagdp + nfagdp_l1 +
                  unrest + unrest_l1 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  dem + as.factor(history_L1) - 1,
                draw.per.iter = 50, n.cores = 50,
                simulation_iterations = 6,  write.to.disk = T, nametext = "one_lag___")
# save(one_lag, file = "/home/erikh.wang/fully_automated_simulations_and_figures/simulation_data/one_lag.RData")

print("doing two lag models")

# two_lags <- 
do_simulations2(misspecified_formula = ~ logpop + logpop_l1 + logpop_l2 +
                  tradewb + tradewb_l1 + tradewb_l2 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 +
                  unrest + unrest_l1 + unrest_l2 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2,
                lag.input = 2, 
                
                ols.misspec = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 + logpop_l2 +
                  tradewb + tradewb_l1 + tradewb_l2 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 +
                  unrest + unrest_l1 + unrest_l2 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  dem + dem_l1 + dem_l2 - 1,
                
                ols.misspec2 = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 + logpop_l2 +
                  tradewb + tradewb_l1 + tradewb_l2 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 +
                  unrest + unrest_l1 + unrest_l2 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  dem + as.factor(history_L2) - 1,
                draw.per.iter = 50, n.cores = 50,
                simulation_iterations = 6,  write.to.disk = T, nametext = "two_lag___")
#save(two_lags, file = "/home/erikh.wang/fully_automated_simulations_and_figures/simulation_data/two_lags.RData")

print('doing correct specifications')

# three_lags <- 
do_simulations2(misspecified_formula = ~ logpop + logpop_l1 + logpop_l2 + logpop_l3 +
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 +
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3,
                lag.input = 3, 
                
                ols.misspec = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 + logpop_l2 + logpop_l3 +
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 +
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  dem + dem_l1 + dem_l2 + dem_l3 - 1,
                
                ols.misspec2 = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 + logpop_l2 + logpop_l3 +
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 +
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  dem + as.factor(history_L3) - 1,
                draw.per.iter = 50, n.cores = 50,
                simulation_iterations = 6,  write.to.disk = TRUE, nametext = "three_lag___")
# save(three_lags, file = "/home/erikh.wang/fully_automated_simulations_and_figures/simulation_data/three_lags.RData")
print('doing four-lag specifications')
# four_lags
do_simulations2(misspecified_formula = ~ logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + 
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + 
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 + 
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l4 * logpop_l4,
                lag.input = 4, 
                
                ols.misspec = y ~ factor(wbcode2) + factor(year) + 
                  logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + 
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 +
                  Populationages1564oftota + Populationages1564oftota_l1 + 
                  Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + 
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l4 * logpop_l4 +
                  dem + dem_l1 + dem_l2 + dem_l3 + dem_l4 - 1,
                
                ols.misspec2 = y ~ factor(wbcode2) + factor(year) + 
                  logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + 
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 +
                  Populationages1564oftota + Populationages1564oftota_l1 + 
                  Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + 
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l4 * logpop_l4 +
                  dem + as.factor(history_L4) - 1,
                draw.per.iter = 50, n.cores = 50,
                simulation_iterations = 6,  write.to.disk = TRUE, nametext = "four_lag___")

print('doing five-lag specifications')
# five_lags
do_simulations2(misspecified_formula = ~ logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + logpop_l5 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + tradewb_l5 + 
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 + Populationages014oftotal_l5 + 
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 + Populationages1564oftota_l5 + 
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + nfagdp_l5 + 
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + unrest_l5 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 + 
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l5 * logpop_l5 + 
                  tradewb_l5 * logpop_l5 +
                  Populationages014oftotal_l5 * logpop_l5 +
                  Populationages1564oftota_l5 * logpop_l5 +
                  nfagdp_l5 * logpop_l5,
                lag.input = 5, 
                
                ols.misspec = y ~ factor(wbcode2) + factor(year) + 
                  logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + logpop_l5 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + tradewb_l5 + 
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 + Populationages014oftotal_l5 + 
                  Populationages1564oftota + Populationages1564oftota_l1 + 
                  Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 + Populationages1564oftota_l5 + 
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + nfagdp_l5 +
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + unrest_l5 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l4 * logpop_l4 +
                  tradewb_l5 * logpop_l5 +
                  Populationages014oftotal_l5 * logpop_l5 +
                  Populationages1564oftota_l5 * logpop_l5 +
                  nfagdp_l5 * logpop_l5 +
                  dem + dem_l1 + dem_l2 + dem_l3 + dem_l4 + dem_l5 - 1,
                
                ols.misspec2 = y ~ factor(wbcode2) + factor(year) + 
                  logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + logpop_l5 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + tradewb_l5 + 
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 + Populationages014oftotal_l5 + 
                  Populationages1564oftota + Populationages1564oftota_l1 + 
                  Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 + Populationages1564oftota_l5 + 
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + nfagdp_l5 +
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + unrest_l5 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l4 * logpop_l4 +
                  tradewb_l5 * logpop_l5 +
                  Populationages014oftotal_l5 * logpop_l5 +
                  Populationages1564oftota_l5 * logpop_l5 +
                  nfagdp_l5 * logpop_l5 +
                  dem + as.factor(history_L5) - 1,
                draw.per.iter = 50, n.cores = 50,
                simulation_iterations = 6,  write.to.disk = TRUE, nametext = "five_lag___")

print("first batch of simulations completed")
setwd(paste0(current.dir, "/", "simulation_data_2"))

do_simulations2(misspecified_formula = ~ logpop + logpop_l1 +
                  tradewb + tradewb_l1 +
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages1564oftota + Populationages1564oftota_l1 +
                  nfagdp + nfagdp_l1 +
                  unrest + unrest_l1 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1, lag.input = 1, 
                
                ols.misspec = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 +
                  tradewb + tradewb_l1 +
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages1564oftota + Populationages1564oftota_l1 +
                  nfagdp + nfagdp_l1 +
                  unrest + unrest_l1 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  dem + dem_l1 - 1,
                ols.misspec2 = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 +
                  tradewb + tradewb_l1 +
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages1564oftota + Populationages1564oftota_l1 +
                  nfagdp + nfagdp_l1 +
                  unrest + unrest_l1 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  dem + as.factor(history_L1) - 1,
                draw.per.iter = 50, n.cores = 50,
                simulation_iterations = 6, write.to.disk = TRUE, nametext = "one_lag___")



print("doing two lag models")

do_simulations2(misspecified_formula = ~ logpop + logpop_l1 + logpop_l2 +
                  tradewb + tradewb_l1 + tradewb_l2 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 +
                  unrest + unrest_l1 + unrest_l2 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2,
                lag.input = 2, 
                
                ols.misspec = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 + logpop_l2 +
                  tradewb + tradewb_l1 + tradewb_l2 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 +
                  unrest + unrest_l1 + unrest_l2 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  dem + dem_l1 + dem_l2 - 1,
                
                ols.misspec2 = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 + logpop_l2 +
                  tradewb + tradewb_l1 + tradewb_l2 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 +
                  unrest + unrest_l1 + unrest_l2 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  dem + as.factor(history_L2) - 1,
                draw.per.iter = 50, n.cores = 50,
                simulation_iterations = 6,  write.to.disk = TRUE, nametext = "two_lag___")


print('doing correct specifications')


do_simulations2(misspecified_formula = ~ logpop + logpop_l1 + logpop_l2 + logpop_l3 +
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 +
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3,
                lag.input = 3, 
                
                ols.misspec = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 + logpop_l2 + logpop_l3 +
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 +
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  dem + dem_l1 + dem_l2 + dem_l3 - 1,
                
                ols.misspec2 = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 + logpop_l2 + logpop_l3 +
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 +
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  dem + as.factor(history_L3) - 1,
                draw.per.iter = 50, n.cores = 50,
                simulation_iterations = 6,  write.to.disk = TRUE, nametext = "three_lag___")

######
print('doing four-lag specifications')
# four_lags
do_simulations2(misspecified_formula = ~ logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + 
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + 
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 + 
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l4 * logpop_l4,
                lag.input = 4, 
                
                ols.misspec = y ~ factor(wbcode2) + factor(year) + 
                  logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + 
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 +
                  Populationages1564oftota + Populationages1564oftota_l1 + 
                  Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + 
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l4 * logpop_l4 +
                  dem + dem_l1 + dem_l2 + dem_l3 + dem_l4 - 1,
                
                ols.misspec2 = y ~ factor(wbcode2) + factor(year) + 
                  logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + 
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 +
                  Populationages1564oftota + Populationages1564oftota_l1 + 
                  Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + 
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l4 * logpop_l4 +
                  dem + as.factor(history_L4) - 1,
                draw.per.iter = 50, n.cores = 50,
                simulation_iterations = 6,  write.to.disk = TRUE, nametext = "four_lag___")

print('doing five-lag specifications')
# five_lags
do_simulations2(misspecified_formula = ~ logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + logpop_l5 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + tradewb_l5 + 
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 + Populationages014oftotal_l5 + 
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 + Populationages1564oftota_l5 + 
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + nfagdp_l5 + 
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + unrest_l5 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 + 
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l5 * logpop_l5 + 
                  tradewb_l5 * logpop_l5 +
                  Populationages014oftotal_l5 * logpop_l5 +
                  Populationages1564oftota_l5 * logpop_l5 +
                  nfagdp_l5 * logpop_l5,
                lag.input = 5, 
                
                ols.misspec = y ~ factor(wbcode2) + factor(year) + 
                  logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + logpop_l5 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + tradewb_l5 + 
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 + Populationages014oftotal_l5 + 
                  Populationages1564oftota + Populationages1564oftota_l1 + 
                  Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 + Populationages1564oftota_l5 + 
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + nfagdp_l5 +
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + unrest_l5 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l4 * logpop_l4 +
                  tradewb_l5 * logpop_l5 +
                  Populationages014oftotal_l5 * logpop_l5 +
                  Populationages1564oftota_l5 * logpop_l5 +
                  nfagdp_l5 * logpop_l5 +
                  dem + dem_l1 + dem_l2 + dem_l3 + dem_l4 + dem_l5 - 1,
                
                ols.misspec2 = y ~ factor(wbcode2) + factor(year) + 
                  logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + logpop_l5 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + tradewb_l5 + 
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 + Populationages014oftotal_l5 + 
                  Populationages1564oftota + Populationages1564oftota_l1 + 
                  Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 + Populationages1564oftota_l5 + 
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + nfagdp_l5 +
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + unrest_l5 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l4 * logpop_l4 +
                  tradewb_l5 * logpop_l5 +
                  Populationages014oftotal_l5 * logpop_l5 +
                  Populationages1564oftota_l5 * logpop_l5 +
                  nfagdp_l5 * logpop_l5 +
                  dem + as.factor(history_L5) - 1,
                draw.per.iter = 50, n.cores = 50,
                simulation_iterations = 6, write.to.disk = TRUE, nametext = "five_lag___")


print("second batch of simulations completed")
setwd(paste0(current.dir, "/", "simulation_data_3"))

do_simulations2(misspecified_formula = ~ logpop + logpop_l1 +
                  tradewb + tradewb_l1 +
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages1564oftota + Populationages1564oftota_l1 +
                  nfagdp + nfagdp_l1 +
                  unrest + unrest_l1 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1, lag.input = 1, 
                
                ols.misspec = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 +
                  tradewb + tradewb_l1 +
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages1564oftota + Populationages1564oftota_l1 +
                  nfagdp + nfagdp_l1 +
                  unrest + unrest_l1 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  dem + dem_l1 - 1,
                
                ols.misspec2 = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 +
                  tradewb + tradewb_l1 +
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages1564oftota + Populationages1564oftota_l1 +
                  nfagdp + nfagdp_l1 +
                  unrest + unrest_l1 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  dem + as.factor(history_L1) - 1,
                draw.per.iter = 50, n.cores = 50,
                simulation_iterations = 8,  write.to.disk = TRUE, nametext = "one_lag___")



print("doing two lag models")

do_simulations2(misspecified_formula = ~ logpop + logpop_l1 + logpop_l2 +
                  tradewb + tradewb_l1 + tradewb_l2 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 +
                  unrest + unrest_l1 + unrest_l2 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2,
                lag.input = 2, 
                
                ols.misspec = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 + logpop_l2 +
                  tradewb + tradewb_l1 + tradewb_l2 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 +
                  unrest + unrest_l1 + unrest_l2 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  dem + dem_l1 + dem_l2 - 1,
                
                ols.misspec2 = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 + logpop_l2 +
                  tradewb + tradewb_l1 + tradewb_l2 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 +
                  unrest + unrest_l1 + unrest_l2 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  dem + as.factor(history_L2) - 1,
                draw.per.iter = 50, n.cores = 50,
                simulation_iterations = 8, write.to.disk = TRUE, nametext = "two_lag___")


print('doing correct specifications')


do_simulations2(misspecified_formula = ~ logpop + logpop_l1 + logpop_l2 + logpop_l3 +
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 +
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3,
                lag.input = 3, 
                
                ols.misspec = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 + logpop_l2 + logpop_l3 +
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 +
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  dem + dem_l1 + dem_l2 + dem_l3 - 1,
                
                ols.misspec2 = y ~ factor(wbcode2) + factor(year) + logpop + logpop_l1 + logpop_l2 + logpop_l3 +
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 +
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 +
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 +
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  dem + as.factor(history_L3) - 1,
                draw.per.iter = 50, n.cores = 50,
                simulation_iterations = 8, write.to.disk = TRUE, nametext = "three_lag___")

##
print('doing four-lag specifications')
# four_lags
do_simulations2(misspecified_formula = ~ logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + 
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 +
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + 
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 + 
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l4 * logpop_l4,
                lag.input = 4, 
                
                ols.misspec = y ~ factor(wbcode2) + factor(year) + 
                  logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + 
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 +
                  Populationages1564oftota + Populationages1564oftota_l1 + 
                  Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + 
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l4 * logpop_l4 +
                  dem + dem_l1 + dem_l2 + dem_l3 + dem_l4 - 1,
                
                ols.misspec2 = y ~ factor(wbcode2) + factor(year) + 
                  logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + 
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 +
                  Populationages1564oftota + Populationages1564oftota_l1 + 
                  Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 +
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + 
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l4 * logpop_l4 +
                  dem + as.factor(history_L4) - 1,
                draw.per.iter = 50, n.cores = 50,
                simulation_iterations = 8, write.to.disk = TRUE, nametext = "four_lag___")

print('doing five-lag specifications')
# five_lags
do_simulations2(misspecified_formula = ~ logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + logpop_l5 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + tradewb_l5 + 
                  Populationages014oftotal + Populationages014oftotal_l1 + Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 + Populationages014oftotal_l5 + 
                  Populationages1564oftota + Populationages1564oftota_l1 + Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 + Populationages1564oftota_l5 + 
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + nfagdp_l5 + 
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + unrest_l5 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 + 
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l5 * logpop_l5 + 
                  tradewb_l5 * logpop_l5 +
                  Populationages014oftotal_l5 * logpop_l5 +
                  Populationages1564oftota_l5 * logpop_l5 +
                  nfagdp_l5 * logpop_l5,
                lag.input = 5, 
                
                ols.misspec = y ~ factor(wbcode2) + factor(year) + 
                  logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + logpop_l5 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + tradewb_l5 + 
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 + Populationages014oftotal_l5 + 
                  Populationages1564oftota + Populationages1564oftota_l1 + 
                  Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 + Populationages1564oftota_l5 + 
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + nfagdp_l5 +
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + unrest_l5 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l4 * logpop_l4 +
                  tradewb_l5 * logpop_l5 +
                  Populationages014oftotal_l5 * logpop_l5 +
                  Populationages1564oftota_l5 * logpop_l5 +
                  nfagdp_l5 * logpop_l5 +
                  dem + dem_l1 + dem_l2 + dem_l3 + dem_l4 + dem_l5 - 1,
                
                ols.misspec2 = y ~ factor(wbcode2) + factor(year) + 
                  logpop + logpop_l1 + logpop_l2 + logpop_l3 + logpop_l4 + logpop_l5 + 
                  tradewb + tradewb_l1 + tradewb_l2 + tradewb_l3 + tradewb_l4 + tradewb_l5 + 
                  Populationages014oftotal + Populationages014oftotal_l1 +
                  Populationages014oftotal_l2 + Populationages014oftotal_l3 +
                  Populationages014oftotal_l4 + Populationages014oftotal_l5 + 
                  Populationages1564oftota + Populationages1564oftota_l1 + 
                  Populationages1564oftota_l2 + Populationages1564oftota_l3 +
                  Populationages1564oftota_l4 + Populationages1564oftota_l5 + 
                  nfagdp + nfagdp_l1 + nfagdp_l2 + nfagdp_l3 + nfagdp_l4 + nfagdp_l5 +
                  unrest + unrest_l1 + unrest_l2 + unrest_l3 + unrest_l4 + unrest_l5 + 
                  tradewb * logpop +
                  Populationages014oftotal * logpop +
                  Populationages1564oftota * logpop +
                  nfagdp * logpop +
                  tradewb_l1 * logpop_l1 +
                  Populationages014oftotal_l1 * logpop_l1 +
                  Populationages1564oftota_l1 * logpop_l1 +
                  nfagdp_l1 * logpop_l1 +
                  tradewb_l2 * logpop_l2 +
                  Populationages014oftotal_l2 * logpop_l2 +
                  Populationages1564oftota_l2 * logpop_l2 +
                  nfagdp_l2 * logpop_l2 +
                  tradewb_l3 * logpop_l3 +
                  Populationages014oftotal_l3 * logpop_l3 +
                  Populationages1564oftota_l3 * logpop_l3 +
                  nfagdp_l3 * logpop_l3 +
                  tradewb_l4 * logpop_l4 +
                  Populationages014oftotal_l4 * logpop_l4 +
                  Populationages1564oftota_l4 * logpop_l4 +
                  nfagdp_l4 * logpop_l4 +
                  tradewb_l5 * logpop_l5 +
                  Populationages014oftotal_l5 * logpop_l5 +
                  Populationages1564oftota_l5 * logpop_l5 +
                  nfagdp_l5 * logpop_l5 +
                  dem + as.factor(history_L5) - 1,
                draw.per.iter = 50, n.cores = 50,
                simulation_iterations = 8, write.to.disk = TRUE, nametext = "five_lag___")

print("all simulations completed. Please use calculations_and_figure.R to generate the plot")