bias_plot_summary <- function(true.treatment.effect, ols.results, ps.maha.results, ps.matching.results, 
                              ps.weight.results, cbps.match.results, cbps.weight.results, y.axis.limits = c(-2, 2), model.detail = "")
{
  #assume each set of *.results is a list
  
  ols.bias.results = numeric(length(ols.results))
  for(j in 1:length(ols.results))
  {
    res <- unlist(ols.results[1:j])
    bias1 = mean(res) - true.treatment.effect
    ols.bias.results[j] <- bias1
  }
  ps.maha.bias.results = numeric(length(ps.maha.results))
  for(j in 1:length(ps.maha.results))
  {
    res <- unlist(ps.maha.results[1:j])
    bias1 = mean(res) - true.treatment.effect
    ps.maha.bias.results[j] <- bias1
  }
  ps.matching.bias.results = numeric(length(ps.matching.results))
  for(j in 1:length(ps.matching.results))
  {
    res <- unlist(ps.matching.results[1:j])
    bias1 = mean(res) - true.treatment.effect
    ps.matching.bias.results[j] <- bias1
  }
  ps.weight.bias.results = numeric(length(ps.weight.results))
  for(j in 1:length(ps.weight.results))
  {
    res <- unlist(ps.weight.results[1:j])
    
    bias1 = mean(res) - true.treatment.effect
    ps.weight.bias.results[j] <- bias1
  }
  cbps.weight.bias.results = numeric(length(cbps.weight.results))
  for(j in 1:length(cbps.weight.results))
  {
    res <- unlist(cbps.weight.results[1:j])
    
    bias1 = mean(res) - true.treatment.effect
    cbps.weight.bias.results[j] <- bias1
  }
  cbps.match.bias.results = numeric(length(cbps.match.results))
  for(j in 1:length(cbps.match.results))
  {
    res <- unlist(cbps.match.results[1:j])
    
    bias1 = mean(res) - true.treatment.effect
    cbps.match.bias.results[j] <- bias1
  }
  
  #par(mfrow=c(2,3))
  par(mfrow=c(2,3),mar=c(4,4,0.5,0.5) + 1, oma=c(1.5,2,1,1) + 2)
  plot(ols.bias.results, type = "b", xlab = "# simulations", ylab = "bias", main = "OLS", ylim = y.axis.limits, xaxt = "n")
  axis(1, at=1:4, labels=c("70", "140", "210", "280"))
  abline(h = 0, col = "red")
  plot(ps.maha.bias.results, type = "b", xlab = "# simulations", ylab = "bias", main = "maha", ylim = y.axis.limits, xaxt = "n")
  axis(1, at=1:4, labels=c("70", "140", "210", "280"))
  abline(h = 0, col = "red")
  
  plot(ps.matching.bias.results, type = "b", xlab = "# simulations", ylab = "bias", main = "ps match", ylim = y.axis.limits, xaxt = "n")
  axis(1, at=1:4, labels=c("70", "140", "210", "280"))
  abline(h = 0, col = "red")
  
  plot(ps.weight.bias.results, type = "b", xlab = "# simulations", ylab = "bias", main = "ps weight", ylim = y.axis.limits, xaxt = "n")
  axis(1, at=1:4, labels=c("70", "140", "210", "280"))
  abline(h = 0, col = "red")
  
  plot(cbps.match.bias.results, type = "b", xlab = "# simulations", ylab = "bias", main = "cbps match", ylim = y.axis.limits, xaxt = "n")
  axis(1, at=1:4, labels=c("70", "140", "210", "280"))
  abline(h = 0, col = "red")
  
  plot(cbps.weight.bias.results, type = "b", xlab = "# simulations", ylab = "bias", main = "cbps weight", ylim = y.axis.limits, xaxt = "n")
  axis(1, at=1:4, labels=c("70", "140", "210", "280"))
  abline(h = 0, col = "red")
  mtext(paste0("Bias for ", model.detail, " models"), side = 3, outer = TRUE, line = .5)
}

simple_bias_plot <- function(true.treatment.effect, ols.results, ps.maha.results, ps.weight.results, ps.matching.results, 
                             cbps.weight.results, cbps.match.results, y.axis.limits = c(-2, 2), model.detail = "")
{

  
  res <- unlist(ols.results)
  bias1 = mean(res) - true.treatment.effect
  
  res <- unlist(ps.maha.results)
  bias2 = mean(res) - true.treatment.effect
  
  res <- unlist(ps.matching.results)
  bias3 = mean(res) - true.treatment.effect
  
  res <- unlist(ps.weight.results)
  bias4 = mean(res) - true.treatment.effect
  
  res <- unlist(cbps.weight.results)
  bias5 = mean(res) - true.treatment.effect

  res <- unlist(cbps.match.results)
  bias6 = mean(res) - true.treatment.effect
  
  bias.vec <- c(bias1, bias2, bias4, bias3, bias5, bias6) # weight, match weight match
  
  plot(bias.vec, xlab = "method", ylab = "bias", main = paste0("Bias by method", " ", model.detail), 
       xaxt = "n", ylim = y.axis.limits, pch = 19, cex = 1.2, cex.axis = 1.2, cex.lab = 1.2)
  
  axis(1, at=1:6, labels=c("OLS", "maha", "ps weight", "ps match", 
                           "cbps weight", "cbps match"), cex.axis = 1.2)
  abline(h = 0, col = "red")
  
}


make_sd_plot <- function(full.ols.results, full.maha.results, full.ps.weight.results,
                         full.ps.match.results, full.cbps.weight.results, full.cbps.match.results, model.detail = "")
{
  tdf <- data.frame("OLS" = sd(full.ols.results), 
                    "maha" = sd(full.maha.results), "ps.weight" = sd(full.ps.weight.results),
                    "ps.match" = sd(full.ps.match.results), 
                    "cbps.weight" = sd(full.cbps.weight.results), "cbps.match" = sd(full.cbps.match.results))
  plot(x = as.numeric(tdf[1,]), main = paste0("Standard Deviation of Estimates", " ", model.detail),
       xaxt = "n", ylab = "SD", xlab = "method", pch = 19, cex = 1.2, cex.axis = 1.2, cex.lab = 1.2, ylim = c(.3, .9))
  axis(1, at = 1:6, labels = colnames(tdf), cex.axis = 1.2)
}


prep_data_for_coverage <- function(estimates.pe.maha1, estimates.pe.maha2, estimates.pe.maha3, estimates.pe.maha4,
                                   estimates.pe.ps.match1, estimates.pe.ps.match2, estimates.pe.ps.match3, estimates.pe.ps.match4,
                                   estimates.pe.ps.weight1, estimates.pe.ps.weight2, estimates.pe.ps.weight3, estimates.pe.ps.weight4,
                                   estimates.pe.cbps.weight1, estimates.pe.cbps.weight2, estimates.pe.cbps.weight3, estimates.pe.cbps.weight4,
                                   estimates.pe.cbps.match1, estimates.pe.cbps.match2, estimates.pe.cbps.match3, estimates.pe.cbps.match4,
                                   ols.models1, ols.models2, ols.models3, ols.models4)
{
  estimates.pe.maha <- c(lapply(estimates.pe.maha1, function(x) x[[2]]),
                         lapply(estimates.pe.maha2, function(x) x[[2]]),
                         lapply(estimates.pe.maha3, function(x) x[[2]]), 
                         lapply(estimates.pe.maha4, function(x) x[[2]]))
  
  estimates.pe.ps.match <- c(lapply(estimates.pe.ps.match1, function(x) x[[2]]),
                             lapply(estimates.pe.ps.match2, function(x) x[[2]]),
                             lapply(estimates.pe.ps.match3, function(x) x[[2]]), 
                             lapply(estimates.pe.ps.match4, function(x) x[[2]]))
  
  
  estimates.pe.ps.weight <- c(lapply(estimates.pe.ps.weight1, function(x) x[[2]]),
                              lapply(estimates.pe.ps.weight2, function(x) x[[2]]),
                              lapply(estimates.pe.ps.weight3, function(x) x[[2]]), 
                              lapply(estimates.pe.ps.weight4, function(x) x[[2]]))
  
  
  estimates.pe.cbps.weight <- c(lapply(estimates.pe.cbps.weight1, function(x) x[[2]]),
                                lapply(estimates.pe.cbps.weight2, function(x) x[[2]]),
                                lapply(estimates.pe.cbps.weight3, function(x) x[[2]]), 
                                lapply(estimates.pe.cbps.weight4, function(x) x[[2]]))
  
  estimates.pe.cbps.match <- c(lapply(estimates.pe.cbps.match1, function(x) x[[2]]),
                               lapply(estimates.pe.cbps.match2, function(x) x[[2]]),
                               lapply(estimates.pe.cbps.match3, function(x) x[[2]]), 
                               lapply(estimates.pe.cbps.match4, function(x) x[[2]]))
  
  
  matlist <- c(lapply(ols.models1, function(x) confint(x, level = .9)["dem", , drop = F]),
               lapply(ols.models2, function(x) confint(x, level = .9)["dem", , drop = F]),
               lapply(ols.models3, function(x) confint(x, level = .9)["dem", , drop = F]),
               lapply(ols.models4, function(x) confint(x, level = .9)["dem", , drop = F]))
  
  
  return(list(matlist, estimates.pe.maha, estimates.pe.ps.weight, estimates.pe.ps.match, 
              estimates.pe.cbps.weight, estimates.pe.cbps.match))	
  
}
#panelmatch results are PE objects in list, ols list is full of matrices
find_coverage <- function(true.effect, ols.list, maha.list, ps.weight.list,
                          ps.match.list, cbps.weight.list, cbps.match.list, model.detail = "")
{
  #standardizing the results a bit
  maha.list <- lapply(maha.list, function(x){summary(x)$summary[, 3:4, drop = F]})
  ps.weight.list <- lapply(ps.weight.list, function(x){summary(x)$summary[, 3:4, drop = F]})
  ps.match.list <- lapply(ps.match.list, function(x){summary(x)$summary[, 3:4, drop = F]})
  cbps.weight.list <- lapply(cbps.weight.list, function(x){summary(x)$summary[, 3:4, drop = F]})
  cbps.match.list <- lapply(cbps.match.list, function(x){summary(x)$summary[, 3:4, drop = F]})
  
  check_interval <- function(x, true.effect_) 
  {
    return(x[, 1] < true.effect & true.effect < x[, 2])
  }
  
  cov.res.ols <- mean(sapply(ols.list, check_interval, true.effect_ = true.effect))
  cov.res.maha <- mean(sapply(maha.list, check_interval, true.effect_ = true.effect))
  cov.res.ps.weight <- mean(sapply(ps.weight.list, check_interval, true.effect_ = true.effect))
  cov.res.ps.match <- mean(sapply(ps.match.list, check_interval, true.effect_ = true.effect))
  cov.res.cbps.weight <- mean(sapply(cbps.weight.list, check_interval, true.effect_ = true.effect))
  cov.res.cbps.match <- mean(sapply(cbps.match.list, check_interval, true.effect_ = true.effect))
  
  cov.results = c(cov.res.ols, cov.res.maha, cov.res.ps.weight, 
                  cov.res.ps.match, cov.res.cbps.weight, cov.res.cbps.match)
  plot(cov.results, ylab = "coverage rate", xlab = "method", xaxt = "n", 
       main = paste0("Coverage rates by method", " ", model.detail), pch = 19, cex = 1.2, cex.axis = 1.2, cex.lab = 1.2, ylim = c(.1, 1))
  axis(1, at=1:6, labels=c("OLS", "maha", "ps weight", "ps match", 
                           "cbps weight", "cbps match"), cex.axis = 1.2)
}

get_rmse <- function(full.ols.results, full.maha.results, full.ps.weight.results,
                     full.ps.match.results, full.cbps.weight.results, full.cbps.match.results, true.effect, model.detail = "")
{
  rmse.ols = sqrt(mean( (full.ols.results - true.effect)^2 ) )
  rmse.maha = sqrt(mean( (full.maha.results - true.effect)^2) )
  rmse.psw = sqrt(mean( (full.ps.weight.results - true.effect)^2) )
  rmse.psm = sqrt(mean( (full.ps.match.results - true.effect)^2) )
  rmse.cbpsw = sqrt(mean( (full.cbps.weight.results - true.effect)^2) )
  rmse.cbpsm = sqrt(mean( (full.cbps.match.results - true.effect)^2) )
  
  pdata  <- c(rmse.ols,rmse.maha, rmse.psw, rmse.psm,rmse.cbpsw,rmse.cbpsm)
  plot(pdata, xlab = "method", ylab = "RMSE", xaxt = "n", main = paste0("RMSE by method", " ", model.detail),  
       pch = 19, cex = 1.2, cex.axis = 1.2, cex.lab = 1.2, ylim = c(.6, 2))
  axis(1, at=1:6, labels=c("OLS", "maha", "ps weight", "ps match", 
                           "cbps weight", "cbps match"), cex.axis = 1.2)
}



bias.calc <- function(true.treatment.effect, ols.results, ols.results2, ps.maha.results, 
                             cbps.weight.results, cbps.match.results, y.axis.limits = c(-2, 2), model.detail = "")
{
  
  
  res <- unlist(ols.results)
  bias1 = mean(res) - true.treatment.effect
  
  res <- unlist(ols.results2)
  bias1.1 = mean(res) - true.treatment.effect
  
  res <- unlist(ps.maha.results)
  bias2 = mean(res) - true.treatment.effect
  
  #res <- unlist(ps.matching.results)
  #bias3 = mean(res) - true.treatment.effect
  
  #res <- unlist(ps.weight.results)
  #bias4 = mean(res) - true.treatment.effect
  
  res <- unlist(cbps.weight.results)
  bias5 = mean(res) - true.treatment.effect
  
  res <- unlist(cbps.match.results)
  bias6 = mean(res) - true.treatment.effect
  
  bias.vec <- c(bias1, bias1.1, bias2, bias5, bias6) # weight, match weight match
  
  data.frame("bias" = bias.vec, 
             "method" = c("ols", "ols2", "mahalanobis", "CBPS weighting", "CBPS matching"))
  
  #plot(bias.vec, xlab = "method", ylab = "bias", main = paste0("Bias by method", " ", model.detail), 
  #     xaxt = "n", ylim = y.axis.limits, pch = 19, cex = 1.2, cex.axis = 1.2, cex.lab = 1.2)
  
  #axis(1, at=1:6, labels=c("OLS", "maha", "ps weight", "ps match", 
  #                         "cbps weight", "cbps match"), cex.axis = 1.2)
  #abline(h = 0, col = "red")
  
}

sd.calc <- function(full.ols.results,full.ols.results2, 
                    full.maha.results,
                    full.cbps.weight.results, full.cbps.match.results, model.detail = "")
{
  tdf <- data.frame("sd" = c(sd(full.ols.results), sd(full.ols.results2), 
                    sd(full.maha.results),
                    sd(full.cbps.weight.results), 
                    sd(full.cbps.match.results)), method = c("ols", "ols2", "mahalanobis", 
                                                            "CBPS weighting", "CBPS matching"))
  return(tdf)
  
  #plot(x = as.numeric(tdf[1,]), main = paste0("Standard Deviation of Estimates", " ", model.detail),
  #     xaxt = "n", ylab = "SD", xlab = "method", pch = 19, cex = 1.2, cex.axis = 1.2, cex.lab = 1.2, ylim = c(.3, .9))
  #axis(1, at = 1:6, labels = colnames(tdf), cex.axis = 1.2)
}


rmse.calc <- function(full.ols.results, full.ols.results2, 
                      full.maha.results, 
                      full.cbps.weight.results, 
                      full.cbps.match.results, true.effect, model.detail = "")
{
  rmse.ols = sqrt(mean( (full.ols.results - true.effect)^2 ) )
  rmse.ols2 = sqrt(mean( (full.ols.results2 - true.effect)^2 ) )
  rmse.maha = sqrt(mean( (full.maha.results - true.effect)^2) )
  #rmse.psw = sqrt(mean( (full.ps.weight.results - true.effect)^2) )
  #rmse.psm = sqrt(mean( (full.ps.match.results - true.effect)^2) )
  rmse.cbpsw = sqrt(mean( (full.cbps.weight.results - true.effect)^2) )
  rmse.cbpsm = sqrt(mean( (full.cbps.match.results - true.effect)^2) )
  
  pdata  <- data.frame("rmse" = c(rmse.ols, rmse.ols2, rmse.maha,rmse.cbpsw,rmse.cbpsm),
                       "method" = c("ols", "ols2", "mahalanobis", "CBPS weighting", "CBPS matching"))
  return(pdata)  
  #plot(pdata, xlab = "method", ylab = "RMSE", xaxt = "n", main = paste0("RMSE by method", " ", model.detail),  
  #     pch = 19, cex = 1.2, cex.axis = 1.2, cex.lab = 1.2, ylim = c(.6, 2))
  #axis(1, at=1:6, labels=c("OLS", "maha", "ps weight", "ps match", 
  #                         "cbps weight", "cbps match"), cex.axis = 1.2)
}



prep_data_for_coverage_temp <- function(estimates.pe.maha1, estimates.pe.maha2, estimates.pe.maha3, estimates.pe.maha4,
                                        estimates.pe.maha5, estimates.pe.maha6, estimates.pe.maha7, estimates.pe.maha8,
                                        estimates.pe.maha9, estimates.pe.maha10, estimates.pe.maha11, estimates.pe.maha12,
                                        estimates.pe.maha13, estimates.pe.maha14, estimates.pe.maha15,
                                        estimates.pe.cbps.weight1, estimates.pe.cbps.weight2, estimates.pe.cbps.weight3, estimates.pe.cbps.weight4,
                                        estimates.pe.cbps.weight5, estimates.pe.cbps.weight6, estimates.pe.cbps.weight7, estimates.pe.cbps.weight8,
                                        estimates.pe.cbps.weight9, estimates.pe.cbps.weight10, estimates.pe.cbps.weight11, estimates.pe.cbps.weight12,
                                        estimates.pe.cbps.weight13, estimates.pe.cbps.weight14, estimates.pe.cbps.weight15,
                                        estimates.pe.cbps.match1, estimates.pe.cbps.match2, estimates.pe.cbps.match3, estimates.pe.cbps.match4,
                                        estimates.pe.cbps.match5, estimates.pe.cbps.match6, estimates.pe.cbps.match7, estimates.pe.cbps.match8,
                                        estimates.pe.cbps.match9, estimates.pe.cbps.match10, estimates.pe.cbps.match11, estimates.pe.cbps.match12,
                                        estimates.pe.cbps.match13, estimates.pe.cbps.match14, estimates.pe.cbps.match15,
                                        ols.models1, ols.models2, ols.models3, ols.models4,ols.models5, ols.models6, ols.models7, ols.models8,
                                        ols.models9, ols.models10, ols.models11, ols.models12, ols.models13, ols.models14, ols.models15)
{
  estimates.pe.maha <- c(lapply(estimates.pe.maha1, function(x) x[[2]]),
                         lapply(estimates.pe.maha2, function(x) x[[2]]),
                         lapply(estimates.pe.maha3, function(x) x[[2]]),
                         lapply(estimates.pe.maha4, function(x) x[[2]]),
                         lapply(estimates.pe.maha5, function(x) x[[2]]),
                         lapply(estimates.pe.maha6, function(x) x[[2]]),
                         lapply(estimates.pe.maha7, function(x) x[[2]]),
                         lapply(estimates.pe.maha8, function(x) x[[2]]),
                         lapply(estimates.pe.maha9, function(x) x[[2]]),
                         lapply(estimates.pe.maha10, function(x) x[[2]]),
                         lapply(estimates.pe.maha11, function(x) x[[2]]),
                         lapply(estimates.pe.maha12, function(x) x[[2]]),
                         lapply(estimates.pe.maha13, function(x) x[[2]]),
                         lapply(estimates.pe.maha14, function(x) x[[2]]),
                         lapply(estimates.pe.maha15, function(x) x[[2]]))
  
  
  estimates.pe.cbps.weight <- c(lapply(estimates.pe.cbps.weight1, function(x) x[[2]]),
                                lapply(estimates.pe.cbps.weight2, function(x) x[[2]]),
                                lapply(estimates.pe.cbps.weight3, function(x) x[[2]]),
                                lapply(estimates.pe.cbps.weight4, function(x) x[[2]]),
                                lapply(estimates.pe.cbps.weight5, function(x) x[[2]]),
                                lapply(estimates.pe.cbps.weight6, function(x) x[[2]]),
                                lapply(estimates.pe.cbps.weight7, function(x) x[[2]]),
                                lapply(estimates.pe.cbps.weight8, function(x) x[[2]]),
                                lapply(estimates.pe.cbps.weight9, function(x) x[[2]]),
                                lapply(estimates.pe.cbps.weight10, function(x) x[[2]]),
                                lapply(estimates.pe.cbps.weight11, function(x) x[[2]]),
                                lapply(estimates.pe.cbps.weight12, function(x) x[[2]]),
                                lapply(estimates.pe.cbps.weight13, function(x) x[[2]]),
                                lapply(estimates.pe.cbps.weight14, function(x) x[[2]]),
                                lapply(estimates.pe.cbps.weight15, function(x) x[[2]]))
  
  estimates.pe.cbps.match <- c(lapply(estimates.pe.cbps.match1, function(x) x[[2]]),
                               lapply(estimates.pe.cbps.match2, function(x) x[[2]]),
                               lapply(estimates.pe.cbps.match3, function(x) x[[2]]),
                               lapply(estimates.pe.cbps.match4, function(x) x[[2]]),
                               lapply(estimates.pe.cbps.match5, function(x) x[[2]]),
                               lapply(estimates.pe.cbps.match6, function(x) x[[2]]),
                               lapply(estimates.pe.cbps.match7, function(x) x[[2]]),
                               lapply(estimates.pe.cbps.match8, function(x) x[[2]]),
                               lapply(estimates.pe.cbps.match9, function(x) x[[2]]),
                               lapply(estimates.pe.cbps.match10, function(x) x[[2]]),
                               lapply(estimates.pe.cbps.match11, function(x) x[[2]]),
                               lapply(estimates.pe.cbps.match12, function(x) x[[2]]),
                               lapply(estimates.pe.cbps.match13, function(x) x[[2]]),
                               lapply(estimates.pe.cbps.match14, function(x) x[[2]]),
                               lapply(estimates.pe.cbps.match15, function(x) x[[2]]))
  
  
  matlist <- c(lapply(ols.models1, function(x) confint(x, level = .9)["dem", , drop = F]),
               lapply(ols.models2, function(x) confint(x, level = .9)["dem", , drop = F]),
               lapply(ols.models3, function(x) confint(x, level = .9)["dem", , drop = F]),
               lapply(ols.models4, function(x) confint(x, level = .9)["dem", , drop = F]),
               lapply(ols.models5, function(x) confint(x, level = .9)["dem", , drop = F]),
               lapply(ols.models6, function(x) confint(x, level = .9)["dem", , drop = F]),
               lapply(ols.models7, function(x) confint(x, level = .9)["dem", , drop = F]),
               lapply(ols.models8, function(x) confint(x, level = .9)["dem", , drop = F]),
               lapply(ols.models9, function(x) confint(x, level = .9)["dem", , drop = F]),
               lapply(ols.models10, function(x) confint(x, level = .9)["dem", , drop = F]),
               lapply(ols.models11, function(x) confint(x, level = .9)["dem", , drop = F]),
               lapply(ols.models12, function(x) confint(x, level = .9)["dem", , drop = F]),
               lapply(ols.models13, function(x) confint(x, level = .9)["dem", , drop = F]),
               lapply(ols.models14, function(x) confint(x, level = .9)["dem", , drop = F]),
               lapply(ols.models15, function(x) confint(x, level = .9)["dem", , drop = F]))
  
  
  return(list(matlist, estimates.pe.maha,estimates.pe.cbps.weight, estimates.pe.cbps.match))	
  
}
#panelmatch results are PE objects in list, ols list is full of matrices
find_coverage_temp <- function(true.effect, ols.list, maha.list, cbps.weight.list, cbps.match.list, model.detail = "")
{
  #standardizing the results a bit
  maha.list <- lapply(maha.list, function(x){summary(x)$summary[, 3:4, drop = F]})
  cbps.weight.list <- lapply(cbps.weight.list, function(x){summary(x)$summary[, 3:4, drop = F]})
  cbps.match.list <- lapply(cbps.match.list, function(x){summary(x)$summary[, 3:4, drop = F]})
  
  check_interval <- function(x, true.effect_) 
  {
    return(x[, 1] < true.effect & true.effect < x[, 2])
  }
  
  cov.res.ols <- mean(sapply(ols.list, check_interval, true.effect_ = true.effect))
  cov.res.maha <- mean(sapply(maha.list, check_interval, true.effect_ = true.effect))
  cov.res.cbps.weight <- mean(sapply(cbps.weight.list, check_interval, true.effect_ = true.effect))
  cov.res.cbps.match <- mean(sapply(cbps.match.list, check_interval, true.effect_ = true.effect))
  
  cov.results = data.frame("coverage" = c(cov.res.ols, cov.res.maha, cov.res.cbps.weight, cov.res.cbps.match),
                           "method" = c("ols", "mahalanobis", "CBPS weighting", "CBPS matching"))
  return(cov.results)
  #plot(cov.results, ylab = "coverage rate", xlab = "method", xaxt = "n", 
  #     main = paste0("Coverage rates by method", " ", model.detail), pch = 19, cex = 1.2, cex.axis = 1.2, cex.lab = 1.2, ylim = c(.1, 1))
  #axis(1, at=1:6, labels=c("OLS", "maha", "cbps weight", "cbps match"), cex.axis = 1.2)
}



prep_data_for_coverage_calc <- function(estimates.pe.maha,
                                        estimates.pe.cbps.match,
                                        estimates.pe.cbps.weight,
                                        ols.models,
                                        ols.models2)
{
  
  pe.maha = list()
  for(j in 1:length(estimates.pe.maha))
  {
    pe.maha[[j]] <- lapply(estimates.pe.maha[[j]], function(x) x[[2]])
  }
  pe.maha <- unlist(pe.maha, recursive = F)
  rm(estimates.pe.maha)
  pe.cbps.match = list()
  for(j in 1:length(estimates.pe.cbps.match))
  {
    pe.cbps.match[[j]] <- lapply(estimates.pe.cbps.match[[j]], function(x) x[[2]])
  }
  pe.cbps.match <- unlist(pe.cbps.match, recursive = F)
  rm(estimates.pe.cbps.match)
  pe.cbps.weight = list()
  for(j in 1:length(estimates.pe.cbps.weight))
  {
    pe.cbps.weight[[j]] <- lapply(estimates.pe.cbps.weight[[j]], function(x) x[[2]])
  }
  pe.cbps.weight <- unlist(pe.cbps.weight, recursive = F)
  rm(estimates.pe.cbps.weight)
  matlist = list()
  for(j in 1:length(ols.models))
  {
    matlist[[j]] <- lapply(ols.models[[j]], function(x) confint(x, level = 0.9)["dem", , drop = F])
  }
  matlist <- unlist(matlist, recursive = F)
  
  matlist2 = list()
  for(j in 1:length(ols.models2))
  {
    matlist2[[j]] <- lapply(ols.models2[[j]], function(x) confint(x, level = 0.9)["dem", , drop = F])
  }
  matlist2 <- unlist(matlist2, recursive = F)
  
  
  return(list(matlist, matlist2, pe.maha,pe.cbps.match, pe.cbps.weight))	
  
}
#panelmatch results are PE objects in list, ols list is full of matrices
find_coverage_calc <- function(true.effect, ols.list, ols.list2, 
                               maha.list, cbps.weight.list, cbps.match.list, model.detail = "")
{
  #standardizing the results a bit
  maha.list[sapply(maha.list, is.null)] <- NULL
  cbps.match.list[sapply(cbps.match.list, is.null)] <- NULL
  cbps.weight.list[sapply(cbps.weight.list, is.null)] <- NULL
  
  maha.list <- lapply(maha.list, function(x){summary(x)$summary[, 3:4, drop = F]})
  cbps.weight.list <- lapply(cbps.weight.list, function(x){summary(x)$summary[, 3:4, drop = F]})
  cbps.match.list <- lapply(cbps.match.list, function(x){summary(x)$summary[, 3:4, drop = F]})
  
  check_interval <- function(x, true.effect_) 
  {
    return(x[, 1] < true.effect_ & true.effect_ < x[, 2])
  }
  
  cov.res.ols <- mean(sapply(ols.list, check_interval, true.effect_ = true.effect))
  cov.res.ols2 <- mean(sapply(ols.list2, check_interval, true.effect_ = true.effect))
  cov.res.maha <- mean(sapply(maha.list, check_interval, true.effect_ = true.effect))
  cov.res.cbps.weight <- mean(sapply(cbps.weight.list, check_interval, true.effect_ = true.effect))
  cov.res.cbps.match <- mean(sapply(cbps.match.list, check_interval, true.effect_ = true.effect))
  
  cov.res.ols_0 <- mean(sapply(ols.list, check_interval, true.effect_ = 0))
  cov.res.ols2_0 <- mean(sapply(ols.list2, check_interval, true.effect_ = 0))
  cov.res.maha_0 <- mean(sapply(maha.list, check_interval, true.effect_ = 0))
  cov.res.cbps.weight_0 <- mean(sapply(cbps.weight.list, check_interval, true.effect_ = 0))
  cov.res.cbps.match_0 <- mean(sapply(cbps.match.list, check_interval, true.effect_ = 0))
  
  cov.results = data.frame("coverage" = c(cov.res.ols, cov.res.ols2, cov.res.maha, cov.res.cbps.weight, cov.res.cbps.match),
                           "coverage_0" = c(cov.res.ols_0, cov.res.ols2_0, cov.res.maha_0, cov.res.cbps.weight_0, cov.res.cbps.match_0),
                           "method" = c("ols", "ols2", "mahalanobis", "CBPS weighting", "CBPS matching"))
  return(cov.results)
  #plot(cov.results, ylab = "coverage rate", xlab = "method", xaxt = "n", 
  #     main = paste0("Coverage rates by method", " ", model.detail), pch = 19, cex = 1.2, cex.axis = 1.2, cex.lab = 1.2, ylim = c(.1, 1))
  #axis(1, at=1:6, labels=c("OLS", "maha", "cbps weight", "cbps match"), cex.axis = 1.2)
}



